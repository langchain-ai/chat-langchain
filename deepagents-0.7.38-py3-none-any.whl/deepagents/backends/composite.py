"""Composite backend that routes file operations by path prefix.

Routes operations to different backends based on path prefixes. Use this when
you need different storage strategies for different paths (e.g., state for
temp files, persistent store for memories).
"""

from collections import defaultdict
from collections.abc import Sequence
from typing import cast

from deepagents.backends.protocol import (
    BackendProtocol,
    DeleteResult,
    EditResult,
    ExecuteResponse,
    FileDownloadResponse,
    FileInfo,
    FileUploadResponse,
    GlobResult,
    GlobTruncationReason,
    GrepMatch,
    GrepResult,
    LsResult,
    ReadResult,
    SandboxBackendProtocol,
    WriteResult,
    _apply_grep_max_count,
    _method_accepts_max_count,
    execute_accepts_timeout,
)
from deepagents.backends.state import StateBackend

_DELETE_UNSUPPORTED_ERROR = "Error: deletion is not supported for '{file_path}'."


def _remap_grep_path(m: GrepMatch, route_prefix: str) -> GrepMatch:
    """Create a new `GrepMatch` with the route prefix prepended to the path."""
    return cast(
        "GrepMatch",
        {
            **m,
            "path": f"{route_prefix.rstrip('/')}{m['path']}",
        },
    )


def _remaining_grep_budget(max_count: int | None, collected: int) -> int | None:
    """Return the match budget left for the next routed grep.

    `None` means "no cap" (propagate `max_count=None` downstream). An int is the
    number of matches still allowed before the global cap is hit; `0` signals
    the caller to short-circuit the remaining routes.
    """
    if max_count is None:
        return None
    return max(max_count - collected, 0)


def _strip_route_from_pattern(pattern: str, route_prefix: str) -> str:
    """Strip a route prefix from a glob pattern when the pattern targets that route.

    If the pattern (ignoring a leading `/`) starts with the route prefix
    (also ignoring its leading `/`), the overlapping prefix is removed so
    the pattern is relative to the backend's internal root. The stripped
    remainder retains a leading `/` so a formerly slash-containing pattern
    remains anchored instead of becoming a recursive basename pattern.

    Args:
        pattern: The glob pattern, possibly absolute (e.g. `/memories/**/*.md`).
        route_prefix: The route prefix (e.g. `/memories/`).

    Returns:
        The pattern with the route prefix replaced by a leading `/`
            (e.g. `/memories/**/*.md` -> `/**/*.md`), or the original pattern
            if it doesn't match the route.
    """
    bare_pattern = pattern.lstrip("/")
    bare_prefix = route_prefix.strip("/") + "/"
    if bare_pattern.startswith(bare_prefix):
        return f"/{bare_pattern[len(bare_prefix) :]}"
    return pattern


def _route_glob_pattern(pattern: str, route_prefix: str) -> str | None:
    """Adapt `pattern` for a routed backend, or `None` if the route cannot match.

    A leading `/` anchors a pattern to the search root, so `/*.py` means
    top-level files only. Every result from a routed backend is prefixed with
    its route (`/memories/foo.py`), which is by construction deeper than the
    anchor allows. Unless the pattern explicitly targets this route, an anchored
    pattern therefore cannot legitimately match anything here -- forwarding it
    anyway is what made the composite root violate the anchoring contract that
    `BackendProtocol.glob` documents.

    Args:
        pattern: The glob pattern as supplied to the composite backend.
        route_prefix: The route prefix (e.g. `/memories/`).

    Returns:
        The pattern to hand the routed backend, or `None` to skip the route.
    """
    rewritten = _strip_route_from_pattern(pattern, route_prefix)
    if rewritten == pattern and pattern.startswith("/"):
        return None
    return rewritten


def _remap_file_info_path(fi: FileInfo, route_prefix: str) -> FileInfo:
    """Create a new FileInfo with the route prefix prepended to the path."""
    return cast(
        "FileInfo",
        {
            **fi,
            "path": f"{route_prefix.rstrip('/')}{fi['path']}",
        },
    )


def _glob_truncated(result: GlobResult | list[FileInfo]) -> bool:
    """Read the `truncated` flag off a glob result, tolerating legacy list returns."""
    return result.truncated if isinstance(result, GlobResult) else False


def _glob_truncation_reason(result: GlobResult | list[FileInfo]) -> GlobTruncationReason | None:
    """Read `truncation_reason` off a glob result, tolerating legacy list returns."""
    return result.truncation_reason if isinstance(result, GlobResult) else None


def _merge_truncation_reason(
    current: GlobTruncationReason | None,
    incoming: GlobTruncationReason | None,
) -> GlobTruncationReason | None:
    """Combine truncation reasons across merged sources, most actionable first.

    `unreadable` wins: it is the one cause the caller cannot fix by narrowing,
    so it must not be masked by a co-occurring budget truncation.
    """
    if current == "unreadable" or incoming == "unreadable":
        return "unreadable"
    return current or incoming


GlobBackendResult = GlobResult | list[FileInfo]
"""Result shape accepted by composite glob merge helpers.

Composite glob supports both current `GlobResult` values and legacy
`list[FileInfo]` backend returns.
"""


def _merge_glob_results(
    default_result: GlobBackendResult,
    routed_results: Sequence[tuple[str, GlobBackendResult]],
) -> GlobResult:
    """Merge the default backend's glob result with routed backends' results.

    A backend error must not be swallowed as a partial success (mirrors the
    grep merge path): the first error encountered — default first, then routes
    in order — short-circuits and is surfaced instead of returning
    default-only or partial matches. On success, `truncated` is OR-ed across
    all sources and each routed match's path is remapped under its route prefix.

    Args:
        default_result: Result from the default backend (searched at the root).
        routed_results: `(route_prefix, result)` pairs from each routed backend,
            in route iteration order.

    Returns:
        A merged `GlobResult`, or the first erroring result unchanged.
    """
    results: list[FileInfo] = []
    truncated = False
    reason: GlobTruncationReason | None = None

    if isinstance(default_result, GlobResult) and default_result.error:
        return default_result
    default_matches = default_result.matches if isinstance(default_result, GlobResult) else default_result
    results.extend(default_matches or [])
    truncated = truncated or _glob_truncated(default_result)
    reason = _merge_truncation_reason(reason, _glob_truncation_reason(default_result))

    for route_prefix, sub_result in routed_results:
        if isinstance(sub_result, GlobResult) and sub_result.error:
            return sub_result
        sub_matches = sub_result.matches if isinstance(sub_result, GlobResult) else sub_result
        results.extend(_remap_file_info_path(fi, route_prefix) for fi in (sub_matches or []))
        truncated = truncated or _glob_truncated(sub_result)
        reason = _merge_truncation_reason(reason, _glob_truncation_reason(sub_result))

    results.sort(key=lambda x: x.get("path", ""))
    return GlobResult(matches=results, truncated=truncated, truncation_reason=reason)


def _route_for_path(
    *,
    default: BackendProtocol,
    sorted_routes: list[tuple[str, BackendProtocol]],
    path: str,
) -> tuple[BackendProtocol, str, str | None]:
    """Route a path to a backend and normalize it for that backend.

    Returns the selected backend, the normalized path to pass to that backend,
    and the matched route prefix (or None if the default backend is used).

    Normalization rules:

    - If path is exactly the route root without trailing slash (e.g., "/memories"),
        route to that backend and return backend_path "/".
    - If path starts with the route prefix (e.g., "/memories/notes.txt"), strip the
        route prefix and ensure the result starts with "/".
    - Otherwise return the default backend and the original path.
    """
    for route_prefix, backend in sorted_routes:
        prefix_no_slash = route_prefix.rstrip("/")
        if path == prefix_no_slash:
            return backend, "/", route_prefix

        # Ensure route_prefix ends with / for startswith check to enforce boundary
        normalized_prefix = route_prefix if route_prefix.endswith("/") else f"{route_prefix}/"
        if path.startswith(normalized_prefix):
            suffix = path[len(normalized_prefix) :]
            backend_path = f"/{suffix}" if suffix else "/"
            return backend, backend_path, route_prefix
    return default, path, None


class CompositeBackend(BackendProtocol):
    """Routes file operations to different backends by path prefix.

    Matches paths against route prefixes (longest first) and delegates to the
    corresponding backend. Unmatched paths use the default backend.

    Attributes:
        default: Backend for paths that don't match any route.
        routes: Map of path prefixes to backends (e.g., `{"/memories/": store_backend}`).
        sorted_routes: Routes sorted by length (longest first) for correct matching.
        artifacts_root: Root path for artifacts, such as messages offloaded by middleware.

            Defaults to `"/"`.

    Examples:
        ```python
        ns = lambda _rt: ("filesystem",)  # noqa: E731
        composite = CompositeBackend(
            default=StateBackend(),
            routes={"/memories/": StoreBackend(namespace=ns), "/cache/": StoreBackend(namespace=ns)},
        )

        composite.write("/temp.txt", "data")
        composite.write("/memories/note.txt", "data")
        ```
    """

    def __init__(
        self,
        default: BackendProtocol | StateBackend,
        routes: dict[str, BackendProtocol],
        *,
        artifacts_root: str = "/",
    ) -> None:
        """Initialize composite backend.

        Args:
            default: Backend for paths that don't match any route.
            routes: Map of path prefixes to backends.

                Prefixes must start with `"/"` and should end with `"/"` (e.g., `"/memories/"`).
            artifacts_root: Root path for artifacts, such as messages offloaded
                by middleware.

                Defaults to `"/"`.
        """
        # Default backend
        self.default = default

        # Virtual routes
        self.routes = routes

        # Sort routes by length (longest first) for correct prefix matching
        self.sorted_routes = sorted(routes.items(), key=lambda x: len(x[0]), reverse=True)

        self.artifacts_root = artifacts_root

    def _get_backend_and_key(self, key: str) -> tuple[BackendProtocol, str]:
        backend, stripped_key, _route_prefix = _route_for_path(
            default=self.default,
            sorted_routes=self.sorted_routes,
            path=key,
        )
        return backend, stripped_key

    @staticmethod
    def _coerce_ls_result(raw: LsResult | list[FileInfo]) -> LsResult:
        """Normalize legacy `list[FileInfo]` returns to `LsResult`."""
        if isinstance(raw, LsResult):
            return raw
        return LsResult(entries=raw)

    def ls(self, path: str) -> LsResult:
        """List directory contents (non-recursive).

        If path matches a route, lists only that backend. If path is `"/"`,
        aggregates default backend plus virtual route directories.
        Otherwise lists default backend.

        Args:
            path: Absolute directory path starting with `"/"`.

        Returns:
            `LsResult` with directory entries or error.

        Examples:
            ```python
            result = composite.ls("/")
            result = composite.ls("/memories/")
            ```
        """
        backend, backend_path, route_prefix = _route_for_path(
            default=self.default,
            sorted_routes=self.sorted_routes,
            path=path,
        )
        if route_prefix is not None:
            ls_result = self._coerce_ls_result(backend.ls(backend_path))
            if ls_result.error:
                return ls_result
            return LsResult(entries=[_remap_file_info_path(fi, route_prefix) for fi in (ls_result.entries or [])])

        # At root, aggregate default and all routed backends
        if path == "/":
            results: list[FileInfo] = []
            default_result = self._coerce_ls_result(self.default.ls(path))
            if default_result.error:
                return default_result
            results.extend(default_result.entries or [])
            for route_prefix, _backend in self.sorted_routes:
                # Add the route itself as a directory (e.g., /memories/)
                results.append(
                    FileInfo(
                        path=route_prefix,
                        is_dir=True,
                        size=0,
                        modified_at="",
                    )
                )

            results.sort(key=lambda x: x.get("path", ""))
            return LsResult(entries=results)

        # Path doesn't match a route: query only default backend
        return self._coerce_ls_result(self.default.ls(path))

    async def als(self, path: str) -> LsResult:
        """Async version of ls."""
        backend, backend_path, route_prefix = _route_for_path(
            default=self.default,
            sorted_routes=self.sorted_routes,
            path=path,
        )
        if route_prefix is not None:
            ls_result = self._coerce_ls_result(await backend.als(backend_path))
            if ls_result.error:
                return ls_result
            return LsResult(entries=[_remap_file_info_path(fi, route_prefix) for fi in (ls_result.entries or [])])

        # At root, aggregate default and all routed backends
        if path == "/":
            results: list[FileInfo] = []
            default_result = self._coerce_ls_result(await self.default.als(path))
            if default_result.error:
                return default_result
            results.extend(default_result.entries or [])
            for route_prefix, _backend in self.sorted_routes:
                # Add the route itself as a directory (e.g., /memories/)
                results.append(
                    {
                        "path": route_prefix,
                        "is_dir": True,
                        "size": 0,
                        "modified_at": "",
                    }
                )

            results.sort(key=lambda x: x.get("path", ""))
            return LsResult(entries=results)

        # Path doesn't match a route: query only default backend
        return self._coerce_ls_result(await self.default.als(path))

    def read(
        self,
        file_path: str,
        offset: int = 0,
        limit: int = 2000,
    ) -> ReadResult:
        """Read file content, routing to appropriate backend.

        Args:
            file_path: Absolute file path.
            offset: Line offset to start reading from (0-indexed).
            limit: Maximum number of lines to read.

        Returns:
            `ReadResult`
        """
        backend, stripped_key = self._get_backend_and_key(file_path)
        return backend.read(stripped_key, offset=offset, limit=limit)

    async def aread(
        self,
        file_path: str,
        offset: int = 0,
        limit: int = 2000,
    ) -> ReadResult:
        """Async version of read."""
        backend, stripped_key = self._get_backend_and_key(file_path)
        return await backend.aread(stripped_key, offset=offset, limit=limit)

    @staticmethod
    def _coerce_grep_result(raw: GrepResult | list[GrepMatch] | str) -> GrepResult:
        """Normalize legacy `list[GrepMatch] | str` returns to `GrepResult`."""
        if isinstance(raw, GrepResult):
            return raw
        if isinstance(raw, str):
            return GrepResult(error=raw)
        return GrepResult(matches=raw)

    def _grep_backend(
        self,
        backend: BackendProtocol,
        pattern: str,
        path: str | None,
        glob: str | None,
        max_count: int | None,
    ) -> GrepResult:
        """Call `grep` while supporting backends with the previous signature."""
        if _method_accepts_max_count(type(backend), "grep"):
            raw = backend.grep(pattern, path, glob, max_count=max_count)
        else:
            raw = backend.grep(pattern, path, glob)
        return _apply_grep_max_count(self._coerce_grep_result(raw), max_count)

    async def _agrep_backend(
        self,
        backend: BackendProtocol,
        pattern: str,
        path: str | None,
        glob: str | None,
        max_count: int | None,
    ) -> GrepResult:
        """Call `agrep` while supporting backends with the previous signature."""
        if _method_accepts_max_count(type(backend), "agrep"):
            raw = await backend.agrep(pattern, path, glob, max_count=max_count)
        else:
            raw = await backend.agrep(pattern, path, glob)
        return _apply_grep_max_count(self._coerce_grep_result(raw), max_count)

    def grep(
        self,
        pattern: str,
        path: str | None = None,
        glob: str | None = None,
        *,
        max_count: int | None = None,
    ) -> GrepResult:
        """Search files for literal text pattern.

        Routes to backends based on path: specific route searches one backend,
        `"/"` or `None` searches all backends, otherwise searches
        default backend.

        Args:
            pattern: Literal text to search for (NOT regex).
            path: Directory to search. None searches all backends.
            glob: Glob pattern to filter files (e.g., `"*.py"`, `"**/*.txt"`).

                Filters by filename, not content.
            max_count: Optional total cap on returned matches across all routed
                backends. `None` returns every match; an int enforces the cap
                globally (not per backend), short-circuits remaining routes once
                the cap is reached, and flags the result `truncated=True`.

                Unlike a single backend, composite does not guarantee the
                "exactly `max_count` matches means complete" boundary: when an
                earlier route fills the budget exactly, the remaining routes are
                short-circuited and the result is flagged `truncated=True` even
                if those routes would have contributed nothing. The flag is thus
                conservative — it may over-report truncation, never under-report.

        Returns:
            `GrepResult` with matches or error.

        Examples:
            ```python
            result = composite.grep("TODO", path="/memories/")
            result = composite.grep("error", path="/")
            result = composite.grep("import", path="/", glob="*.py")
            ```
        """
        if path is not None:
            backend, backend_path, route_prefix = _route_for_path(
                default=self.default,
                sorted_routes=self.sorted_routes,
                path=path,
            )
            if route_prefix is not None:
                grep_result = self._grep_backend(backend, pattern, backend_path, glob, max_count)
                if grep_result.error:
                    return grep_result
                return GrepResult(
                    matches=[_remap_grep_path(m, route_prefix) for m in (grep_result.matches or [])],
                    truncated=grep_result.truncated,
                )

        # If path is None or "/", search default and all routed backends and merge
        # Otherwise, search only the default backend
        if path is None or path == "/":
            all_matches: list[GrepMatch] = []
            truncated = False
            default_result = self._grep_backend(self.default, pattern, path, glob, max_count)
            if default_result.error:
                return default_result
            all_matches.extend(default_result.matches or [])
            truncated = truncated or default_result.truncated

            for route_prefix, backend in self.routes.items():
                remaining = _remaining_grep_budget(max_count, len(all_matches))
                if remaining == 0:
                    # Cap already met by earlier routes; skip the rest.
                    truncated = True
                    break
                grep_result = self._grep_backend(backend, pattern, "/", glob, remaining)
                if grep_result.error:
                    return grep_result
                all_matches.extend(_remap_grep_path(m, route_prefix) for m in (grep_result.matches or []))
                truncated = truncated or grep_result.truncated

            # Unreachable safety net: each routed result is already capped to its
            # allotted budget by the `_grep_backend`/`_agrep_backend` helpers
            # (via `_apply_grep_max_count`), so the running total can never exceed
            # `max_count`. Kept as belt-and-suspenders against a future refactor
            # that bypasses that per-route capping.
            if max_count is not None and len(all_matches) > max_count:
                all_matches = all_matches[:max_count]
                truncated = True
            return GrepResult(matches=all_matches, truncated=truncated)
        # Path specified but doesn't match a route - search only default
        return self._grep_backend(self.default, pattern, path, glob, max_count)

    async def agrep(
        self,
        pattern: str,
        path: str | None = None,
        glob: str | None = None,
        *,
        max_count: int | None = None,
    ) -> GrepResult:
        """Async version of grep.

        See `grep()` for detailed documentation on routing behavior and parameters.
        """
        if path is not None:
            backend, backend_path, route_prefix = _route_for_path(
                default=self.default,
                sorted_routes=self.sorted_routes,
                path=path,
            )
            if route_prefix is not None:
                grep_result = await self._agrep_backend(backend, pattern, backend_path, glob, max_count)
                if grep_result.error:
                    return grep_result
                return GrepResult(
                    matches=[_remap_grep_path(m, route_prefix) for m in (grep_result.matches or [])],
                    truncated=grep_result.truncated,
                )

        # If path is None or "/", search default and all routed backends and merge
        # Otherwise, search only the default backend
        if path is None or path == "/":
            all_matches: list[GrepMatch] = []
            truncated = False
            default_result = await self._agrep_backend(self.default, pattern, path, glob, max_count)
            if default_result.error:
                return default_result
            all_matches.extend(default_result.matches or [])
            truncated = truncated or default_result.truncated

            for route_prefix, backend in self.routes.items():
                remaining = _remaining_grep_budget(max_count, len(all_matches))
                if remaining == 0:
                    # Cap already met by earlier routes; skip the rest.
                    truncated = True
                    break
                grep_result = await self._agrep_backend(backend, pattern, "/", glob, remaining)
                if grep_result.error:
                    return grep_result
                all_matches.extend(_remap_grep_path(m, route_prefix) for m in (grep_result.matches or []))
                truncated = truncated or grep_result.truncated

            # Unreachable safety net: each routed result is already capped to its
            # allotted budget by the `_grep_backend`/`_agrep_backend` helpers
            # (via `_apply_grep_max_count`), so the running total can never exceed
            # `max_count`. Kept as belt-and-suspenders against a future refactor
            # that bypasses that per-route capping.
            if max_count is not None and len(all_matches) > max_count:
                all_matches = all_matches[:max_count]
                truncated = True
            return GrepResult(matches=all_matches, truncated=truncated)
        # Path specified but doesn't match a route - search only default
        return await self._agrep_backend(self.default, pattern, path, glob, max_count)

    def glob(self, pattern: str, path: str | None = None) -> GlobResult:
        """Find files matching a glob pattern, routing by path prefix.

        Routes to backends based on path: a routed path searches that route,
        `"/"` or `None` searches every backend, and a non-route path searches
        only the default backend.

        When merging across routes, a pattern that targets a route is rewritten
        relative to that route's internal root (see `_strip_route_from_pattern`);
        a bare pattern is forwarded unchanged and matches recursively within
        every route; and a root-anchored pattern that targets no route skips the
        routed backends entirely, since their results are always deeper than the
        anchor permits (see `_route_glob_pattern`).
        """
        if path is not None:
            backend, backend_path, route_prefix = _route_for_path(
                default=self.default,
                sorted_routes=self.sorted_routes,
                path=path,
            )
            if route_prefix is not None:
                glob_result = backend.glob(pattern, backend_path)
                matches = glob_result.matches if isinstance(glob_result, GlobResult) else glob_result
                if isinstance(glob_result, GlobResult) and glob_result.error:
                    return glob_result
                return GlobResult(
                    matches=[_remap_file_info_path(fi, route_prefix) for fi in (matches or [])],
                    truncated=_glob_truncated(glob_result),
                    truncation_reason=_glob_truncation_reason(glob_result),
                )

        # If path is None or "/", search default and all routed backends and merge.
        # Otherwise, search only the default backend.
        if path is None or path == "/":
            default_result = self.default.glob(pattern, path)
            if isinstance(default_result, GlobResult) and default_result.error:
                return _merge_glob_results(default_result, ())

            routed_results: list[tuple[str, GlobBackendResult]] = []
            for route_prefix, backend in self.routes.items():
                routed_pattern = _route_glob_pattern(pattern, route_prefix)
                if routed_pattern is None:
                    continue
                sub_result = backend.glob(routed_pattern, "/")
                routed_results.append((route_prefix, sub_result))
                if isinstance(sub_result, GlobResult) and sub_result.error:
                    return _merge_glob_results(default_result, routed_results)

            return _merge_glob_results(default_result, routed_results)

        return self.default.glob(pattern, path)

    async def aglob(self, pattern: str, path: str | None = None) -> GlobResult:
        """Async version of glob.

        See `glob()` for detailed documentation on routing behavior and parameters.
        """
        if path is not None:
            backend, backend_path, route_prefix = _route_for_path(
                default=self.default,
                sorted_routes=self.sorted_routes,
                path=path,
            )
            if route_prefix is not None:
                glob_result = await backend.aglob(pattern, backend_path)
                matches = glob_result.matches if isinstance(glob_result, GlobResult) else glob_result
                if isinstance(glob_result, GlobResult) and glob_result.error:
                    return glob_result
                return GlobResult(
                    matches=[_remap_file_info_path(fi, route_prefix) for fi in (matches or [])],
                    truncated=_glob_truncated(glob_result),
                    truncation_reason=_glob_truncation_reason(glob_result),
                )

        # If path is None or "/", search default and all routed backends and merge.
        # Otherwise, search only the default backend.
        if path is None or path == "/":
            default_result = await self.default.aglob(pattern, path)
            if isinstance(default_result, GlobResult) and default_result.error:
                return _merge_glob_results(default_result, ())

            routed_results: list[tuple[str, GlobBackendResult]] = []
            for route_prefix, backend in self.routes.items():
                routed_pattern = _route_glob_pattern(pattern, route_prefix)
                if routed_pattern is None:
                    continue
                sub_result = await backend.aglob(routed_pattern, "/")
                routed_results.append((route_prefix, sub_result))
                if isinstance(sub_result, GlobResult) and sub_result.error:
                    return _merge_glob_results(default_result, routed_results)

            return _merge_glob_results(default_result, routed_results)

        return await self.default.aglob(pattern, path)

    def write(
        self,
        file_path: str,
        content: str,
    ) -> WriteResult:
        """Create a new file, routing to appropriate backend.

        Args:
            file_path: Absolute file path.
            content: File content as a string.

        Returns:
            Success message or `Command` object, or error if file already exists.
        """
        backend, stripped_key = self._get_backend_and_key(file_path)
        res = backend.write(stripped_key, content)
        if res.path is not None and stripped_key != file_path:
            res.path = file_path
        return res

    async def awrite(
        self,
        file_path: str,
        content: str,
    ) -> WriteResult:
        """Async version of write."""
        backend, stripped_key = self._get_backend_and_key(file_path)
        res = await backend.awrite(stripped_key, content)
        if res.path is not None and stripped_key != file_path:
            res.path = file_path
        return res

    def edit(
        self,
        file_path: str,
        old_string: str,
        new_string: str,
        replace_all: bool = False,  # noqa: FBT001, FBT002
    ) -> EditResult:
        """Edit a file, routing to appropriate backend.

        Args:
            file_path: Absolute file path.
            old_string: String to find and replace.
            new_string: Replacement string.
            replace_all: If `True`, replace all occurrences.

        Returns:
            Success message or `Command` object, or error message on failure.
        """
        backend, stripped_key = self._get_backend_and_key(file_path)
        res = backend.edit(stripped_key, old_string, new_string, replace_all=replace_all)
        if res.path is not None:
            res.path = file_path
        return res

    async def aedit(
        self,
        file_path: str,
        old_string: str,
        new_string: str,
        replace_all: bool = False,  # noqa: FBT001, FBT002
    ) -> EditResult:
        """Async version of edit."""
        backend, stripped_key = self._get_backend_and_key(file_path)
        res = await backend.aedit(stripped_key, old_string, new_string, replace_all=replace_all)
        if res.path is not None:
            res.path = file_path
        return res

    def delete(self, file_path: str) -> DeleteResult:
        """Delete a file, routing to the appropriate backend.

        `CompositeBackend` always advertises delete support (it overrides this
        method), so the `delete` tool is never filtered out for it. A
        route may still point at a backend that does not implement `delete`;
        rather than letting `NotImplementedError` escape to the caller, that
        case is converted into a `DeleteResult` error.

        Args:
            file_path: Absolute file path.

        Returns:
            `DeleteResult` with the original path on success, or an error
            (including when the routed backend does not support deletion).
        """
        backend, stripped_key = self._get_backend_and_key(file_path)
        try:
            res = backend.delete(stripped_key)
        except NotImplementedError:
            return DeleteResult(error=_DELETE_UNSUPPORTED_ERROR.format(file_path=file_path))
        if res.path is not None:
            res.path = file_path
        return res

    async def adelete(self, file_path: str) -> DeleteResult:
        """Async version of delete."""
        backend, stripped_key = self._get_backend_and_key(file_path)
        try:
            res = await backend.adelete(stripped_key)
        except NotImplementedError:
            return DeleteResult(error=_DELETE_UNSUPPORTED_ERROR.format(file_path=file_path))
        if res.path is not None:
            res.path = file_path
        return res

    def execute(
        self,
        command: str,
        *,
        timeout: int | None = None,
    ) -> ExecuteResponse:
        """Execute a shell command via the default backend.

        Unlike file operations, execution is not path-routable — it always
        delegates to the default backend.

        Args:
            command: Shell command to execute.
            timeout: Maximum time in seconds to wait for the command to complete.

                If `None`, uses the backend's default timeout.

        Returns:
            `ExecuteResponse` with output, exit code, and truncation flag.

        Raises:
            NotImplementedError: If the default backend is not a
                [`SandboxBackendProtocol`][deepagents.backends.protocol.SandboxBackendProtocol]
                (i.e., it doesn't support execution).
        """
        if isinstance(self.default, SandboxBackendProtocol):
            if timeout is not None and execute_accepts_timeout(type(self.default)):
                return self.default.execute(command, timeout=timeout)
            return self.default.execute(command)

        # This shouldn't be reached if the runtime check in the execute tool works correctly,
        # but we include it as a safety fallback.
        msg = (
            "Default backend doesn't support command execution (SandboxBackendProtocol). "
            "To enable execution, provide a default backend that implements SandboxBackendProtocol."
        )
        raise NotImplementedError(msg)

    async def aexecute(
        self,
        command: str,
        *,
        # ASYNC109 - timeout is a semantic parameter forwarded to the underlying
        # backend's implementation, not an asyncio.timeout() contract.
        timeout: int | None = None,  # noqa: ASYNC109
    ) -> ExecuteResponse:
        """Async version of execute.

        See `execute()` for detailed documentation on parameters and behavior.
        """
        if isinstance(self.default, SandboxBackendProtocol):
            if timeout is not None and execute_accepts_timeout(type(self.default)):
                return await self.default.aexecute(command, timeout=timeout)
            return await self.default.aexecute(command)

        # This shouldn't be reached if the runtime check in the execute tool works correctly,
        # but we include it as a safety fallback.
        msg = (
            "Default backend doesn't support command execution (SandboxBackendProtocol). "
            "To enable execution, provide a default backend that implements SandboxBackendProtocol."
        )
        raise NotImplementedError(msg)

    def upload_files(self, files: list[tuple[str, bytes]]) -> list[FileUploadResponse]:
        """Upload multiple files, batching by backend for efficiency.

        Groups files by their target backend, calls each backend's
        `upload_files` once with all files for that backend, then merges
        results in original order.

        Args:
            files: List of `(path, content)` tuples to upload.

        Returns:
            List of `FileUploadResponse` objects, one per input file.

                Response order matches input order.
        """
        # Pre-allocate result list
        results: list[FileUploadResponse | None] = [None] * len(files)

        # Group files by backend, tracking original indices
        backend_batches: dict[BackendProtocol, list[tuple[int, str, bytes]]] = defaultdict(list)

        for idx, (path, content) in enumerate(files):
            backend, stripped_path = self._get_backend_and_key(path)
            backend_batches[backend].append((idx, stripped_path, content))

        # Process each backend's batch
        for backend, batch in backend_batches.items():
            # Extract data for backend call
            indices, stripped_paths, contents = zip(*batch, strict=False)
            batch_files = list(zip(stripped_paths, contents, strict=False))

            # Call backend once with all its files
            batch_responses = backend.upload_files(batch_files)

            # Place responses at original indices with original paths
            for i, orig_idx in enumerate(indices):
                results[orig_idx] = FileUploadResponse(
                    path=files[orig_idx][0],  # Original path
                    error=batch_responses[i].error if i < len(batch_responses) else None,
                )

        return cast("list[FileUploadResponse]", results)

    async def aupload_files(self, files: list[tuple[str, bytes]]) -> list[FileUploadResponse]:
        """Async version of upload_files."""
        # Pre-allocate result list
        results: list[FileUploadResponse | None] = [None] * len(files)

        # Group files by backend, tracking original indices
        backend_batches: dict[BackendProtocol, list[tuple[int, str, bytes]]] = defaultdict(list)

        for idx, (path, content) in enumerate(files):
            backend, stripped_path = self._get_backend_and_key(path)
            backend_batches[backend].append((idx, stripped_path, content))

        # Process each backend's batch
        for backend, batch in backend_batches.items():
            # Extract data for backend call
            indices, stripped_paths, contents = zip(*batch, strict=False)
            batch_files = list(zip(stripped_paths, contents, strict=False))

            # Call backend once with all its files
            batch_responses = await backend.aupload_files(batch_files)

            # Place responses at original indices with original paths
            for i, orig_idx in enumerate(indices):
                results[orig_idx] = FileUploadResponse(
                    path=files[orig_idx][0],  # Original path
                    error=batch_responses[i].error if i < len(batch_responses) else None,
                )

        return cast("list[FileUploadResponse]", results)

    def download_files(self, paths: list[str]) -> list[FileDownloadResponse]:
        """Download multiple files, batching by backend for efficiency.

        Groups paths by their target backend, calls each backend's
        `download_files` once with all paths for that backend, then merges
        results in original order.

        Args:
            paths: List of file paths to download.

        Returns:
            List of `FileDownloadResponse` objects, one per input path.

                Response order matches input order.
        """
        # Pre-allocate result list
        results: list[FileDownloadResponse | None] = [None] * len(paths)

        backend_batches: dict[BackendProtocol, list[tuple[int, str]]] = defaultdict(list)

        for idx, path in enumerate(paths):
            backend, stripped_path = self._get_backend_and_key(path)
            backend_batches[backend].append((idx, stripped_path))

        # Process each backend's batch
        for backend, batch in backend_batches.items():
            # Extract data for backend call
            indices, stripped_paths = zip(*batch, strict=False)

            # Call backend once with all its paths
            batch_responses = backend.download_files(list(stripped_paths))

            # Place responses at original indices with original paths
            for i, orig_idx in enumerate(indices):
                results[orig_idx] = FileDownloadResponse(
                    path=paths[orig_idx],  # Original path
                    content=batch_responses[i].content if i < len(batch_responses) else None,
                    error=batch_responses[i].error if i < len(batch_responses) else None,
                )

        return cast("list[FileDownloadResponse]", results)

    async def adownload_files(self, paths: list[str]) -> list[FileDownloadResponse]:
        """Async version of download_files."""
        # Pre-allocate result list
        results: list[FileDownloadResponse | None] = [None] * len(paths)

        backend_batches: dict[BackendProtocol, list[tuple[int, str]]] = defaultdict(list)

        for idx, path in enumerate(paths):
            backend, stripped_path = self._get_backend_and_key(path)
            backend_batches[backend].append((idx, stripped_path))

        # Process each backend's batch
        for backend, batch in backend_batches.items():
            # Extract data for backend call
            indices, stripped_paths = zip(*batch, strict=False)

            # Call backend once with all its paths
            batch_responses = await backend.adownload_files(list(stripped_paths))

            # Place responses at original indices with original paths
            for i, orig_idx in enumerate(indices):
                results[orig_idx] = FileDownloadResponse(
                    path=paths[orig_idx],  # Original path
                    content=batch_responses[i].content if i < len(batch_responses) else None,
                    error=batch_responses[i].error if i < len(batch_responses) else None,
                )

        return cast("list[FileDownloadResponse]", results)
