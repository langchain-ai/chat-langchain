"""Managed runtime seam for compiled Managed Deep Agents.

This module is consumed only by the entry module that ``mda deploy`` generates —
agent authors never import it directly. It is the point where MDA injects the
platform-owned backend (the configured sandbox), Context Hub-backed deployed
context, StateBackend scratch fallback, and managed memory/skills.
"""

from __future__ import annotations

import asyncio
import hashlib
import inspect
import json
import math
import os
import posixpath
import re
import socket
import threading
import time
from collections import OrderedDict
from collections.abc import (
    AsyncGenerator,
    Awaitable,
    Callable,
    Generator,
    Iterable,
    Mapping,
    Sequence,
    Sized,
)
from contextlib import asynccontextmanager, contextmanager, suppress
from contextvars import ContextVar
from dataclasses import dataclass, replace
from http import HTTPStatus
from pathlib import Path
from typing import TYPE_CHECKING, Any, ClassVar, Literal, TypedDict, TypeVar, cast
from urllib.parse import quote, urlsplit

from deepagents import FilesystemPermission, create_deep_agent
from deepagents.backends import (
    CompositeBackend,
    ContextHubBackend,
    FilesystemBackend,
    LangSmithSandbox,
    StateBackend,
)
from deepagents.backends.protocol import (
    BackendProtocol,
    DeleteResult,
    EditResult,
    ExecuteResponse,
    FileDownloadResponse,
    FileUploadResponse,
    GlobResult,
    GrepResult,
    LsResult,
    ReadResult,
    SandboxBackendProtocol,
    WriteResult,
)
from deepagents.middleware.async_subagents import _NEST_UNDER_PARENT
from langchain_core.runnables import RunnableConfig
from langgraph.graph.state import CompiledStateGraph as CompiledAgent
from langgraph_sdk import get_client
from langsmith import tracing_context
from langsmith.run_trees import RunTree
from langsmith.utils import tracing_is_enabled

from managed_deepagents._async_subagents import (
    GENERAL_PURPOSE,
    SUBAGENT_SKILLS_KEY,
    async_subagent_definition,
    route_async_subagents,
    with_async_general_purpose,
)
from managed_deepagents._channel import (
    Channel,
    collect_channels,
    requirements_from_channels,
)
from managed_deepagents._channels.binding import resolve_channel_provider
from managed_deepagents._channels.messaging_registry import register_channel_messaging
from managed_deepagents._connector import (
    Connector,
    ConnectorToolList,
    SandboxMode,
    collect_connectors,
    has_sandbox_connectors,
    load_connector_tools,
    load_tools_by_connector,
    requirements_from_connectors,
    run_connector_sandbox_hooks,
)
from managed_deepagents._eval_filesystem import create_eval_trial_filesystem_backend
from managed_deepagents._graph_build_timing import GraphBuildTiming
from managed_deepagents._identity_auth import build_managed_auth
from managed_deepagents._identity_http import build_managed_http_app
from managed_deepagents._identity_runtime import (
    _field,
    build_runtime_identity,
    resolve_runtime_configurable,
)
from managed_deepagents._ingress_runs import ingress_run_origin
from managed_deepagents._langsmith_env import resolve_server_api_key
from managed_deepagents._log import logger
from managed_deepagents._managed_composition import (
    assert_dynamic_memory_selection,
    snapshot_browser_selection,
    snapshot_managed_composition,
    snapshot_mcp_selection,
    snapshot_memory_selection,
    snapshot_sandbox_selection,
)
from managed_deepagents._managed_middleware import wrap_middleware_with_managed_runtime
from managed_deepagents._managed_tools import (
    ManagedSandboxBackend,
    ManagedServerRuntime,
    _ManagedExecutionRuntime,
    _ManagedReadRuntime,
    adapt_server_runtime,
    wrap_tools_with_managed_runtime,
)
from managed_deepagents._memory import (
    ManagedCompositeBackend as _ManagedCompositeBackend,
)
from managed_deepagents._memory import (
    managed_context_backend as _managed_context_backend,
)
from managed_deepagents._memory import (
    managed_context_permissions as _managed_context_permissions,
)
from managed_deepagents._memory import (
    managed_selected_skills_backend as _managed_selected_skills_backend,
)
from managed_deepagents._memory.assistant_memory import AssistantMemoryBackend
from managed_deepagents._memory.async_util import await_if_needed as _await_if_needed
from managed_deepagents._memory.context_io import (
    download_context_file as _download_context_file,
)
from managed_deepagents._memory.deps import (
    optional_runtime_symbols as _optional_runtime_symbols,
)
from managed_deepagents._memory.layers import (
    MemoryLayers,
    has_agent_memory_layer,
    user_memory_layer,
)
from managed_deepagents._memory.policy import (
    UserMemoryAccess,
    resolve_agent_memory_access,
    resolve_user_memory_access,
)
from managed_deepagents._memory.selected_skills import (
    SelectedSkillsBackend,
    resolve_selected_skills,
)
from managed_deepagents._memory.user_memory import UserMemoryBackend
from managed_deepagents._routes import Routes, mount_routes
from managed_deepagents._run_local import RunLocal, current_run_id
from managed_deepagents._telemetry.metadata import detect_run_identity
from managed_deepagents._telemetry.run import (
    MemoryObservations,
    RunConfiguration,
    SubagentRole,
    start_run,
)
from managed_deepagents._telemetry.run_wrapper import observe_run
from managed_deepagents.agent_entry import CachedAgent
from managed_deepagents.define_deep_agent import DeepAgentDefinition
from managed_deepagents.run_context import ManagedChannelContext, ManagedRunContext


class _Omitted:
    __slots__ = ()


_OMITTED = _Omitted()

_ResultT = TypeVar("_ResultT")

if TYPE_CHECKING:
    from deepagents import SubAgent
    from langchain.agents.middleware import AgentMiddleware
    from langgraph_sdk.runtime import ServerRuntime
    from langsmith.sandbox import Sandbox
    from langsmith.sandbox import SandboxClient as LangSmithSandboxClient

    from managed_deepagents._managed_tools import RuntimeBackendFactory
    from managed_deepagents._sandbox_proxy import SandboxProxyConfigSync
    from managed_deepagents.agent_entry import AgentEntry
    from managed_deepagents.define_browser import BrowserDefinition
    from managed_deepagents.define_deep_agent import DeepAgentSubAgent, DeepAgentTool
    from managed_deepagents.define_memory import MemoryDefinition, MemoryDefinitionLike
    from managed_deepagents.identity import (
        IdentityDefinitionLike,
    )
    from managed_deepagents.sandbox import SandboxDefinition


class ManagedRunConfig(RunnableConfig, total=False):
    """LangGraph runnable config used to scope the managed sandbox.

    Mirrors TypeScript ``ManagedRunConfig``: the native ``RunnableConfig`` plus
    the Agent Server ``context`` read by the managed runtime at invocation time.
    """

    context: object


__all__ = [
    "MANAGED_SKILLS_PATH",
    "RECIPE_SNAPSHOT_ENV",
    "build_managed_auth",
    "build_managed_http_app",
    "collect_channels",
    "collect_connectors",
    "compile_agent_factory_for_eval_async",
    "compile_managed_agent",
    "compile_managed_agent_async",
    "compile_managed_agent_for_eval",
    "has_sandbox_connectors",
    "load_connector_tools",
    "parent_run",
    "requirements_from_channels",
    "requirements_from_connectors",
    "run_connector_sandbox_hooks",
]


def _snapshot_factory_definition(selected: DeepAgentDefinition) -> DeepAgentDefinition:
    """Validate and copy a definition returned across the callback boundary."""
    try:
        config = dict(selected.config)
    except Exception:  # noqa: BLE001 - returned config is an untrusted callback value
        raise TypeError("agent factory returned an invalid definition") from None
    name = config.get("name")
    if not isinstance(name, str) or not name.strip():
        raise TypeError("agent definition must have a non-empty name")
    forbidden = {"backend", "store", "checkpointer", "system_prompt", "disable_memory"}
    if forbidden.intersection(config):
        raise ValueError("agent factory returned a managed runtime field")
    try:
        snapshot = snapshot_managed_composition(config)
    except Exception:  # noqa: BLE001 - returned config is an untrusted callback value
        raise TypeError("agent factory returned an invalid definition") from None
    selected_memory = snapshot.get("memory")
    if selected_memory is not None:
        assert_dynamic_memory_selection(cast("MemoryDefinition", selected_memory))
    return DeepAgentDefinition(snapshot)


async def resolve_agent_definition(
    entry: AgentEntry, runtime: ManagedServerRuntime
) -> DeepAgentDefinition:
    """Resolve one managed definition without exposing callback data in errors."""
    if isinstance(entry, DeepAgentDefinition):
        return entry
    if not callable(entry):
        raise TypeError("agent export must be a managed agent definition or factory entrypoint")

    try:
        selected = entry(runtime)
        if inspect.isawaitable(selected):
            selected = await selected
    except Exception:  # noqa: BLE001 - callback failures cross an untrusted boundary
        raise RuntimeError("agent factory failed") from None

    if not isinstance(selected, DeepAgentDefinition):
        raise TypeError("agent factory must return define_deep_agent(...)")
    return _snapshot_factory_definition(selected)


# Core framework packages are required for native authoring types. Optional
# provider integrations (for example, MCP and sandbox clients) remain lazy and
# are required only when a runtime path uses them.

#: Backend path the runtime mounts the project's skills at.
#:
#: Local/deploy route this to the Context Hub mock or repo; an eval trial resolves
#: it against the trial workspace, where the Harbor adapter has copied the
#: compiled project (so it reads the project's own ``skills/`` tree).
MANAGED_SKILLS_PATH = "/skills/"

# Keep in sync with MANAGED_DEEP_AGENT_INSTRUCTIONS in the TypeScript runtime.
MANAGED_DEEP_AGENT_INSTRUCTIONS = (
    "<managed_deep_agent>\n"
    "You are a Managed Deep Agent (MDA), built on LangChain's Deep Agents harness.\n"
    "</managed_deep_agent>"
)

#: Deployment secret naming the recipe snapshot baked at ``mda deploy``.
#: Mirrors TypeScript ``RECIPE_SNAPSHOT_ENV``.
RECIPE_SNAPSHOT_ENV = "MDA_SANDBOX_RECIPE_SNAPSHOT"

#: Full sandbox API endpoint resolved and owned by ``mda deploy``.
#: Mirrors TypeScript ``SANDBOX_API_ENDPOINT_ENV``.
SANDBOX_API_ENDPOINT_ENV = "MDA_SANDBOX_API_ENDPOINT"

#: Env var naming the workspace the CLI baked the recipe snapshot into.
#: ``mda deploy`` sets it on the deployment and ``mda dev`` stages it into the
#: local ``.env``. Sandboxes and snapshots are workspace-scoped, so the runtime
#: must send it too — an API key whose default workspace differs from this one
#: resolves ``snapshot_name`` in the wrong workspace and 404s on the recipe.
#: Mirrors TypeScript ``WORKSPACE_ID_ENV``.
WORKSPACE_ID_ENV = "LANGSMITH_WORKSPACE_ID"

#: Header the LangSmith APIs use to scope a request to one workspace.
_TENANT_HEADER = "X-Tenant-Id"

#: Author bake-base keys — deploy-time only; stripped from runtime create.
_BAKE_BASE_OPTION_KEYS = frozenset({"snapshot_name", "snapshot_id", "docker_image", "registry"})

#: Separator between the deployment name and the identity digest in a managed
#: sandbox name. Doubled so one deployment's prefix can never match another's
#: name: ``agent--<digest>`` is not matched by the ``agent-staging--`` prefix.
#: Mirrors the ``--u--`` / ``--t--`` convention used for Context Hub child repos,
#: and must stay in sync with ``SANDBOX_NAME_SEPARATOR`` in the CLI.
_SANDBOX_NAME_SEPARATOR = "--"

#: Hex characters of the identity digest kept in a sandbox name.
_SANDBOX_DIGEST_LENGTH = 12

#: Host sandbox-name limit.
_MAX_SANDBOX_NAME_LENGTH = 63
_MAX_PRIMARY_DEPLOYMENT_COMPONENT_LENGTH = (
    _MAX_SANDBOX_NAME_LENGTH - len(_SANDBOX_NAME_SEPARATOR) - _SANDBOX_DIGEST_LENGTH
)
_SANDBOX_DEPLOYMENT_DIGEST_LENGTH = 8

#: Sandbox statuses that can be adopted as-is.
_ADOPTABLE_SANDBOX_STATUS = frozenset({"ready", "running"})

#: Sandbox status for one that is stopped but restartable.
_STOPPED_SANDBOX_STATUS = "stopped"

#: Sandbox status for one still booting: adopted, and waited for on first use.
_PROVISIONING_SANDBOX_STATUS = "provisioning"

#: Create failures that mean the sandbox name is already taken.
_SANDBOX_NAME_CONFLICT_RE = re.compile(
    r"409|conflict|already exists|already in use|duplicate", re.IGNORECASE
)


class _ManagedSandboxEntry:
    """Cached sandbox plus per-thread connector sandbox sync state."""

    __slots__ = ("backend", "host_name", "sandbox_id", "selection_fingerprint", "synced_threads")

    def __init__(
        self,
        backend: SandboxBackendProtocol,
        host_name: str | None = None,
        sandbox_id: str | None = None,
        selection_fingerprint: str | None = None,
    ) -> None:
        self.backend = backend
        self.synced_threads: set[str] = set()
        #: LangSmith box name for this entry (deterministic or unique-suffixed).
        self.host_name = host_name
        self.sandbox_id = sandbox_id
        #: Options fingerprint of the dynamic selection this process created or adopted it with.
        self.selection_fingerprint = selection_fingerprint


class _SandboxClaim:
    """A sandbox adopted or created, but maybe still booting and not yet used."""

    __slots__ = ("adopted", "client", "host_name", "sandbox")

    def __init__(
        self,
        client: LangSmithSandboxClient,
        sandbox: Sandbox,
        *,
        adopted: bool,
        host_name: str | None,
    ) -> None:
        self.client = client
        self.sandbox = sandbox
        self.adopted = adopted
        self.host_name = host_name


#: Created sandboxes, keyed by thread and any dynamic selection's mounts,
#: reused for the lifetime of this runtime process. Storing the entry dedupes
#: concurrent runs. Provisioning (``setup.sh``) happens at deploy bake, not on
#: thread create.
_managed_sandboxes: dict[str, _ManagedSandboxEntry] = {}
#: Sandboxes ``runtime.backend.aopen(wait=False)`` claimed, by the same key, until their
#: first use waits for them to boot and moves them to ``_managed_sandboxes``.
_claimed_sandboxes: dict[str, _SandboxClaim] = {}
#: Host box names that must not be re-adopted after invalidate until a fresh
#: create claims them (or a unique suffix replaces them). Covers delete lag.
_invalidated_sandbox_names: set[str] = set()
#: Guards the cache / per-key lock maps only — never held across cold create.
_managed_sandbox_lock = threading.Lock()
#: One lock per scope key so concurrent resolves for the *same* sandbox share a
#: single provision, while different keys stay parallel (Host workers must not
#: block each other on unrelated cold boxes).
_managed_sandbox_key_locks: dict[str, threading.Lock] = {}


def _sandbox_key_lock(key: str) -> threading.Lock:
    """Return the per-scope lock, creating it on first use."""
    with _managed_sandbox_lock:
        lock = _managed_sandbox_key_locks.get(key)
        if lock is None:
            lock = threading.Lock()
            _managed_sandbox_key_locks[key] = lock
        return lock


def _peek_managed_host_name(key: str) -> str | None:
    """Host box name currently cached for ``key``, if any."""
    with _managed_sandbox_lock:
        entry = _managed_sandboxes.get(key)
        return entry.host_name if entry is not None else None


def _bake_base(sandbox: SandboxDefinition | None) -> tuple[str, str] | None:
    """The ``(option, value)`` bake base a sandbox sets, if any."""
    if sandbox is None:
        return None
    for key in ("snapshot_id", "snapshot_name", "docker_image"):
        value = _string_option(sandbox.options.get(key))
        if value:
            return key, value
    return None


def _inherit_setup_recipe(
    selected: SandboxDefinition,
    declared: SandboxDefinition | None,
) -> SandboxDefinition:
    """Keep a factory's sandbox selection on the ``setup.sh`` recipe snapshot.

    The recipe is baked on the base declared in ``sandbox/__init__.py``, or on
    Host's default image when none is declared. A selection without a base, or
    with that same base, clones the recipe. Any other base was never baked, so
    the run fails instead of starting a sandbox without ``setup.sh``.
    """
    if not _string_option(os.environ.get(RECIPE_SNAPSHOT_ENV)):
        return selected
    base = _bake_base(selected)
    if base is None:
        return selected
    declared_base = _bake_base(declared)
    if base == declared_base:
        from managed_deepagents.sandbox import SandboxDefinition  # noqa: PLC0415

        return SandboxDefinition(
            {
                key: value
                for key, value in selected.options.items()
                if key not in _BAKE_BASE_OPTION_KEYS
            }
        )
    baked_on = (
        f"{declared_base[0]} {json.dumps(declared_base[1])}"
        if declared_base
        else "the default sandbox image"
    )
    raise TypeError(
        f"sandbox/setup.sh is baked on {baked_on}, but this run selected "
        f"{base[0]} {json.dumps(base[1])}. Remove {base[0]} from the selected sandbox, "
        "or declare the same base in sandbox/__init__.py."
    )


def _sandbox_create_kwargs(
    sandbox: SandboxDefinition,
    selection: _SandboxSelection | None = None,
) -> dict[str, object]:
    """Options for ``create_sandbox``."""
    create_kwargs = {
        key: value
        for key, value in sandbox.options.items()
        if key
        not in {
            "scope",
            "api_key",
            "default_timeout",
            "template_name",
            *_BAKE_BASE_OPTION_KEYS,
        }
    }
    from managed_deepagents._sandbox_proxy import static_sandbox_proxy_config  # noqa: PLC0415

    if "proxy_config" in create_kwargs:
        create_kwargs["proxy_config"] = static_sandbox_proxy_config(create_kwargs["proxy_config"])
    recipe = _string_option(os.environ.get(RECIPE_SNAPSHOT_ENV))
    snapshot_id = sandbox.options.get("snapshot_id")
    snapshot_name = sandbox.options.get("snapshot_name")
    if selection is not None and snapshot_id:
        create_kwargs["snapshot_id"] = snapshot_id
    elif selection is not None and snapshot_name:
        create_kwargs["snapshot_name"] = snapshot_name
    elif recipe:
        create_kwargs["snapshot_name"] = recipe
    return create_kwargs


class _SandboxClientKwargs(TypedDict, total=False):
    """Subset of ``SandboxClient`` constructor keywords the runtime pins."""

    api_endpoint: str
    api_key: str
    headers: dict[str, str]


def _sandbox_client_kwargs(sandbox: SandboxDefinition) -> _SandboxClientKwargs:
    """Client kwargs pinning the API key and the workspace holding the recipe."""
    kwargs: _SandboxClientKwargs = {}
    api_endpoint = _configured_sandbox_api_endpoint()
    if api_endpoint:
        kwargs["api_endpoint"] = api_endpoint
    api_key = _string_option(sandbox.options.get("api_key")) or _string_option(
        resolve_server_api_key()
    )
    if api_key:
        kwargs["api_key"] = api_key
    workspace_id = _string_option(os.environ.get(WORKSPACE_ID_ENV))
    if workspace_id:
        kwargs["headers"] = {_TENANT_HEADER: workspace_id}
    return kwargs


def _configured_sandbox_api_endpoint() -> str | None:
    """Return the validated deploy-owned sandbox endpoint, when configured."""
    raw = _string_option(os.environ.get(SANDBOX_API_ENDPOINT_ENV))
    if raw is None:
        return None
    try:
        parsed = urlsplit(raw)
        hostname = parsed.hostname
    except ValueError:
        parsed = None
        hostname = None
    if (
        parsed is None
        or parsed.scheme not in {"http", "https"}
        or hostname is None
        or parsed.username is not None
        or parsed.password is not None
        or parsed.query
        or parsed.fragment
    ):
        raise RuntimeError(
            f"{SANDBOX_API_ENDPOINT_ENV} must be an HTTP(S) URL without credentials, "
            "query, or fragment"
        )
    return raw.rstrip("/")


def _sandbox_client_for(sandbox: SandboxDefinition) -> LangSmithSandboxClient:
    """Build a LangSmith sandbox client using the definition's API key."""
    # Loaded lazily through the optional-provider boundary below.
    sandbox_client_cls = cast("type[LangSmithSandboxClient] | None", SandboxClient)
    if sandbox_client_cls is None:  # pragma: no cover - depends on runtime deps
        raise RuntimeError("MDA requires `langsmith` with sandbox support to create sandboxes.")
    return sandbox_client_cls(**_sandbox_client_kwargs(sandbox))


def _sandbox_name_blocked(name: str) -> bool:
    with _managed_sandbox_lock:
        return name in _invalidated_sandbox_names


def _unblock_sandbox_name(name: str) -> None:
    with _managed_sandbox_lock:
        _invalidated_sandbox_names.discard(name)


def _sandbox_handle_name(handle: object) -> str | None:
    """Read ``name`` from an SDK sandbox handle (object or mapping)."""
    name = _string_option(getattr(handle, "name", None))
    if name is not None:
        return name
    if isinstance(handle, Mapping):
        return _string_option(handle.get("name"))
    return None


def _sandbox_handle_id(handle: object) -> str | None:
    """Read ``id`` from an SDK sandbox handle (object or mapping)."""
    value = getattr(handle, "id", None)
    if value is None and isinstance(handle, Mapping):
        value = handle.get("id")
    if value is None:
        return None
    text = str(value).strip()
    return text or None


(SandboxClient,) = _optional_runtime_symbols("langsmith.sandbox", "SandboxClient")


class _ManagedCompileOptions(TypedDict):
    context_root: str | None
    context_repo: str | None
    system_prompt: str | None
    has_skills: bool
    sandbox: SandboxDefinition | None
    sandbox_selection: _SandboxSelection | None
    connectors: list[Connector] | None
    channels: list[Channel] | None
    identity: IdentityDefinitionLike | None
    memory: MemoryDefinitionLike | None
    browser: BrowserDefinition | None
    trial_root_dir: str | None
    subagent_role: SubagentRole


def _internal_server_runtime(
    config: ManagedRunConfig | None,
    context: object,
    is_run: bool,
) -> ManagedServerRuntime:
    """Create an SDK-compatible runtime for direct internal/eval callers."""
    # The SDK exposes no public constructor for internal/eval calls.
    from langgraph.store.base import BaseStore  # noqa: PLC0415 - runtime dependency
    from langgraph.store.memory import InMemoryStore  # noqa: PLC0415 - runtime dependency
    from langgraph_sdk.auth.types import BaseUser  # noqa: PLC0415

    configurable = resolve_runtime_configurable(config)
    candidate = _field(configurable, "langgraph_auth_user")
    user = candidate if isinstance(candidate, BaseUser) else None
    candidate_store = _field(configurable, "__pregel_store")
    store = candidate_store if isinstance(candidate_store, BaseStore) else InMemoryStore()
    if is_run:
        return _ManagedExecutionRuntime(
            access_context="threads.create_run",
            user=user,
            store=store,
            context=cast("dict[str, object]", context if context is not None else {}),
        )
    return _ManagedReadRuntime(access_context="assistants.read", user=user, store=store)


def compile_managed_agent(
    entry: AgentEntry,
    config: ManagedRunConfig | None = None,
    *,
    context_root: str | None = None,
    context_repo: str | None = None,
    system_prompt: str | None = None,
    has_skills: bool = False,
    sandbox: SandboxDefinition | None = None,
    sandbox_setup: bool = False,
    connectors: list[Connector] | None = None,
    channels: list[Channel] | None = None,
    identity: IdentityDefinitionLike | None = None,
    memory: MemoryDefinitionLike | None = None,
    browser: BrowserDefinition | None = None,
    trial_root_dir: str | None = None,
    runtime: ServerRuntime[ManagedRunContext] | None = None,
    run_context: object = None,
    is_run: bool = True,
    report_telemetry: bool = True,
) -> CompiledAgent:
    """Compile one run; direct callers create a fresh graph for each execution."""
    return _await_if_needed(
        compile_managed_agent_async(
            entry,
            config,
            context_root=context_root,
            context_repo=context_repo,
            system_prompt=system_prompt,
            has_skills=has_skills,
            sandbox=sandbox,
            sandbox_setup=sandbox_setup,
            connectors=connectors,
            channels=channels,
            identity=identity,
            memory=memory,
            browser=browser,
            trial_root_dir=trial_root_dir,
            runtime=runtime,
            run_context=run_context,
            is_run=is_run,
            report_telemetry=report_telemetry,
        )
    )


@asynccontextmanager
async def parent_run(config: Mapping[str, object]) -> AsyncGenerator[None]:
    """Set up a run for async subagents: verify its lead, then nest its trace.

    The generated entry holds this open for the whole run. For a run that
    deepagents launched from another run, the Agent Server is asked once whether
    this run's caller may access the launching (lead) thread, under MDA's usual
    thread ownership. Only then may the run share the lead's sandbox, and read
    the lead's thread record as its own ``runtime.thread``.
    """
    from managed_deepagents._managed_thread import _verified_lead_metadata  # noqa: PLC0415

    lead = await _accessible_lead_thread(config)
    token = _VERIFIED_LEAD_THREAD.set(lead[0] if lead is not None else None)
    metadata_token = _verified_lead_metadata.set(lead)
    try:
        with _parent_trace(config):
            yield
    finally:
        # The Agent Server enters and exits the entry in one task; tolerate otherwise.
        with suppress(ValueError):
            _verified_lead_metadata.reset(metadata_token)
        with suppress(ValueError):
            _VERIFIED_LEAD_THREAD.reset(token)


@contextmanager
def _parent_trace(config: Mapping[str, object]) -> Generator[None]:
    """Nest this run's trace under the async subagent call that launched it.

    Only acts on runs deepagents marked as launched by an async subagent tool,
    and only when tracing is on.
    """
    configurable = config.get("configurable")
    parent = _launching_parent(configurable) if isinstance(configurable, Mapping) else None
    if parent is None or not tracing_is_enabled():
        yield
        return
    with tracing_context(parent=parent):
        yield


def _launching_parent(configurable: Mapping[str, object]) -> RunTree | None:
    """Rebuild the launching span from the trace headers the Agent Server kept, if marked."""
    trace = configurable.get("langsmith-trace")
    metadata = configurable.get("langsmith-metadata")
    if not isinstance(trace, str) or not trace or not isinstance(metadata, Mapping):
        return None
    if metadata.get(_NEST_UNDER_PARENT) is not True:
        return None
    project = configurable.get("langsmith-project")
    baggage = f"langsmith-project={quote(project)}" if isinstance(project, str) else ""
    try:
        return RunTree.from_headers({"langsmith-trace": trace, "baggage": baggage})
    except ValueError:
        logger.warning("Ignoring a malformed langsmith-trace; the run keeps its own trace")
        return None


async def _accessible_lead_thread(
    config: Mapping[str, object],
) -> tuple[str, Mapping[str, object]] | None:
    """Return the lead's thread and its metadata when this run's caller owns it, else ``None``.

    Reads the thread in process under the caller's identity, then requires its
    ``owner`` to be the caller's owner key, MDA's rule for changing a thread.
    Being able to read it isn't enough: Studio callers can read every thread.
    A thread without an owner (no managed identity) only needs to be readable.
    """
    lead_thread = _lead_thread(config)
    if lead_thread is None:
        return None
    try:
        thread = await get_client().threads.get(lead_thread)
    except Exception:  # noqa: BLE001 — missing or not allowed: keep this run's own sandbox
        logger.warning("lead thread not accessible to this run; using its own sandbox")
        return None
    metadata = thread.get("metadata") or {}
    owner = metadata.get("owner")
    if owner is not None and owner != _caller_owner_key(config):
        logger.warning("lead thread belongs to another caller; using this run's own sandbox")
        return None
    return lead_thread, metadata


def _caller_owner_key(config: Mapping[str, object]) -> str | None:
    """The thread owner key MDA stamps for this run's caller, if it's authenticated."""
    from managed_deepagents._identity_auth import _thread_owner_key  # noqa: PLC0415

    configurable = resolve_runtime_configurable(config)
    user = configurable.get("langgraph_auth_user") if configurable is not None else None
    return _thread_owner_key(user) if user is not None else None


async def compile_managed_agent_async(
    entry: AgentEntry,
    config: ManagedRunConfig | None = None,
    *,
    context_root: str | None = None,
    context_repo: str | None = None,
    system_prompt: str | None = None,
    has_skills: bool = False,
    sandbox: SandboxDefinition | None = None,
    sandbox_setup: bool = False,
    connectors: list[Connector] | None = None,
    channels: list[Channel] | None = None,
    identity: IdentityDefinitionLike | None = None,
    memory: MemoryDefinitionLike | None = None,
    browser: BrowserDefinition | None = None,
    trial_root_dir: str | None = None,
    runtime: ServerRuntime[ManagedRunContext] | None = None,
    run_context: object = None,
    is_run: bool = True,
    report_telemetry: bool = True,
    async_subagent_graphs: Mapping[str, str] | None = None,
    async_subagent: str | None = None,
) -> CompiledAgent:
    """Resolve one entry and compile it with the current managed run context.

    Generated entries pass `async_subagent_graphs` to the lead, and
    `async_subagent` to build that async subagent's own graph instead.
    """
    timing = GraphBuildTiming()
    trusted_assistant_id = None
    if runtime is not None and runtime.execution_runtime is not None:
        candidate = (config or {}).get("metadata", {}).get("assistant_id")
        if isinstance(candidate, str) and candidate.strip():
            trusted_assistant_id = candidate.strip()
    if runtime is not None:
        execution = runtime.execution_runtime
        is_run = execution is not None
        run_context = execution.context if execution is not None else None
    factory_runtime = (
        runtime if runtime is not None else _internal_server_runtime(config, run_context, is_run)
    )
    from managed_deepagents._run_input import execution_context, run_thread  # noqa: PLC0415

    register_channel_messaging(channels or [])
    binding, authored_context, _ = (
        execution_context(run_context, config, None) if is_run else (None, run_context, None)
    )
    factory_runtime = adapt_server_runtime(
        factory_runtime,
        authored_context,
        run_thread(binding, config, None).thread if is_run else None,
    )
    factory_entry = callable(entry)
    factory_inspection = factory_entry and not is_run
    cached_digest: str | None = None
    with timing.phase("factory"):
        if isinstance(entry, CachedAgent):
            definition, cached_digest = await _CachedDefinitions.resolve(entry, factory_runtime)
        else:
            definition = await resolve_agent_definition(entry, factory_runtime)
    definition = _select_async_subagent_graph(definition, async_subagent_graphs, async_subagent)
    agent = await _compile_resolved_managed_agent_async(
        definition,
        config,
        context_root=context_root,
        context_repo=context_repo,
        system_prompt=system_prompt,
        has_skills=has_skills,
        sandbox=sandbox,
        sandbox_setup=sandbox_setup,
        connectors=connectors,
        channels=channels,
        identity=identity,
        memory=memory,
        browser=browser,
        trial_root_dir=trial_root_dir,
        run_context=run_context,
        is_run=is_run,
        report_telemetry=report_telemetry,
        skip_factory_inspection_tools=factory_inspection,
        subagent_role="lead" if async_subagent is None else "async_subagent",
        factory_entry=factory_entry,
        trusted_assistant_id=trusted_assistant_id,
        timing=timing,
        cached_entry=entry if isinstance(entry, (CachedAgent, DeepAgentDefinition)) else None,
        cached_graph="lead" if async_subagent is None else f"subagent:{async_subagent}",
        cached_digest=_STATIC_DIGEST if isinstance(entry, DeepAgentDefinition) else cached_digest,
        cached_options=_identity_key(
            context_root,
            context_repo,
            system_prompt,
            has_skills,
            sandbox,
            sandbox_setup,
            tuple(connectors or ()),
            tuple(channels or ()),
            identity,
            memory,
            browser,
            trial_root_dir,
            tuple(sorted((async_subagent_graphs or {}).items())),
        ),
    )
    timing.log(kind="run" if is_run else "read", run_id=_platform_run_id(config))
    return agent


def _select_async_subagent_graph(
    definition: DeepAgentDefinition,
    async_subagent_graphs: Mapping[str, str] | None,
    async_subagent: str | None,
) -> DeepAgentDefinition:
    if GENERAL_PURPOSE in (async_subagent_graphs or {}) or async_subagent == GENERAL_PURPOSE:
        definition = with_async_general_purpose(definition)
    if async_subagent is not None:
        return async_subagent_definition(definition, async_subagent)
    return route_async_subagents(definition, async_subagent_graphs or {})


async def _compile_resolved_managed_agent_async(
    definition: DeepAgentDefinition,
    config: ManagedRunConfig | None = None,
    *,
    context_root: str | None = None,
    context_repo: str | None = None,
    system_prompt: str | None = None,
    has_skills: bool = False,
    sandbox: SandboxDefinition | None = None,
    sandbox_setup: bool = False,
    connectors: list[Connector] | None = None,
    channels: list[Channel] | None = None,
    identity: IdentityDefinitionLike | None = None,
    memory: MemoryDefinitionLike | None = None,
    browser: BrowserDefinition | None = None,
    trial_root_dir: str | None = None,
    run_context: object = None,
    is_run: bool = True,
    report_telemetry: bool = True,
    skip_factory_inspection_tools: bool = False,
    factory_entry: bool = False,
    subagent_role: SubagentRole = "lead",
    timing: GraphBuildTiming,
    trusted_assistant_id: str | None = None,
    cached_entry: object | None = None,
    cached_graph: str | None = None,
    cached_digest: str | None = None,
    cached_options: tuple[object, ...] = (),
) -> CompiledAgent:
    """Select native context schema and memory access for a resolved definition.

    ``cached_entry`` is set when the entry is a static definition or a
    ``CachedAgent``. In that case the compiled graph is cached in
    ``_CachedGraphs`` and reused by later runs and reads, from any thread or caller.
    Plain factories compile on every access.
    """
    started_monotonic_ms = time.monotonic() * 1000

    run_connectors = _select_run_connectors(definition.config, connectors)
    run_sandbox = (
        None if trial_root_dir is not None else _select_run_sandbox(definition.config, sandbox)
    )
    sandbox_selection = (
        _sandbox_selection(run_sandbox)
        if factory_entry and run_sandbox is not None and "sandbox" in definition.config
        else None
    )
    if run_sandbox is not None and sandbox_selection is not None and is_run and sandbox_setup:
        run_sandbox = _inherit_setup_recipe(run_sandbox, sandbox)
    # Eval builds ship no browser, like no nested sandbox.
    run_browser = (
        None if trial_root_dir is not None else _select_run_browser(definition.config, browser)
    )
    register_channel_messaging(channels or [])
    memory_selected_by_dynamic_resolver = "memory" in definition.config
    run_memory = (
        (
            None
            if definition.config["memory"] is None
            else snapshot_memory_selection(definition.config["memory"])
        )
        if memory_selected_by_dynamic_resolver
        else memory
    )
    options: _ManagedCompileOptions = {
        "context_root": context_root,
        "context_repo": context_repo,
        "system_prompt": system_prompt,
        "has_skills": has_skills,
        "sandbox": run_sandbox,
        "sandbox_selection": sandbox_selection,
        "connectors": run_connectors,
        "channels": channels,
        "identity": identity,
        "memory": run_memory,
        "browser": run_browser,
        "trial_root_dir": trial_root_dir,
        "subagent_role": subagent_role,
    }
    context_schema = definition.config.get("context_schema")
    declared_memory_layers = _declared_memory_layers(run_memory)
    from managed_deepagents._run_input import (  # noqa: PLC0415
        ManagedCompiledAgent,
        is_channel_execution,
    )

    policy_schema = (
        ManagedChannelContext
        if is_run and is_channel_execution(resolve_runtime_configurable(config))
        else context_schema
    )
    allow_agent = False
    allow_assistant = False
    user_access = UserMemoryAccess(denied_reason="no_context")
    if is_run:
        agent_layer = next(
            (layer for layer in declared_memory_layers if layer["type"] == "agent"), None
        )
        # Memory policies keep their public channel field after routing normalization.
        policy_context = _policy_run_context(run_context, config)
        if policy_schema is ManagedChannelContext:
            policy_context = _with_thread_origin(policy_context, config)
        allow_agent = await resolve_agent_memory_access(agent_layer, policy_context, policy_schema)
        assistant_layer = next(
            (layer for layer in declared_memory_layers if layer["type"] == "assistant"), None
        )
        allow_assistant = await resolve_agent_memory_access(
            assistant_layer, policy_context, policy_schema
        )
        if allow_assistant and trusted_assistant_id is None:
            raise ValueError("Assistant memory requires a trusted runtime assistant identity")
        user_access = await resolve_user_memory_access(
            user_memory_layer(declared_memory_layers),
            config,
            policy_context,
            policy_schema,
            selected_by_dynamic_resolver=memory_selected_by_dynamic_resolver,
        )
    # Cache key for _CachedGraphs, or None for a plain factory, which compiles on
    # every access.
    # - cached_entry: the static definition or cached agent itself, so two
    #   entries with equal params (or none) never share a graph.
    # - cached_graph: which graph is being built, "lead" or "subagent:<name>". One
    #   entry can produce several graphs, so the params alone aren't enough.
    # - cached_digest: the SHA-256 digest of the cached agent's params JSON (a
    #   constant for a static definition).
    # - cached_options: the compile options, compared by identity. The generated
    #   entry passes the same declarations on every access; in-process callers
    #   such as eval trials may not, and must not share a graph.
    key = (
        (_ByIdentity(cached_entry), cached_graph, cached_digest, cached_options)
        if cached_entry is not None and cached_graph is not None and cached_digest is not None
        else None
    )
    # A run's graph bakes in which memory layers are mounted, so a cached graph is
    # reused by a run only if it was built with the same layers allowed. Which user
    # the user layer reads is not part of it: the backend resolves the caller per
    # call and checks them against the user this call was approved for
    # (APPROVED_USER), so one graph serves every user. Reads have no caller, so
    # their policy is None and they can reuse any cached graph.
    policy = (allow_agent, allow_assistant, user_access.user_id is not None) if is_run else None

    async def compile_graph() -> _BuiltGraph:
        agent, configuration = await asyncio.to_thread(
            _compile_managed_agent,
            definition,
            # A cached graph is reused across runs, so it must not be compiled with
            # this run's config. Per-run values, such as the thread whose sandbox to
            # use, are read from the run in progress when each call executes.
            None if key is not None else config,
            **options,
            allow_agent=allow_agent,
            allow_assistant=allow_assistant,
            user_access=user_access,
            declared_memory_layers=declared_memory_layers,
            inspection=not is_run,
            skip_factory_inspection_tools=skip_factory_inspection_tools,
            context_schema=context_schema,
            timing=timing,
        )
        if isinstance(agent, CompiledAgent):
            agent.__class__ = ManagedCompiledAgent
        return _BuiltGraph(policy=policy, agent=agent, configuration=configuration)

    if key is None:
        timing.set_cache("off")
        built = await compile_graph()
    else:
        cached = _CachedGraphs.built(key, policy)
        if cached is not None:
            timing.set_cache("hit")
            built = cached
        else:
            built, compiled_here = await _CachedGraphs.compile_once(key, policy, compile_graph)
            timing.set_cache("miss" if compiled_here else "hit")
    return _for_call(
        built,
        config,
        run_context=run_context,
        is_run=is_run,
        report_telemetry=report_telemetry,
        started_monotonic_ms=started_monotonic_ms,
        user_access=user_access,
        approved_assistant=trusted_assistant_id if allow_assistant else None,
    )


def _for_call(
    built: _BuiltGraph,
    config: ManagedRunConfig | None,
    *,
    run_context: object,
    is_run: bool,
    report_telemetry: bool,
    started_monotonic_ms: float,
    user_access: UserMemoryAccess | None = None,
    approved_assistant: str | None = None,
) -> CompiledAgent:
    """Prepare a compiled graph for this call: telemetry and this run's config.

    Both are applied to a copy returned by ``with_config`` / ``observe_run``, so the
    graph in ``built`` is never modified and stays safe to share across runs.
    """
    from managed_deepagents._run_input import (  # noqa: PLC0415
        ManagedCompiledAgent,
        execution_context,
        graph_default_config,
    )

    agent = built.agent
    if not isinstance(agent, CompiledAgent):
        return agent
    if report_telemetry and built.configuration is not None:
        origin = ingress_run_origin(config.get("metadata") if config else None)
        agent = observe_run(
            agent,
            start_run(
                detect_run_identity(
                    caller=build_runtime_identity(resolve_runtime_configurable(config)),
                    is_run=is_run,
                ),
                replace(
                    built.configuration,
                    channel=_detect_run_channel(config),
                    provider_event_type=origin["provider_event_type"],
                    user_resolution=origin["user_resolution"],
                    # Graphs are shared across users, so this run's denial reason
                    # is its own, not the one the graph was compiled with.
                    memory=built.configuration.memory
                    if user_access is None
                    else {
                        **built.configuration.memory,
                        "user_denied_reason": user_access.denied_reason,
                    },
                ),
                run_id=_platform_run_id(config),
                thread_id=_thread_id_of(config),
                started_monotonic_ms=started_monotonic_ms,
            ),
        )
    defaults = graph_default_config(config)
    if is_run:
        _, _, routing = execution_context(run_context, config, None)
        if routing is not None:
            # Agent Server filters context against the authored schema after
            # this factory returns. Retain managed routing for graph execution.
            defaults["configurable"] = {**defaults.get("configurable", {}), **routing}
    agent = agent.with_config(defaults)
    if is_run and user_access is not None and isinstance(agent, ManagedCompiledAgent):
        # The user this run may reach user memory as: from the run's resolved
        # access, never from anything the caller sends.
        agent.approved_user = user_access.user_id
        agent.approved_assistant = approved_assistant
    return agent


# (entry, graph, params digest, compile options); see _compile_resolved_managed_agent_async.
_GraphKey = tuple[object, str, str, tuple[object, ...]]
# (agent, assistant, user memory allowed) for a run; None for a read.
_Policy = tuple[bool, bool, bool] | None


@dataclass(frozen=True)
class _BuiltGraph:
    """A compiled graph, before any single call's telemetry or config is applied."""

    # The memory layers a run's graph was compiled with: (agent memory allowed,
    # user memory allowed). None when the graph was compiled for a read.
    policy: _Policy
    agent: CompiledAgent
    # Telemetry fields known at compile time. _for_call fills in each call's own
    # fields (channel, ingress origin) and reports it.
    configuration: RunConfiguration | None


# The params digest of a static definition: it has no params, so one graph per entry.
_STATIC_DIGEST = hashlib.sha256(b"static").hexdigest()


class _ByIdentity:
    """A cache-key part that matches only the same object.

    Holds a strong reference, so the object's id can't be reused by another object
    while the key is cached.
    """

    __slots__ = ("value",)

    def __init__(self, value: object) -> None:
        self.value = value

    def __hash__(self) -> int:
        return id(self.value)

    def __eq__(self, other: object) -> bool:
        return isinstance(other, _ByIdentity) and other.value is self.value


def _identity_key(*values: object) -> tuple[object, ...]:
    """Key parts for ``values``: strings, numbers and None by value, anything else by identity."""
    parts: list[object] = []
    for value in values:
        if value is None or isinstance(value, (str, int, float, bool)):
            parts.append(value)
        elif isinstance(value, tuple):
            parts.append(_identity_key(*value))
        else:
            parts.append(_ByIdentity(value))
    return tuple(parts)


# Maximum entries in each of _CachedDefinitions and _CachedGraphs, per process.
# When full, the least recently used entry is dropped.
_CACHED_GRAPHS_KEPT = 32


class _CachedDefinitions:
    """Cache of agent definitions built by cached agents.

    Keyed by (agent, params digest). ``build`` only sees its params, so the same
    params always produce the same definition, and ``build`` runs once per key.
    """

    _built: ClassVar[OrderedDict[tuple[CachedAgent[Any], str], DeepAgentDefinition]] = OrderedDict()

    @classmethod
    async def resolve(
        cls, entry: CachedAgent[Any], runtime: ManagedServerRuntime
    ) -> tuple[DeepAgentDefinition, str]:
        """Return the definition and params digest for this access.

        Calls the agent's ``keyed_by`` every time, and its ``build`` only on a cache miss.
        """
        try:
            resolved = await entry.resolve(runtime)
        except Exception:  # noqa: BLE001 - callback failures cross an untrusted boundary
            raise RuntimeError("agent factory failed") from None
        key = (entry, resolved.digest)
        definition = cls._built.get(key)
        if definition is None:
            try:
                selected = entry.build(resolved)
            except Exception:  # noqa: BLE001 - callback failures cross an untrusted boundary
                raise RuntimeError("agent factory failed") from None
            if not isinstance(selected, DeepAgentDefinition):
                raise TypeError("agent factory must return define_deep_agent(...)")
            definition = _snapshot_factory_definition(selected)
            cls._built[key] = definition
        cls._built.move_to_end(key)
        while len(cls._built) > _CACHED_GRAPHS_KEPT:
            cls._built.popitem(last=False)
        return definition, resolved.digest


class _CachedGraphs:
    """Cache of compiled graphs, keyed by (entry, graph, digest, compile options).

    Only static definitions' and cached agents' graphs are cached. Their definitions
    don't depend on the run, so they hold nothing specific to one run, thread or caller.
    """

    _built: ClassVar[OrderedDict[_GraphKey, _BuiltGraph]] = OrderedDict()
    # Compiles in progress, so concurrent misses on one key share one compile. Keyed
    # by event loop too, since a task can only be awaited on its own loop.
    _pending: ClassVar[
        dict[tuple[_GraphKey, _Policy, asyncio.AbstractEventLoop], asyncio.Task[_BuiltGraph]]
    ] = {}

    @classmethod
    def built(cls, key: _GraphKey, policy: _Policy) -> _BuiltGraph | None:
        """Return the cached graph for ``key``, or None on a miss.

        A read (``policy`` None) accepts any cached graph. A run only accepts one
        compiled with the same memory access ``policy``.
        """
        built = cls._built.get(key)
        if built is None or (policy is not None and built.policy != policy):
            return None
        cls._built.move_to_end(key)
        return built

    @classmethod
    async def compile_once(
        cls, key: _GraphKey, policy: _Policy, compile_graph: Callable[[], Awaitable[_BuiltGraph]]
    ) -> tuple[_BuiltGraph, bool]:
        """Compile and keep the graph for ``key``, or wait for a compile already running.

        Returns the graph and whether this call compiled it. A failed compile is not
        kept, so the next access tries again.
        """
        loop = asyncio.get_running_loop()
        pending_key = (key, policy, loop)
        task = cls._pending.get(pending_key)
        compiled_here = task is None
        if task is None:

            async def compile_and_keep() -> _BuiltGraph:
                built = await compile_graph()
                cls.keep(key, built)
                return built

            task = asyncio.ensure_future(compile_and_keep())
            cls._pending[pending_key] = task

            def done(finished: asyncio.Task[_BuiltGraph]) -> None:
                cls._pending.pop(pending_key, None)
                if not finished.cancelled():
                    finished.exception()  # mark retrieved when nobody is waiting

            task.add_done_callback(done)
        # A caller that is cancelled stops waiting; the compile carries on for others.
        return await asyncio.shield(task), compiled_here

    @classmethod
    def keep(cls, key: _GraphKey, built: _BuiltGraph) -> None:
        kept = cls._built.get(key)
        # Don't let a read's graph replace a cached one: a run's graph serves both
        # runs and reads, while a read's graph can't serve runs.
        if built.policy is None and kept is not None:
            return
        cls._built[key] = built
        cls._built.move_to_end(key)
        while len(cls._built) > _CACHED_GRAPHS_KEPT:
            cls._built.popitem(last=False)


def _select_run_connectors(
    config: Mapping[str, object],
    discovered: list[Connector] | None,
) -> list[Connector] | None:
    """Replace discovered MCP definitions while preserving other connectors."""
    if "mcp" not in config:
        return discovered

    selected = () if config["mcp"] is None else snapshot_mcp_selection(config["mcp"])
    return [
        *(connector for connector in discovered or [] if connector.kind != "mcp_servers"),
        *selected,
    ]


def _select_run_sandbox(
    config: Mapping[str, object],
    discovered: SandboxDefinition | None,
) -> SandboxDefinition | None:
    """Replace or disable the discovered sandbox for this run."""
    if "sandbox" not in config:
        return discovered
    return snapshot_sandbox_selection(config["sandbox"])


def _select_run_browser(
    config: Mapping[str, object],
    declared: BrowserDefinition | None,
) -> BrowserDefinition | None:
    """Keep, disable, or replace ``browser.py``'s browser for this run."""
    if "browser" not in config:
        return declared
    selected = snapshot_browser_selection(config["browser"])
    if selected is not None and declared is None:
        msg = (
            "The agent factory selected a browser, but the project has no browser.py. "
            "Declare `browser = define_browser()` there so the deployment installs Stagehand."
        )
        raise ValueError(msg)
    return selected


def _compile_managed_agent(
    definition: DeepAgentDefinition,
    config: ManagedRunConfig | None = None,
    *,
    context_root: str | None = None,
    context_repo: str | None = None,
    system_prompt: str | None = None,
    has_skills: bool = False,
    sandbox: SandboxDefinition | None = None,
    sandbox_selection: _SandboxSelection | None = None,
    connectors: list[Connector] | None = None,
    channels: list[Channel] | None = None,
    identity: IdentityDefinitionLike | None = None,
    memory: MemoryDefinitionLike | None = None,
    browser: BrowserDefinition | None = None,
    trial_root_dir: str | None = None,
    user_access: UserMemoryAccess,
    allow_agent: bool,
    allow_assistant: bool,
    declared_memory_layers: MemoryLayers,
    inspection: bool = False,
    skip_factory_inspection_tools: bool = False,
    context_schema: object = None,
    subagent_role: SubagentRole = "lead",
    timing: GraphBuildTiming,
) -> tuple[CompiledAgent, RunConfiguration]:
    """Compile the definition and return it with its compile-time telemetry fields.

    Per-call telemetry and config are applied later by ``_for_call``.
    """
    # Resolution + thread/store scope run in the generated custom-auth handler
    # (``build_managed_auth``). When identity is declared, the seam also surfaces
    # ``runtime.server_info.principal`` to authored + connector tools (below),
    # projected from the trusted ``langgraph_auth_user``.
    merged: dict[str, object] = dict(definition.config)
    authored_instructions = merged.pop("instructions", _OMITTED)
    authored_skills = merged.pop("skills", _OMITTED)
    subagent_skills = merged.pop(SUBAGENT_SKILLS_KEY, None)
    merged.pop("memory", None)
    merged.pop("mcp", None)
    merged.pop("sandbox", None)
    merged.pop("browser", None)
    merged["context_schema"] = context_schema

    sandbox_backend = (
        _managed_sandbox_backend(
            sandbox,
            config,
            connectors=connectors,
            identity=identity,
            selection=sandbox_selection,
        )
        if sandbox is not None
        else None
    )
    backend_factory: RuntimeBackendFactory = (
        sandbox_backend.bind_runtime if sandbox_backend is not None else lambda _runtime: None
    )

    context = (
        None
        if inspection
        else timing.measure(
            "context",
            lambda: _open_context_backend(context_repo=context_repo, context_root=context_root),
        )
    )
    selected_skills_backend = (
        None
        if skip_factory_inspection_tools
        else timing.measure(
            "skills",
            lambda: _resolve_run_skills(
                authored_skills,
                context,
                context_repo=context_repo,
                context_root=context_root,
                trial_root_dir=trial_root_dir,
            ),
        )
    )
    # Memory mounts read the repo while the run executes, so each run gets its own
    # Context Hub backend (see _RunScopedBackend). The local filesystem mock reads
    # disk on every call, so it needs no wrapper.
    live_context_backend: BackendProtocol | None = None
    if context is not None:
        live_context_backend = (
            _RunScopedBackend(context.backend, lambda: ContextHubBackend(context_repo))
            if context_repo and context.filesystem_root is None
            else context.backend
        )
    mounted_memory: MemoryLayers = []
    user_memory_backend: UserMemoryBackend | None = None
    assistant_memory_backend: AssistantMemoryBackend | None = None
    if context is not None and live_context_backend is not None:
        mounted_memory, user_memory_backend, assistant_memory_backend = _apply_managed_context(
            merged,
            context_backend=live_context_backend,
            filesystem_root=context.filesystem_root,
            context_repo=context_repo,
            run_config=config,
            sandbox_backend=sandbox_backend,
            memory_layers=declared_memory_layers,
            selected_skills_backend=selected_skills_backend,
            allow_agent=allow_agent,
            allowed_user_id=user_access.user_id,
            allow_assistant=allow_assistant,
        )
    elif sandbox_backend is not None:
        merged["backend"] = sandbox_backend
    if context is None and selected_skills_backend is not None:
        _mount_selected_skills(
            merged,
            selected_skills_backend,
            sandbox_backend=sandbox_backend,
        )
    _mount_authored_routes(merged)

    merged["system_prompt"] = timing.measure(
        "instructions",
        lambda: _select_system_prompt(
            authored_instructions,
            context.backend if context is not None else None,
            system_prompt,
        ),
    )

    # Mounted the same way in every mode, but resolved against different roots:
    # local/deploy route ``/skills/`` to the Context Hub mock or repo, while an
    # eval trial reads the project's own ``skills/`` tree, which the Harbor
    # adapter copies into the trial workspace the backend is rooted at.
    effective_has_skills = (
        bool(authored_skills)
        if skip_factory_inspection_tools and authored_skills is not _OMITTED
        else selected_skills_backend.file_count > 0
        if selected_skills_backend is not None
        else has_skills
    )
    if sources := _skill_sources(subagent_skills, has_skills=effective_has_skills):
        merged["skills"] = sources
    # Authored tools and managed Slack file tools share the current sandbox backend.
    # Wrap even without identity or a sandbox so runtime.backend is None rather
    # than an absent attribute on LangGraph's runtime.
    # Inspection needs the credential gate, but must not load credentials.
    _prepend_credential_gate_middleware(merged, connectors, sandbox)
    # Save files and checkpoint their paths before credential interrupts;
    # resume deliveries do not include the original file event.
    _prepend_slack_files_middleware(merged, channels)
    # Before the seam, so the browser's tools get the thread's sandbox backend.
    _append_browser_middleware(merged, browser)
    _apply_runtime_seam(merged, backend_factory)

    # Connectors: run each connector's ``tools`` hook and append the results to
    # the authored tools. Connector tools keep identity injection, but do not
    # receive the authored runtime backend API.
    tools_by_connector = (
        timing.measure("connectors", lambda: load_tools_by_connector(connectors))
        if connectors and not skip_factory_inspection_tools
        else []
    )
    authored_tools = list(cast("Iterable[DeepAgentTool]", merged.get("tools") or ()))
    tools_by_connector = [
        (connector, wrap_tools_with_managed_runtime(tools) if identity is not None else tools)
        for connector, tools in tools_by_connector
    ]
    if tools_by_connector:
        merged["tools"] = authored_tools + [
            tool for _, tools in tools_by_connector for tool in tools
        ]
    if merged.get("subagents") is not None:
        merged["subagents"] = _scope_subagent_mcp_tools(
            cast("Sequence[object]", merged["subagents"]),
            connectors or [],
            authored_tools,
            tools_by_connector,
        )

    # Managed prompt behavior surrounds authored middleware in the same order as TS.
    _append_channel_response_format_middleware(merged)
    if mounted_memory:
        _append_memory_instructions_middleware(
            merged,
            mounted_memory,
            user_memory_backend,
            assistant_memory_backend=assistant_memory_backend,
            agent_memory_backend=live_context_backend
            if has_agent_memory_layer(mounted_memory)
            else None,
        )
    # Last, so taken messages are the final state write before the model call.
    _append_steering_middleware(merged)

    # Author ``metadata`` is not a create_deep_agent kwarg — apply it on the
    # compiled runnable so LangSmith root runs carry prompt provenance, etc.
    metadata = merged.pop("metadata", None)
    timing.set_sizes(
        tools=_count(merged.get("tools")),
        middleware=_count(merged.get("middleware")),
        subagents=_count(merged.get("subagents")),
    )
    # The definition and managed adapters are validated at their own boundaries.
    # This heterogeneous argument map cannot express each native keyword type.
    agent = timing.measure("create_deep_agent", lambda: create_deep_agent(**cast("Any", merged)))
    compiled = (
        agent.with_config({"metadata": dict(metadata)})
        if isinstance(metadata, Mapping) and metadata
        else agent
    )
    return compiled, RunConfiguration(
        # Left unset here because they differ per call; _for_call fills them in.
        channel=_detect_run_channel(config),
        sandbox_declared=sandbox is not None,
        identity_declared=identity is not None,
        skills_declared=effective_has_skills,
        backend_kind="sandbox" if sandbox_backend is not None else "state",
        context_source=(
            "none" if context is None else ("local" if context.filesystem_root else "hub")
        ),
        memory=MemoryObservations(
            layers_declared=[layer["type"] for layer in _declared_memory_layers(memory)],
            layers_mounted=[layer["type"] for layer in mounted_memory],
            user_denied_reason=user_access.denied_reason,
        ),
        provider_event_type=None,
        user_resolution=None,
        subagent_role=subagent_role,
        browser_declared=browser is not None,
    )


def _scope_subagent_mcp_tools(
    subagents: Sequence[object],
    connectors: Sequence[Connector],
    authored_tools: list[DeepAgentTool],
    tools_by_connector: list[tuple[Connector, ConnectorToolList]],
) -> Sequence[object]:
    """Give each sync subagent with `mcp` only the tools of the MCP servers it selects."""
    if not any(isinstance(spec, Mapping) and "mcp" in spec for spec in subagents):
        return subagents
    loaded = {id(c) for c in connectors if c.kind == "mcp_servers"}
    non_mcp = [tool for c, tools in tools_by_connector if c.kind != "mcp_servers" for tool in tools]
    scoped: list[object] = []
    for spec in subagents:
        if not isinstance(spec, Mapping) or "mcp" not in spec:
            scoped.append(spec)
            continue
        selected = {id(definition) for definition in spec["mcp"] or ()}
        if not selected <= loaded:
            msg = f"subagent {spec.get('name')!r} selects an MCP server this agent does not load"
            raise ValueError(msg)
        own = (
            list(cast("Iterable[DeepAgentTool]", spec["tools"]))
            if "tools" in spec
            else authored_tools + non_mcp
        )
        mcp_tools = [tool for c, tools in tools_by_connector if id(c) in selected for tool in tools]
        scoped.append(
            {key: value for key, value in spec.items() if key != "mcp"} | {"tools": own + mcp_tools}
        )
    return scoped


def _count(value: object) -> int:
    return len(value) if isinstance(value, Sized) else 0


def _platform_run_id(config: Mapping[str, object] | None) -> str | None:
    """LangGraph stamps the run it is executing here; Pregel reads the same key.

    Absent under ``mda dev`` and a direct invoke, where ``start_run`` mints one.
    """
    metadata = config.get("metadata") if config else None
    value = metadata.get("run_id") if isinstance(metadata, Mapping) else None
    return _string_option(value)


def _thread_id_of(config: Mapping[str, object] | None) -> str | None:
    configurable = config.get("configurable") if config else None
    value = configurable.get("thread_id") if isinstance(configurable, Mapping) else None
    return _string_option(value)


def _policy_run_context(run_context: object, config: RunnableConfig | None) -> object:
    from managed_deepagents._run_input import execution_context  # noqa: PLC0415

    _, _, routing = execution_context(run_context, config, None)
    context = run_context if isinstance(run_context, Mapping) else {}
    channel = (routing or {}).get("mda_channel", context.get("mda_channel"))
    if channel is not None:
        return {**context, "mda_channel": channel, "channel": channel}
    return run_context


def _with_thread_origin(policy_context: object, config: RunnableConfig | None) -> object:
    """Give the memory policy of a run with no live channel its thread origin's channel.

    A run no channel message started (a task notification waking the lead, a
    resume) still answers in the thread's channel conversation, so the policy
    sees that channel too. The origin has no provider event, so MDA's default
    policy still denies user memory outside a live Slack DM; only an authored
    policy can allow it. The origin comes from the run's metadata, so this needs
    no extra request.
    """
    from managed_deepagents._run_input import run_thread  # noqa: PLC0415

    if _field(policy_context, "mda_channel") is not None:
        return policy_context
    origin = run_thread(None, config, None).origin
    if origin is None:
        return policy_context
    context = policy_context if isinstance(policy_context, Mapping) else {}
    return {**context, "mda_channel": origin, "channel": origin}


def _detect_run_channel(config: Mapping[str, object] | None) -> str:
    """The cron principal cannot be forged, so it wins over a channel binding.

    An unrecognized provider reports ``unknown`` rather than widening the
    dimension.
    """
    from managed_deepagents._run_input import is_scheduled_execution  # noqa: PLC0415

    configurable = config.get("configurable") if config else None
    if not isinstance(configurable, Mapping):
        return "unknown"
    if is_scheduled_execution(configurable):
        return "schedule"
    return resolve_channel_provider(configurable) or "unknown"


class _OpenedContextBackend:
    """Resolved Context Hub or local filesystem mock used by compile."""

    __slots__ = ("backend", "filesystem_root")

    def __init__(self, backend: BackendProtocol, filesystem_root: str | None) -> None:
        self.backend = backend
        self.filesystem_root = filesystem_root


class _RunScopedBackend(BackendProtocol):
    """A Context Hub backend that each run opens for itself.

    ``ContextHubBackend`` loads the repo tree once and keeps it, reloading only
    after a write conflict. A cached graph serves many runs, so a backend held by
    the graph would keep serving the first run's snapshot: memory written since,
    by another replica or another graph, would never show up. This forwards every
    call to the current run's own backend instead.

    ``compiled`` is the backend opened at compile time. Calls outside a run (the
    compile itself) use it, and the first run adopts it, so an uncached graph,
    which serves one run, opens one backend as before.
    """

    def __init__(self, compiled: BackendProtocol, open_backend: Callable[[], BackendProtocol]):
        self._compiled = compiled
        self._runs: RunLocal[BackendProtocol] = RunLocal(open_backend, first=compiled)

    def _backend(self) -> BackendProtocol:
        if current_run_id() is None:
            return self._compiled
        return self._runs.get()

    def ls(self, *args: Any, **kwargs: Any) -> Any:
        return self._backend().ls(*args, **kwargs)

    async def als(self, *args: Any, **kwargs: Any) -> Any:
        return await self._backend().als(*args, **kwargs)

    def read(self, *args: Any, **kwargs: Any) -> Any:
        return self._backend().read(*args, **kwargs)

    async def aread(self, *args: Any, **kwargs: Any) -> Any:
        return await self._backend().aread(*args, **kwargs)

    def grep(self, *args: Any, **kwargs: Any) -> Any:
        return self._backend().grep(*args, **kwargs)

    async def agrep(self, *args: Any, **kwargs: Any) -> Any:
        return await self._backend().agrep(*args, **kwargs)

    def glob(self, *args: Any, **kwargs: Any) -> Any:
        return self._backend().glob(*args, **kwargs)

    async def aglob(self, *args: Any, **kwargs: Any) -> Any:
        return await self._backend().aglob(*args, **kwargs)

    def write(self, *args: Any, **kwargs: Any) -> Any:
        return self._backend().write(*args, **kwargs)

    async def awrite(self, *args: Any, **kwargs: Any) -> Any:
        return await self._backend().awrite(*args, **kwargs)

    def edit(self, *args: Any, **kwargs: Any) -> Any:
        return self._backend().edit(*args, **kwargs)

    async def aedit(self, *args: Any, **kwargs: Any) -> Any:
        return await self._backend().aedit(*args, **kwargs)

    def delete(self, *args: Any, **kwargs: Any) -> Any:
        return self._backend().delete(*args, **kwargs)

    async def adelete(self, *args: Any, **kwargs: Any) -> Any:
        return await self._backend().adelete(*args, **kwargs)

    def upload_files(self, *args: Any, **kwargs: Any) -> Any:
        return self._backend().upload_files(*args, **kwargs)

    async def aupload_files(self, *args: Any, **kwargs: Any) -> Any:
        return await self._backend().aupload_files(*args, **kwargs)

    def download_files(self, *args: Any, **kwargs: Any) -> Any:
        return self._backend().download_files(*args, **kwargs)

    async def adownload_files(self, *args: Any, **kwargs: Any) -> Any:
        return await self._backend().adownload_files(*args, **kwargs)


def _open_context_backend(
    *, context_repo: str | None, context_root: str | None
) -> _OpenedContextBackend | None:
    """Open the deploy Hub or local ``.mda/__contexthub__`` mock, if configured."""
    if context_repo:
        return _OpenedContextBackend(ContextHubBackend(context_repo), None)
    if context_root:
        return _OpenedContextBackend(
            FilesystemBackend(root_dir=context_root, virtual_mode=True),
            context_root,
        )
    return None


def _skill_sources(subagent_skills: object, *, has_skills: bool) -> list[str]:
    """Skill sources for the agent: an async subagent's own (`SubAgent.skills`), else the mount."""
    if subagent_skills is None:
        return [MANAGED_SKILLS_PATH] if has_skills else []
    sources = list(cast("Sequence[str]", subagent_skills))
    # Without a mount, `/skills/` would read whatever the sandbox holds there.
    return sources if has_skills else [path for path in sources if path != MANAGED_SKILLS_PATH]


def _resolve_run_skills(
    authored: object,
    context: _OpenedContextBackend | None,
    *,
    context_repo: str | None,
    context_root: str | None,
    trial_root_dir: str | None,
) -> SelectedSkillsBackend | None:
    if authored is _OMITTED:
        return None
    source_context = context
    if source_context is None and trial_root_dir is None:
        source_context = _open_context_backend(
            context_repo=context_repo,
            context_root=context_root,
        )
    return resolve_selected_skills(
        () if authored is None else authored,
        context_backend=source_context.backend if source_context is not None else None,
        local_root=trial_root_dir,
    )


def _mount_selected_skills(
    merged: dict[str, object],
    selected: SelectedSkillsBackend,
    *,
    sandbox_backend: SandboxBackendProtocol | None,
) -> None:
    # ``merged`` is the heterogeneous ``create_deep_agent`` kwargs map; only the
    # runtime itself (sandbox or eval trial backend) has set ``backend`` here.
    merged["backend"] = _managed_selected_skills_backend(
        cast("BackendProtocol | None", merged.get("backend")),
        selected,
        CompositeBackend,
        StateBackend,
    )
    if sandbox_backend is not None:
        merged["permissions"] = []
        return
    merged["permissions"] = _managed_context_permissions(
        merged.get("permissions"),
        FilesystemPermission,
    )


def _mount_authored_routes(merged: dict[str, object]) -> None:
    """Mount ``define_deep_agent(routes=...)`` over the managed backend."""
    routes = cast("Routes | None", merged.pop("routes", None))
    if routes:
        merged["backend"] = mount_routes(
            cast("BackendProtocol | None", merged.get("backend")), routes
        )


def _apply_managed_context(
    merged: dict[str, object],
    *,
    context_backend: BackendProtocol,
    filesystem_root: str | None,
    context_repo: str | None,
    run_config: Mapping[str, object] | None,
    sandbox_backend: SandboxBackendProtocol | None,
    memory_layers: MemoryLayers,
    selected_skills_backend: SelectedSkillsBackend | None,
    allowed_user_id: str | None,
    allow_agent: bool,
    allow_assistant: bool = False,
) -> tuple[MemoryLayers, UserMemoryBackend | None, AssistantMemoryBackend | None]:
    """Wire system prompt, backend routes, permissions, and hot memory.

    Return the mounted layers and the caller backend used to load user hot
    memory once per run without saving it in thread state. Skills are
    mounted by the caller so eval trials mount them too.
    """
    # Memory is opt-in: only the root ``memory`` declaration enables a layer, so a
    # project that declares nothing mounts nothing regardless of identity.
    memory_layers = [
        layer
        for layer in memory_layers
        if (
            allow_agent
            if layer["type"] == "agent"
            else allow_assistant
            if layer["type"] == "assistant"
            else allowed_user_id is not None
        )
    ]
    declared_user_layer = user_memory_layer(memory_layers)
    user_memory_backend = (
        UserMemoryBackend(
            deploy_handle=context_repo or "local",
            filesystem_root=filesystem_root,
            run_config=run_config,
            # An assertion the backend checks against the authenticated
            # principal; it never selects whose memory is mounted.
            asserted_user_id=declared_user_layer.get("id"),
        )
        if declared_user_layer is not None
        else None
    )
    assistant_memory_backend = (
        AssistantMemoryBackend(
            deploy_handle=context_repo or "local", filesystem_root=filesystem_root
        )
        if any(layer["type"] == "assistant" for layer in memory_layers)
        else None
    )
    merged["backend"] = _managed_context_backend(
        context_backend,
        sandbox_backend,
        _ManagedCompositeBackend,
        StateBackend,
        mount_agent_memory=has_agent_memory_layer(memory_layers),
        user_memory_backend=user_memory_backend,
        assistant_memory_backend=assistant_memory_backend,
        selected_skills_backend=selected_skills_backend,
    )
    # Sandbox + FilesystemPermission cannot coexist at execute() time: deepagents
    # adapts CompositeBackend and drops route prefixes, so any permission rule
    # disables shell. Rely on read-only Context Hub mounts instead.
    if sandbox_backend is not None:
        merged["permissions"] = []
    else:
        merged["permissions"] = _managed_context_permissions(
            merged.get("permissions"),
            FilesystemPermission,
        )
    return memory_layers, user_memory_backend, assistant_memory_backend


def _declared_memory_layers(memory: MemoryDefinitionLike | None) -> MemoryLayers:
    """Layers from the root declaration; empty when the project declares none."""
    if memory is None:
        return []
    config = getattr(memory, "config", None)
    if not isinstance(config, Mapping):
        return []
    scope = config.get("scope")
    # Dynamic boundary: the declaration is imported from the author's module, so
    # its shape is checked here rather than trusted.
    return list(scope) if isinstance(scope, list) else []


def _select_system_prompt(
    authored: object,
    context_backend: BackendProtocol | None,
    fallback: str | None,
) -> str:
    """Choose authored instructions while preserving MDA's platform boundary."""
    if authored is not _OMITTED:
        if authored is None:
            selected = ""
        elif isinstance(authored, str):
            selected = authored
        else:
            raise TypeError("instructions must be a string or None")
    elif context_backend is not None:
        selected = _read_context_instructions(context_backend)
    else:
        selected = None
    if selected is None:
        selected = fallback
    return (
        f"{MANAGED_DEEP_AGENT_INSTRUCTIONS}\n\n{selected}"
        if selected
        else MANAGED_DEEP_AGENT_INSTRUCTIONS
    )


def compile_managed_agent_for_eval(
    definition: DeepAgentDefinition,
    config: ManagedRunConfig | None = None,
    *,
    system_prompt: str | None = None,
    has_skills: bool = False,
    connectors: list[Connector] | None = None,
    channels: list[Channel] | None = None,
    identity: IdentityDefinitionLike | None = None,
    model_override: str | None = None,
) -> CompiledAgent:
    """Compile an authored definition for an MDA eval trial.

    Harbor owns the outer sandbox in eval mode, so authored MDA sandbox wiring is
    deliberately not instantiated here. File tools must still write real disk
    under the trial ``/app`` (or ``configurable["cwd"]``) so Harbor verifiers can
    see outputs like ``/app/answer.txt`` — without this, deepagents defaults to
    StateBackend and writes stay in virtual agent state.

    ``has_skills`` mounts the project's skills the way dev and deploy do. There is
    no Context Hub here: the trial backend is rooted at the workspace the adapter
    copied the compiled project into, so :data:`MANAGED_SKILLS_PATH` resolves to
    the project's own ``skills/`` tree.

    The model override is applied to a copied definition so normal dev/deploy
    behavior remains unchanged.
    """
    eval_definition = _prepare_eval_definition(
        route_async_subagents(definition, {}), config, model_override, _eval_app_dir(config)
    )

    return compile_managed_agent(
        eval_definition,
        config,
        run_context=config.get("context") if config else None,
        system_prompt=system_prompt,
        has_skills=has_skills,
        connectors=connectors,
        channels=channels,
        identity=identity,
        trial_root_dir=_eval_app_dir(config),
        # A trial is a scored test rather than someone using an agent, so it
        # reports nothing; ``mda evals`` is counted once by the CLI instead.
        report_telemetry=False,
        # Eval trials never mount durable memory: this path takes no ``memory``
        # keyword, and the generated eval entry does not pass one.
    )


async def compile_agent_factory_for_eval_async(
    entry: AgentEntry,
    config: ManagedRunConfig | None = None,
    *,
    system_prompt: str | None = None,
    has_skills: bool = False,
    connectors: list[Connector] | None = None,
    channels: list[Channel] | None = None,
    identity: IdentityDefinitionLike | None = None,
    model_override: str | None = None,
    app_dir: str | None = None,
    async_subagent_graphs: Mapping[str, str] | None = None,
    async_subagent: str | None = None,
) -> CompiledAgent:
    """Resolve a dynamic eval entry once before applying its trial model."""
    # Harbor calls this helper only to execute a scored trial. Missing context
    # means the run has empty authored context; it is not graph inspection.
    context = config.get("context") if config is not None else None
    timing = GraphBuildTiming()
    with timing.phase("factory"):
        definition = await resolve_agent_definition(
            entry, _internal_server_runtime(config, context, is_run=True)
        )
    definition = _select_async_subagent_graph(definition, async_subagent_graphs, async_subagent)
    trial_root_dir = app_dir or _eval_app_dir(config)
    eval_definition = _prepare_eval_definition(definition, config, model_override, trial_root_dir)
    agent = await _compile_resolved_managed_agent_async(
        eval_definition,
        config,
        run_context=context,
        is_run=True,
        system_prompt=system_prompt,
        has_skills=has_skills,
        connectors=connectors,
        channels=channels,
        identity=identity,
        trial_root_dir=trial_root_dir,
        report_telemetry=False,
        skip_factory_inspection_tools=False,
        subagent_role="lead" if async_subagent is None else "async_subagent",
        timing=timing,
    )
    timing.log(kind="run", run_id=_platform_run_id(config))
    return agent


def _prepare_eval_definition(
    definition: DeepAgentDefinition,
    config: ManagedRunConfig | None,
    model_override: str | None,
    app_dir: str,
) -> DeepAgentDefinition:
    """Copy one resolved definition and add eval-owned model and disk settings."""
    configured_model = _configurable_model(config)
    merged = dict(definition.config)
    selected_model = model_override or configured_model
    if selected_model:
        merged["model"] = selected_model
    # Prefer runner-provided cwd; default matches the adapter's ``/app`` staging.
    # Authoring forbids ``backend`` on definitions; inject via the compiled config.
    merged["backend"] = create_eval_trial_filesystem_backend(
        FilesystemBackend,
        app_dir,
        hide_skills="skills" in merged,
    )
    return DeepAgentDefinition(merged)


def _configurable_model(config: Mapping[str, object] | None) -> str | None:
    configurable = config.get("configurable") if config else None
    if not isinstance(configurable, Mapping):
        return None
    value = configurable.get("model")
    return _string_option(value)


def _eval_app_dir(config: Mapping[str, object] | None) -> str:
    configurable = config.get("configurable") if config else None
    if isinstance(configurable, Mapping):
        cwd = configurable.get("cwd")
        if isinstance(cwd, str) and cwd.strip():
            return cwd
    return "/app"


def _apply_runtime_seam(merged: dict[str, object], backend_factory: RuntimeBackendFactory) -> None:
    """Wrap authored tools and middleware with managed runtime fields."""
    # ``merged`` is the heterogeneous ``create_deep_agent`` kwargs map; each
    # value was validated against its native type by ``define_deep_agent``.
    tools_value = merged.get("tools")
    if tools_value is not None:
        merged["tools"] = wrap_tools_with_managed_runtime(
            list(cast("Iterable[DeepAgentTool]", tools_value)), backend_factory
        )
    middleware_value = merged.get("middleware")
    if middleware_value is not None:
        merged["middleware"] = wrap_middleware_with_managed_runtime(
            list(cast("Iterable[AgentMiddleware]", middleware_value)), backend_factory
        )
    subagents_value = merged.get("subagents")
    if subagents_value is not None:
        merged["subagents"] = _wrap_declarative_subagents(
            list(cast("Iterable[DeepAgentSubAgent]", subagents_value)), backend_factory
        )


def _wrap_declarative_subagents(
    subagents: Sequence[DeepAgentSubAgent], backend_factory: RuntimeBackendFactory
) -> list[DeepAgentSubAgent]:
    """Wrap authored subagent tools while leaving opaque agents unchanged."""
    wrapped: list[DeepAgentSubAgent] = []
    for subagent in subagents:
        if not isinstance(subagent, Mapping) or "runnable" in subagent or "graph_id" in subagent:
            wrapped.append(subagent)
            continue
        # Compiled (``runnable``) and async (``graph_id``) specs are excluded above.
        spec = cast("SubAgent", dict(subagent))
        tools = spec.get("tools")
        if tools is not None:
            spec["tools"] = wrap_tools_with_managed_runtime(list(tools), backend_factory)
        middleware = spec.get("middleware")
        if middleware is not None:
            spec["middleware"] = wrap_middleware_with_managed_runtime(
                list(middleware), backend_factory
            )
        wrapped.append(spec)
    return wrapped


def _prepend_credential_gate_middleware(
    merged: dict[str, object],
    connectors: list[Connector] | None,
    sandbox: SandboxDefinition | None = None,
) -> None:
    """Gate user credentials required by connectors and sandbox proxy config."""
    from managed_deepagents._connectors.mcp.load import (  # noqa: PLC0415
        mcp_credential_consumers,
    )
    from managed_deepagents._credential_gate import (  # noqa: PLC0415
        create_credential_gate_middleware,
        create_credential_outage_middleware,
    )
    from managed_deepagents._sandbox_proxy import (  # noqa: PLC0415
        sandbox_credential_consumers,
        sandbox_has_proxy_connections,
    )

    gate = create_credential_gate_middleware(
        [
            *mcp_credential_consumers(connectors),
            *sandbox_credential_consumers(sandbox),
        ]
    )
    if gate is None:
        if not sandbox_has_proxy_connections(sandbox):
            return
        gate = create_credential_outage_middleware()
    middleware_value = merged.get("middleware")
    existing = (
        list(cast("Iterable[object]", middleware_value)) if middleware_value is not None else []
    )
    merged["middleware"] = [gate, *existing]


def _append_memory_instructions_middleware(
    merged: dict[str, object],
    memory: MemoryLayers,
    user_memory_backend: UserMemoryBackend | None = None,
    *,
    agent_memory_backend: BackendProtocol | None = None,
    assistant_memory_backend: BackendProtocol | None = None,
) -> None:
    """Replace native memory in its slot after prompt caching, including in forks."""
    from managed_deepagents._memory_instructions import (  # noqa: PLC0415
        create_memory_instructions_middleware,
    )

    middleware_value = merged.get("middleware")
    existing = (
        list(cast("Iterable[object]", middleware_value)) if middleware_value is not None else []
    )
    # Reserve the native slot; replacement by name removes its loader and state
    # schema before graph compilation. Only MDA's permitted per-run loader runs.
    merged["memory"] = [f"/memories/{layer['type']}/AGENTS.md" for layer in memory]
    merged["middleware"] = [
        *existing,
        create_memory_instructions_middleware(
            memory,
            (lambda: _download_context_file(user_memory_backend, "/AGENTS.md"))
            if user_memory_backend is not None
            else None,
            load_assistant_memory=(
                lambda: _download_context_file(assistant_memory_backend, "/AGENTS.md")
            )
            if assistant_memory_backend is not None
            else None,
            load_agent_memory=(
                lambda: _download_context_file(agent_memory_backend, "/memories/agent/AGENTS.md")
            )
            if agent_memory_backend is not None
            else None,
        ),
    ]


def _prepend_slack_files_middleware(
    merged: dict[str, object], channels: list[Channel] | None
) -> None:
    """Enable file transfers, and status choosers, when the agent declares Slack."""
    if any(getattr(channel, "kind", None) == "slack" for channel in channels or []):
        from managed_deepagents._channels.slack.middleware import (  # noqa: PLC0415
            SlackFileTransferMiddleware,
        )
        from managed_deepagents._channels.slack.status import (  # noqa: PLC0415
            SlackStatusMiddleware,
            slack_status_choosers,
        )

        choosers = slack_status_choosers(channels)
        authored_middleware = merged.get("middleware")
        merged["middleware"] = [
            SlackFileTransferMiddleware(),
            # Show each Slack channel's status chooser while the run works.
            *([SlackStatusMiddleware(choosers)] if choosers else []),
            *(cast("Iterable[object]", authored_middleware) if authored_middleware else []),
        ]


def _append_browser_middleware(
    merged: dict[str, object], browser: BrowserDefinition | None
) -> None:
    """Give the agent a browser when the project declares one in ``browser.py``.

    Without a sandbox its screenshots save to the agent's own ``backend``, so call it
    once that is final.
    """
    if browser is None:
        return
    from managed_deepagents.browser import BrowserMiddleware  # noqa: PLC0415

    authored_middleware = merged.get("middleware")
    merged["middleware"] = [
        *(cast("Iterable[object]", authored_middleware) if authored_middleware else []),
        BrowserMiddleware(
            scope=browser.scope,
            idle_ttl_seconds=browser.idle_ttl_seconds,
            allow_list=browser.allow_list,
            backend=cast("BackendProtocol | None", merged.get("backend")),
        ),
    ]


def _append_steering_middleware(merged: dict[str, object]) -> None:
    from managed_deepagents._steering import SteeringMiddleware  # noqa: PLC0415

    middleware_value = merged.get("middleware")
    existing = (
        list(cast("Iterable[object]", middleware_value)) if middleware_value is not None else []
    )
    merged["middleware"] = [*existing, SteeringMiddleware()]


def _append_channel_response_format_middleware(merged: dict[str, object]) -> None:
    """Install managed channel response guidance after authored middleware.

    The run-output recorder goes first, so a stateless run's delivery reads
    what the agent ended with.
    """
    from managed_deepagents._channels.response_format import (  # noqa: PLC0415
        create_channel_response_format_middleware,
    )
    from managed_deepagents._channels.run_output import RunOutputMiddleware  # noqa: PLC0415

    middleware_value = merged.get("middleware")
    existing = (
        list(cast("Iterable[object]", middleware_value)) if middleware_value is not None else []
    )
    merged["middleware"] = [
        RunOutputMiddleware(),
        *existing,
        create_channel_response_format_middleware(),
    ]


#: Refusal returned instead of globbing the sandbox root.
#:
#: deepagents implements sandbox glob as an unfiltered ``find -L <path>`` whose
#: entire stdout is buffered in this process and then split per line, so a root
#: search walks the whole container image (including ``/proc``, and back through
#: ``/`` via its symlinks) and can exhaust the server heap before any truncation
#: applies. Must stay identical to the npm runtime's ``ROOT_GLOB_ERROR``.
_ROOT_GLOB_ERROR = (
    "cannot glob the sandbox root: '/' walks the entire container filesystem, "
    "which can exhaust memory. Retry with a concrete directory, for example /workspace."
)


def _is_filesystem_root(path: str | None) -> bool:
    """Whether ``path`` addresses the filesystem root rather than a directory in it.

    ``None`` counts: deepagents defaults an omitted path to ``/``, and
    ``CompositeBackend`` forwards a root search to the default backend as-is.
    """
    raw = ("/" if path is None else path).strip()
    if not raw:
        return True
    if not raw.startswith("/"):
        return False
    return posixpath.normpath(f"/{raw.lstrip('/')}") == "/"


def _root_glob_refusal() -> GlobResult:
    """Refuse a root glob as a real ``GlobResult``.

    Must be the deepagents dataclass, not a structural stand-in:
    ``CompositeBackend.glob`` gates on ``isinstance(result, GlobResult)`` before
    reading ``error``, and treats anything else as a raw list of matches.
    """
    return GlobResult(error=_ROOT_GLOB_ERROR, matches=[])


class _LazySandboxSource:
    """Factory-closed inputs shared by every bound lazy sandbox backend."""

    __slots__ = (
        "connectors",
        "identity",
        "proxy_config_sync",
        "run_config",
        "sandbox",
        "selection",
    )

    def __init__(
        self,
        sandbox: SandboxDefinition,
        run_config: ManagedRunConfig | None,
        *,
        connectors: list[Connector] | None,
        identity: IdentityDefinitionLike | None,
        selection: _SandboxSelection | None,
        proxy_config_sync: SandboxProxyConfigSync,
    ) -> None:
        self.sandbox = sandbox
        self.run_config = run_config
        self.connectors = connectors
        self.identity = identity
        self.selection = selection
        self.proxy_config_sync = proxy_config_sync


class _LazyManagedSandboxBackend(ManagedSandboxBackend):
    """Lazy sandbox backend with frozen per-instance ``configurable``.

    Construct unbound (``None``) for static mounts, or call ``bind_runtime`` so
    concurrent requests each keep their own thread/actor without shared
    mutable identity state. Process-level sandbox reuse lives in
    ``_resolve_managed_sandbox``.
    """

    def __init__(
        self, source: _LazySandboxSource, bound_configurable: Mapping[str, object] | None
    ) -> None:
        self._source = source
        self._bound_configurable = bound_configurable
        self._resolved_backend: SandboxBackendProtocol | None = None
        # True when this backend belongs to a cached graph (see _CachedGraphs), which
        # is compiled with no run config and has no run bound to it. One backend
        # instance then serves many threads, so it must not cache the sandbox it
        # resolves: it looks up the current run's thread on every call instead.
        # Otherwise thread B would be served thread A's sandbox.
        self._shared = bound_configurable is None and source.run_config is None

    def bind_runtime(self, runtime: object) -> _LazyManagedSandboxBackend:
        """Capture this run's configuration without resolving the sandbox."""
        return _LazyManagedSandboxBackend(self._source, resolve_runtime_configurable(runtime))

    def _keep(self, backend: SandboxBackendProtocol) -> None:
        """Cache the resolved sandbox, unless this backend is shared across threads."""
        if not self._shared:
            self._resolved_backend = backend

    def opened(self) -> SandboxBackendProtocol | None:
        """This thread's sandbox if this process opened it, by any handle; never opens one."""
        if self._resolved_backend is not None:
            return self._resolved_backend
        try:
            key = _thread_scope_key(self._config(), self._source.selection)
        except Exception:  # noqa: BLE001 — no thread, so no sandbox, as in ``id``
            return None
        with _managed_sandbox_lock:
            entry = _managed_sandboxes.get(key)
        return entry.backend if entry is not None else None

    @property
    def id(self) -> str:
        # deepagents' sandbox protocol guards require a non-empty ``id``
        # (and snapshot it at adapt time). Return the resolved sandbox id
        # when available; otherwise a stable pending placeholder so execute
        # is not stripped before the first resolve. Never raise — a missing
        # thread_id must not crash CompositeBackend construction.
        resolved = getattr(self._resolved_backend, "id", None)
        if resolved:
            return str(resolved)
        try:
            scope = _thread_scope_key(self._config(), self._source.selection)
            return f"pending:{scope}"
        except Exception:  # noqa: BLE001 — match TS pending:sandbox fallback
            return "pending:sandbox"

    def ls(self, path: str = "/") -> LsResult:
        return self._call(lambda backend: backend.ls(path))

    async def als(self, path: str = "/") -> LsResult:
        return await self._acall(lambda backend: backend.als(path))

    def read(self, file_path: str, offset: int = 0, limit: int = 2000) -> ReadResult:
        return self._call(lambda backend: backend.read(file_path, offset=offset, limit=limit))

    async def aread(self, file_path: str, offset: int = 0, limit: int = 2000) -> ReadResult:
        return await self._acall(lambda backend: backend.aread(file_path, offset, limit))

    def grep(
        self,
        pattern: str,
        path: str | None = None,
        glob: str | None = None,
        *,
        max_count: int | None = None,
    ) -> GrepResult:
        if max_count is not None:
            return self._call(
                lambda backend: backend.grep(pattern, path, glob, max_count=max_count)
            )
        return self._call(lambda backend: backend.grep(pattern, path, glob))

    async def agrep(
        self,
        pattern: str,
        path: str | None = None,
        glob: str | None = None,
        *,
        max_count: int | None = None,
    ) -> GrepResult:
        if max_count is not None:
            return await self._acall(
                lambda backend: backend.agrep(pattern, path, glob, max_count=max_count)
            )
        return await self._acall(lambda backend: backend.agrep(pattern, path, glob))

    def glob(self, pattern: str, path: str | None = None) -> GlobResult:
        # Refuse before resolving: a root glob is never worth creating a sandbox for.
        if _is_filesystem_root(path):
            return _root_glob_refusal()
        return self._call(lambda backend: backend.glob(pattern, path))

    async def aglob(self, pattern: str, path: str | None = None) -> GlobResult:
        if _is_filesystem_root(path):
            return _root_glob_refusal()
        return await self._acall(lambda backend: backend.aglob(pattern, path))

    def write(self, file_path: str, content: str) -> WriteResult:
        return self._call(lambda backend: backend.write(file_path, content))

    async def awrite(self, file_path: str, content: str) -> WriteResult:
        return await self._acall(lambda backend: backend.awrite(file_path, content))

    def edit(
        self,
        file_path: str,
        old_string: str,
        new_string: str,
        replace_all: bool = False,
    ) -> EditResult:
        return self._call(
            lambda backend: backend.edit(file_path, old_string, new_string, replace_all=replace_all)
        )

    async def aedit(
        self,
        file_path: str,
        old_string: str,
        new_string: str,
        replace_all: bool = False,
    ) -> EditResult:
        return await self._acall(
            lambda backend: backend.aedit(
                file_path, old_string, new_string, replace_all=replace_all
            )
        )

    def delete(self, file_path: str) -> DeleteResult:
        return self._call(lambda backend: backend.delete(file_path))

    async def adelete(self, file_path: str) -> DeleteResult:
        return await self._acall(lambda backend: backend.adelete(file_path))

    def upload_files(self, files: list[tuple[str, bytes]]) -> list[FileUploadResponse]:
        return self._call(lambda backend: backend.upload_files(files))

    async def aupload_files(self, files: list[tuple[str, bytes]]) -> list[FileUploadResponse]:
        return await self._acall(lambda backend: backend.aupload_files(files))

    def download_files(self, paths: list[str]) -> list[FileDownloadResponse]:
        return self._call(lambda backend: backend.download_files(paths))

    async def adownload_files(self, paths: list[str]) -> list[FileDownloadResponse]:
        return await self._acall(lambda backend: backend.adownload_files(paths))

    def execute(self, command: str, *, timeout: int | None = None) -> ExecuteResponse:
        if timeout is not None:
            try:
                return self._call(
                    lambda backend: backend.execute(command, timeout=timeout), execute=True
                )
            except TypeError:
                return self._call(lambda backend: backend.execute(command), execute=True)
        return self._call(lambda backend: backend.execute(command), execute=True)

    async def aexecute(
        self,
        command: str,
        *,
        timeout: int | None = None,  # noqa: ASYNC109 - native backend timeout contract
    ) -> ExecuteResponse:
        try:
            if timeout is not None:
                return await self._acall(
                    lambda backend: backend.aexecute(command, timeout=timeout), execute=True
                )
            return await self._acall(lambda backend: backend.aexecute(command), execute=True)
        except TypeError:
            return await self._acall(lambda backend: backend.aexecute(command), execute=True)

    async def aopen(self, *, wait: bool = True) -> str:
        """Adopt or create this thread's sandbox now, as its first use would; return its name."""
        if wait or self._resolved_backend is not None:
            return (await self._abackend()).id
        source = self._source
        name = await asyncio.to_thread(
            _claim_managed_sandbox, source.sandbox, self._config(), source.selection
        )
        # A sandbox handle without a name only tells its name once it is ready.
        return name if name is not None else (await self._abackend()).id

    def _config(self) -> ManagedRunConfig | None:
        return _effective_sandbox_run_config(
            self._source.run_config, bound_configurable=self._bound_configurable
        )

    async def _sync_sandbox_proxy_config(self) -> None:
        config = self._config()
        key = _thread_scope_key(config, self._source.selection)
        await self._source.proxy_config_sync.sync(
            self._source.sandbox,
            _peek_managed_host_name(key),
            config,
        )

    def _backend(self) -> SandboxBackendProtocol:
        if self._resolved_backend is not None:
            return self._resolved_backend
        source = self._source
        backend = _resolve_managed_sandbox(
            source.sandbox,
            self._config(),
            connectors=source.connectors,
            identity=source.identity,
            selection=source.selection,
        )
        self._keep(backend)
        return backend

    async def _abackend(self) -> SandboxBackendProtocol:
        if self._resolved_backend is not None:
            return self._resolved_backend
        source = self._source
        backend = await asyncio.to_thread(
            _resolve_managed_sandbox,
            source.sandbox,
            self._config(),
            source.connectors,
            source.identity,
            source.selection,
        )
        self._keep(backend)
        return backend

    def _recover(self, backend: SandboxBackendProtocol, error: Exception) -> None:
        if not _is_sandbox_not_found_error(error):
            return
        source = self._source
        config = self._config()
        if _parent_sandbox_scope(config, source.selection) is not None:
            # The lead recovers its own sandbox; helpers must not recreate it.
            return
        previous_name = _peek_managed_host_name(_thread_scope_key(config, source.selection))
        try:
            recovered = _recover_managed_sandbox(
                source.sandbox,
                config,
                backend,
                source.connectors,
                source.identity,
                source.selection,
            )
        except Exception:  # noqa: BLE001
            return
        if recovered is not backend:
            source.proxy_config_sync.invalidate(previous_name)
        if self._resolved_backend is backend:
            self._keep(recovered)

    def _call(
        self,
        operation: Callable[[SandboxBackendProtocol], _ResultT],
        *,
        execute: bool = False,
    ) -> _ResultT:
        from managed_deepagents._sandbox_proxy import run_sync  # noqa: PLC0415

        backend = self._backend()
        try:
            if execute:
                run_sync(self._sync_sandbox_proxy_config())
            return operation(backend)
        except Exception as error:
            self._recover(backend, error)
            raise

    async def _acall(
        self,
        operation: Callable[[SandboxBackendProtocol], Awaitable[_ResultT]],
        *,
        execute: bool = False,
    ) -> _ResultT:
        backend = await self._abackend()
        try:
            if execute:
                await self._sync_sandbox_proxy_config()
            result = operation(backend)
            # Provider stand-ins may implement an ``a*`` method synchronously.
            if inspect.isawaitable(result):
                return await result
            return cast("_ResultT", result)
        except Exception as error:
            await asyncio.to_thread(self._recover, backend, error)
            raise


def _managed_sandbox_backend(
    sandbox: SandboxDefinition,
    run_config: ManagedRunConfig | None,
    *,
    connectors: list[Connector] | None = None,
    identity: IdentityDefinitionLike | None = None,
    selection: _SandboxSelection | None = None,
) -> _LazyManagedSandboxBackend:
    from managed_deepagents._sandbox_proxy import SandboxProxyConfigSync  # noqa: PLC0415

    return _LazyManagedSandboxBackend(
        _LazySandboxSource(
            sandbox,
            run_config,
            connectors=connectors,
            identity=identity,
            selection=selection,
            proxy_config_sync=SandboxProxyConfigSync(),
        ),
        None,
    )


def _effective_sandbox_run_config(
    run_config: ManagedRunConfig | None,
    *,
    bound_configurable: Mapping[str, object] | None = None,
) -> ManagedRunConfig | None:
    """Merge bound/ambient LangGraph ``configurable`` into the factory-closed run config.

    Sandbox connector hooks (e.g. GitHub credential injection) need
    the live ``langgraph_auth_user``; the compile-time bag often lacks it.
    """
    # The Agent Server hands over an untyped mapping; check before reading.
    closed = run_config if isinstance(run_config, Mapping) else None
    closed_configurable = closed.get("configurable") if closed is not None else None
    seed: dict[str, Any] = {}
    if isinstance(closed_configurable, Mapping):
        seed.update(closed_configurable)
    if bound_configurable is not None:
        seed.update(bound_configurable)
    configurable = resolve_runtime_configurable({"configurable": seed} if seed else closed)
    if configurable is None:
        return run_config
    merged: ManagedRunConfig = closed.copy() if closed is not None else {}
    existing = merged.get("configurable")
    base: dict[str, Any] = dict(existing) if isinstance(existing, Mapping) else {}
    base.update(configurable)
    merged["configurable"] = base
    return merged


def _read_context_instructions(context_backend: BackendProtocol) -> str | None:
    """Load deploy-owned ``instructions.md`` from Context Hub as the system prompt.

    Prefer ``download_files`` (full raw bytes, no line-limit truncation). Fall
    back to ``read`` and use the ``ReadResult.file_data`` content.
    """
    downloaded = _download_context_file(context_backend, "/instructions.md")
    if downloaded is not None:
        return downloaded

    # Large limit: ``read`` defaults to a few hundred lines, which can truncate prompts.
    result = context_backend.read("/instructions.md", offset=0, limit=10_000_000)
    if result.error or result.file_data is None:
        return None
    return result.file_data["content"]


def _resolve_managed_sandbox(
    sandbox: SandboxDefinition,
    config: ManagedRunConfig | None,
    connectors: list[Connector] | None = None,
    identity: IdentityDefinitionLike | None = None,
    selection: _SandboxSelection | None = None,
) -> SandboxBackendProtocol:
    """Resolve (and cache) the per-thread sandbox backend.

    Connectors that implement ``sandbox`` run on create, when a new thread
    starts against a reused sandbox (mode ``"reuse"``), and again on later
    messages in an already-synced thread (mode ``"credentials"``) so token /
    CLI wiring can refresh without re-cloning. Provisioning (``setup.sh``)
    happens at deploy bake, not here.
    """
    key = _thread_scope_key(config, selection)
    thread_key = _thread_sync_key(config)
    has_sandbox = has_sandbox_connectors(connectors)

    # Serialize same-key resolve/provision; different keys use different locks
    # so unrelated cold creates stay parallel.
    with _sandbox_key_lock(key):
        with _managed_sandbox_lock:
            entry = _managed_sandboxes.get(key)

        if entry is not None:
            _warn_selection_changed(entry, selection, config)
            # A helper sharing its lead's sandbox only refreshes credentials: the
            # lead's workspace is already set up.
            helper = _parent_sandbox_scope(config, selection) is not None
            if has_sandbox and (thread_key in entry.synced_threads or helper):
                # Same thread: refresh credentials / CLI wiring without re-cloning.
                run_connector_sandbox_hooks(
                    connectors,
                    backend=entry.backend,
                    mode="credentials",
                    config=config,
                    identity=identity,
                )
            elif has_sandbox:
                run_connector_sandbox_hooks(
                    connectors,
                    backend=entry.backend,
                    mode="reuse",
                    config=config,
                    identity=identity,
                )
                entry.synced_threads.add(thread_key)
            return entry.backend

        # Cold create/provision while holding only the per-key lock. Do not hold
        # ``_managed_sandbox_lock`` here — websocket retries can take tens of
        # seconds and would wedge every other Host worker. A helper adopting its
        # lead's sandbox only refreshes credentials; one whose lead hasn't
        # created it yet creates it under the lead's scope for the lead to adopt.
        helper = _parent_sandbox_scope(config, selection) is not None
        with _managed_sandbox_lock:
            # A claimed sandbox that fails to boot is claimed afresh by the next use.
            claim = _claimed_sandboxes.pop(key, None)
        backend, host_name, sandbox_id = _create_langsmith_sandbox(
            sandbox,
            config=config,
            connectors=connectors,
            identity=identity,
            sandbox_mode="create",
            adopted_mode="credentials" if helper else "reuse",
            scope_key=key,
            selection=selection,
            claim=claim,
        )
        entry = _ManagedSandboxEntry(
            backend,
            host_name=host_name,
            sandbox_id=sandbox_id,
            selection_fingerprint=selection.fingerprint if selection is not None else None,
        )
        entry.synced_threads.add(thread_key)
        with _managed_sandbox_lock:
            _managed_sandboxes[key] = entry
        return entry.backend


def _claim_managed_sandbox(
    sandbox: SandboxDefinition,
    config: ManagedRunConfig | None,
    selection: _SandboxSelection | None = None,
) -> str | None:
    """Adopt the per-thread sandbox, or create it without waiting for it to boot; its name.

    ``_resolve_managed_sandbox`` waits for the sandbox, and runs the connectors'
    hooks, on its first use.
    """
    key = _thread_scope_key(config, selection)
    with _sandbox_key_lock(key):
        with _managed_sandbox_lock:
            entry = _managed_sandboxes.get(key)
            claim = _claimed_sandboxes.get(key)
        if entry is not None:
            return entry.host_name or entry.backend.id
        if claim is None:
            claim = _claim_langsmith_sandbox(
                sandbox, config=config, scope_key=key, selection=selection, wait=False
            )
            with _managed_sandbox_lock:
                _claimed_sandboxes[key] = claim
        return claim.host_name


def _is_sandbox_not_found_error(error: Exception) -> bool:
    from langsmith.sandbox import ResourceNotFoundError, SandboxConnectionError  # noqa: PLC0415

    if isinstance(error, ResourceNotFoundError):
        return True
    if isinstance(error, SandboxConnectionError):
        response = getattr(error.__cause__, "response", None)
        return getattr(response, "status_code", None) == HTTPStatus.NOT_FOUND
    return False


def _recover_managed_sandbox(
    sandbox: SandboxDefinition,
    config: ManagedRunConfig | None,
    failed_backend: SandboxBackendProtocol,
    connectors: list[Connector] | None = None,
    identity: IdentityDefinitionLike | None = None,
    selection: _SandboxSelection | None = None,
) -> SandboxBackendProtocol:
    from langsmith.sandbox import ResourceNotFoundError  # noqa: PLC0415

    key = _thread_scope_key(config, selection)
    with _sandbox_key_lock(key):
        with _managed_sandbox_lock:
            entry = _managed_sandboxes.get(key)
        if entry is None:
            return failed_backend
        current = entry.backend
        if current is not failed_backend or entry.host_name is None:
            return current
        client = _sandbox_client_for(sandbox)
        try:
            existing = _await_if_needed(client.get_sandbox(entry.host_name))
        except ResourceNotFoundError:
            existing = None
        if existing is not None and _sandbox_handle_id(existing) == entry.sandbox_id:
            return current
        backend, host_name, sandbox_id = _create_langsmith_sandbox(
            sandbox,
            config=config,
            connectors=connectors,
            identity=identity,
            scope_key=key,
            selection=selection,
            recovery_name=entry.host_name,
            existing_sandbox=existing,
        )
        replacement = _ManagedSandboxEntry(
            backend,
            host_name=host_name,
            sandbox_id=sandbox_id,
            selection_fingerprint=selection.fingerprint if selection is not None else None,
        )
        replacement.synced_threads.add(_thread_sync_key(config))
        with _managed_sandbox_lock:
            _managed_sandboxes[key] = replacement
        return backend


def _thread_sync_key(
    config: ManagedRunConfig | None,
) -> str:
    """Per-thread sync key (always the thread scope key)."""
    return _thread_scope_key(config)


@dataclass(frozen=True, slots=True)
class _SandboxSelection:
    """Digests of a dynamic sandbox selection's identity options and of its mounts alone."""

    fingerprint: str
    mounts_fingerprint: str | None


def _sandbox_selection(sandbox: SandboxDefinition) -> _SandboxSelection:
    """Fingerprint a dynamic selection: its options for create, its mounts for the box key."""
    mount_config = sandbox.options.get("mount_config")
    mounts = mount_config.get("mounts") if isinstance(mount_config, Mapping) else None
    return _SandboxSelection(
        fingerprint=_sandbox_selection_fingerprint(sandbox),
        mounts_fingerprint=_sandbox_value_digest(mounts) if mounts else None,
    )


def _with_selection_mounts(scope: str, selection: _SandboxSelection | None) -> str:
    """Add a selection's mounts to a thread scope, so per-user mounts never share a box."""
    mounts = selection.mounts_fingerprint if selection is not None else None
    return f"{scope}:mounts:{mounts}" if mounts else scope


def _warn_selection_changed(
    entry: _ManagedSandboxEntry,
    selection: _SandboxSelection | None,
    config: ManagedRunConfig | None,
) -> None:
    """Warn when a run's selection options differ from those the live box was created with."""
    if (
        selection is None
        or entry.selection_fingerprint is None
        or entry.selection_fingerprint == selection.fingerprint
    ):
        return
    logger.warning(
        "sandbox options changed on thread %s; they apply only when a new sandbox is created",
        _thread_id_from_config(config),
    )


def _sandbox_value_digest(value: object) -> str:
    canonical = _canonical_sandbox_value(value, set())
    encoded = json.dumps(canonical, separators=(",", ":"), ensure_ascii=False)
    return hashlib.sha256(encoded.encode()).hexdigest()


def _sandbox_selection_fingerprint(sandbox: SandboxDefinition) -> str:
    """Return a stable digest of only the sandbox identity options, without exposing them."""
    options = sandbox.options
    registry = options.get("registry")
    mount_config = options.get("mount_config")
    identity = {
        "snapshot_id": options.get("snapshot_id"),
        "snapshot_name": options.get("snapshot_name"),
        "docker_image": options.get("docker_image"),
        "registry_url": registry.get("url") if isinstance(registry, Mapping) else None,
        "vcpus": options.get("vcpus"),
        "mem_bytes": options.get("mem_bytes"),
        "fs_capacity_bytes": options.get("fs_capacity_bytes"),
        "mounts": mount_config.get("mounts") if isinstance(mount_config, Mapping) else None,
    }
    return _sandbox_value_digest(
        {key: value for key, value in identity.items() if value is not None}
    )


def _canonical_sandbox_value(  # noqa: C901, PLR0911, PLR0912 - exhaustive type boundary
    value: object, ancestors: set[int]
) -> object:
    """Canonicalize supported sandbox option values or reject ambiguity."""
    from managed_deepagents._connections import (  # noqa: PLC0415
        is_connection_reference,
    )
    from managed_deepagents.sandbox import ConnectionHeader  # noqa: PLC0415

    if value is None:
        return ["null"]
    if isinstance(value, bool):
        return ["boolean", value]
    if isinstance(value, str):
        return ["string", value]
    if isinstance(value, int):
        return ["integer", str(value)]
    if isinstance(value, float):
        if not math.isfinite(value):
            raise TypeError("sandbox options must contain finite numbers")
        rendered = "-0" if value == 0 and math.copysign(1, value) < 0 else repr(value)
        return ["number", rendered]
    if is_connection_reference(value):
        owner = value.owner
        return ["connection", value.slug, owner["type"], owner.get("id")]
    if isinstance(value, ConnectionHeader):
        return [
            "connection_header",
            value.format,
            value.username,
            _canonical_sandbox_value(value.connection, ancestors),
        ]

    identity = id(value)
    if identity in ancestors:
        raise TypeError("sandbox options must not contain cycles")
    if isinstance(value, Mapping):
        if not all(isinstance(key, str) for key in value):
            raise TypeError("sandbox option mapping keys must be strings")
        ancestors.add(identity)
        try:
            mapping = cast("Mapping[str, object]", value)
            return [
                "object",
                [
                    [key, _canonical_sandbox_value(mapping[key], ancestors)]
                    for key in sorted(mapping)
                ],
            ]
        finally:
            ancestors.remove(identity)
    if isinstance(value, (list, tuple)):
        ancestors.add(identity)
        try:
            return [
                "array",
                [_canonical_sandbox_value(item, ancestors) for item in value],
            ]
        finally:
            ancestors.remove(identity)
    raise TypeError("sandbox options contain an unsupported value")


def _thread_scope_key(
    config: ManagedRunConfig | None,
    selection: _SandboxSelection | None = None,
) -> str:
    """Derive the process-level reuse key for a thread and any dynamic selection's mounts.

    A dynamic selection's other options never change the key, so a live thread
    keeps its box when they change. An async subagent sharing its lead's sandbox
    uses the lead's sandbox scope, so both resolve, sync, and never invalidate the
    same sandbox.
    """
    if (shared := _parent_sandbox_scope(config, selection)) is not None:
        return shared
    thread_key = f"thread:{_thread_id_from_config(config)}"
    return _with_selection_mounts(thread_key, selection)


#: ``configurable`` key where deepagents puts an async subagent run's parent reference.
_PARENT_REFERENCE_KEY = "deepagents_parent"
#: Run metadata key (copied from the task thread) naming an async subagent's lead thread.
_PARENT_THREAD_METADATA_KEY = "parent_thread_id"
#: The lead thread this run's caller may access, set once per run by ``parent_run``.
_VERIFIED_LEAD_THREAD: ContextVar[str | None] = ContextVar("mda_verified_lead_thread", default=None)


def _lead_thread(config: ManagedRunConfig | Mapping[str, object] | None) -> str | None:
    """The thread of the agent that launched this async subagent run, if deepagents sent it.

    Read from deepagents' parent reference, or else from the task thread's
    ``parent_thread_id`` metadata, which the Agent Server copies into every run
    on the thread, including runs deepagents didn't start (such as a resume).
    """
    configurable = config.get("configurable") if isinstance(config, Mapping) else None
    reference = (
        configurable.get(_PARENT_REFERENCE_KEY) if isinstance(configurable, Mapping) else None
    )
    thread_id = reference.get("thread_id") if isinstance(reference, Mapping) else None
    if thread_id is None:
        metadata = config.get("metadata") if isinstance(config, Mapping) else None
        thread_id = (
            metadata.get(_PARENT_THREAD_METADATA_KEY) if isinstance(metadata, Mapping) else None
        )
    return thread_id if isinstance(thread_id, str) and thread_id else None


def _parent_sandbox_scope(
    config: ManagedRunConfig | Mapping[str, object] | None,
    selection: _SandboxSelection | None = None,
) -> str | None:
    """Return the lead's sandbox scope when this run may share the lead's sandbox.

    MDA keys and names sandboxes by thread scope, so the lead's thread is enough
    to find its sandbox: the same process's cache, or the same deterministic
    name in LangSmith. Requires ``parent_run`` to have verified that this run's
    caller owns the lead's thread; otherwise the run keeps its own sandbox.
    Called on every sandbox operation, so it doesn't log.
    """
    lead_thread = _lead_thread(config)
    if lead_thread is None or _VERIFIED_LEAD_THREAD.get() != lead_thread:
        return None
    scope = f"thread:{lead_thread}"
    return _with_selection_mounts(scope, selection)


def _thread_id_from_config(config: ManagedRunConfig | None) -> str:
    thread_id = _config_value(config, "thread_id")
    if thread_id is None:
        raise RuntimeError(
            "managed sandboxes require configurable.thread_id (one sandbox per thread)"
        )
    return thread_id


def _config_value(config: Mapping[str, object] | None, key: str) -> str | None:
    if config is None:
        return None
    for container_key in ("metadata", "configurable"):
        container = config.get(container_key)
        if isinstance(container, Mapping):
            value = container.get(key)
            if value is not None:
                return str(value)
    return None


def _managed_deployment_name(env: Mapping[str, str] | None = None) -> str | None:
    """Deployment this runtime belongs to, used to name the sandboxes it creates.

    ``MDA_DEPLOYMENT_NAME`` is injected by ``mda deploy``;
    ``LANGSMITH_DEPLOYMENT_NAME`` is the platform's own value and is preferred
    when present. Under ``mda dev`` sandboxes fall back to
    :func:`_local_dev_deployment_name`, but a given ``env`` never does.
    """
    values = os.environ if env is None else env
    return (
        _string_option(values.get("LANGSMITH_DEPLOYMENT_NAME"))
        or _string_option(values.get("MDA_DEPLOYMENT_NAME"))
        or (_local_dev_deployment_name() if env is None else None)
    )


# The dev server's project directory, read once at import: runs ask for it on the
# event loop, where ``os.getcwd()`` is a blocking call ``langgraph dev`` fails the run for.
_PROJECT_DIRECTORY = Path.cwd()


def _local_dev_deployment_name() -> str | None:
    """A stable name for ``mda dev`` boxes, so a restarted dev server finds its threads' boxes.

    Unique per machine and project directory, so two projects never share a box.
    """
    if os.environ.get("MDA_LOCAL_DEV") != "1":
        return None
    machine = f"{socket.gethostname()}\0{_PROJECT_DIRECTORY}"
    return f"mda-dev-{hashlib.sha256(machine.encode()).hexdigest()[:8]}"


def _managed_sandbox_name(deployment: str, scope_key: str) -> str:
    """Deterministic sandbox name for a deployment and thread.

    The thread key is digested rather than embedded so names stay short and
    stable across container restarts. Recipe (``setup.sh`` / bake base) changes
    do **not** rename live boxes — new threads clone the new recipe; live threads
    keep ``/workspace`` until idle reclaim.
    """
    return _managed_sandbox_name_with_deployment_limit(
        deployment,
        scope_key,
        _MAX_PRIMARY_DEPLOYMENT_COMPONENT_LENGTH,
    )


def _legacy_provisioning_fingerprint(
    create_options: Mapping[str, object] | None,
) -> str:
    """Stable string 0.5.x hashed into the sandbox name.

    0.5.x serialized ``[sorted entries, setup_script]``. ``setup.sh`` was never
    a documented name input, so reconnect always uses the empty-script form.
    """
    options = sorted((create_options or {}).items())
    return json.dumps([options, ""], sort_keys=True, default=str)


def _legacy_sandbox_create_kwargs(sandbox: SandboxDefinition) -> dict[str, object]:
    """Create options 0.5.x included in the sandbox-name fingerprint.

    Mirrors the 0.5.x ``_sandbox_create_kwargs`` rest-spread: ``template_name``
    becomes ``snapshot_name``, and managed keys are dropped.
    """
    create_kwargs = {
        key: value
        for key, value in sandbox.options.items()
        if key not in {"scope", "api_key", "default_timeout", "template_name"}
    }
    from managed_deepagents._sandbox_proxy import static_sandbox_proxy_config  # noqa: PLC0415

    if "proxy_config" in create_kwargs:
        create_kwargs["proxy_config"] = static_sandbox_proxy_config(create_kwargs["proxy_config"])
    template_name = _string_option(sandbox.options.get("template_name"))
    if template_name:
        create_kwargs["snapshot_name"] = template_name
    return create_kwargs


def _legacy_managed_sandbox_name(
    deployment: str,
    scope_key: str,
    create_options: Mapping[str, object] | None = None,
) -> str:
    """Reconstruct the 0.5.x Host box name for one thread.

    0.5.x hashed the thread scope plus the options it sent to Host. 0.6.0
    hashes only the thread id, so a live 0.5.x box is invisible under the new
    name. Used only to reconnect that existing box — new threads are created
    under :func:`_managed_sandbox_name`.
    """
    fingerprint = _legacy_provisioning_fingerprint(create_options)
    digest = hashlib.sha256(f"{scope_key}\0{fingerprint}".encode()).hexdigest()[
        :_SANDBOX_DIGEST_LENGTH
    ]
    return f"{deployment}{_SANDBOX_NAME_SEPARATOR}{digest}"


def _managed_sandbox_lookup_names(
    deployment: str,
    scope_key: str,
    sandbox: SandboxDefinition,
    config: ManagedRunConfig | None = None,
    selection: _SandboxSelection | None = None,
) -> list[str]:
    """Create name, then 0.9.x and 0.5.x names that only reconnect a live box."""
    names = [_managed_sandbox_name(deployment, scope_key)]
    if selection is not None:
        options_key = f"{_thread_scope_key(config)}:sandbox:{selection.fingerprint}"
        names.append(_managed_sandbox_name(deployment, options_key))
    names.append(
        _legacy_managed_sandbox_name(
            deployment,
            scope_key,
            _legacy_sandbox_create_kwargs(sandbox),
        )
    )
    return list(dict.fromkeys(names))


def _managed_sandbox_name_with_deployment_limit(
    deployment: str,
    scope_key: str,
    deployment_limit: int,
) -> str:
    digest = hashlib.sha256(scope_key.encode()).hexdigest()[:_SANDBOX_DIGEST_LENGTH]
    component = _sandbox_deployment_component(deployment, deployment_limit)
    return f"{component}{_SANDBOX_NAME_SEPARATOR}{digest}"


def _sandbox_deployment_component(deployment: str, max_length: int) -> str:
    if len(deployment) <= max_length:
        return deployment
    digest = hashlib.sha256(deployment.encode()).hexdigest()[:_SANDBOX_DEPLOYMENT_DIGEST_LENGTH]
    prefix_length = max_length - _SANDBOX_DEPLOYMENT_DIGEST_LENGTH - 1
    return f"{deployment[:prefix_length]}-{digest}"


def _fetch_sandbox(client: LangSmithSandboxClient, name: str) -> Sandbox | None:
    """Look up a sandbox by name; ``None`` only when LangSmith confirms it is not there.

    Any other failure (a timeout, a 5xx) fails the open: the sandbox may still
    exist, and creating beside it would give the thread a second, empty one.
    """
    get_sandbox = getattr(client, "get_sandbox", None)
    if not callable(get_sandbox):
        return None
    try:
        return _await_if_needed(get_sandbox(name))
    except Exception as error:
        if _is_sandbox_not_found_error(error):
            return None
        raise RuntimeError(f"Could not look up sandbox {name!r}; retry the run: {error}") from error


def _restart_sandbox(client: LangSmithSandboxClient, name: str, stopped: Sandbox) -> Sandbox:
    """Start a stopped sandbox so it can be adopted; raises when that fails."""
    start_sandbox = getattr(client, "start_sandbox", None)
    if not callable(start_sandbox):
        raise RuntimeError(f"Sandbox {name!r} is stopped and this client cannot start it")
    try:
        # Some SDK versions return nothing on success; it is the same sandbox.
        return _await_if_needed(start_sandbox(name)) or stopped
    except Exception as error:
        raise RuntimeError(
            f"Could not start stopped sandbox {name!r}; retry the run: {error}"
        ) from error


def _adopt_sandbox(client: LangSmithSandboxClient, name: str) -> Sandbox | None:
    """Return the existing sandbox for ``name`` when usable, else ``None``.

    ``None`` means nothing usable holds the name. A lookup or restart failure
    raises instead, so the open never creates a second sandbox for the thread.
    """
    existing = _fetch_sandbox(client, name)
    if existing is None:
        return None

    status = _string_option(getattr(existing, "status", None))
    normalized = status.lower() if status else None
    # No status reported: assume the SDK handed back a usable sandbox. One still
    # provisioning is another create's; ``_ready_sandbox`` waits for it to boot.
    if (
        normalized is None
        or normalized in _ADOPTABLE_SANDBOX_STATUS
        or normalized == _PROVISIONING_SANDBOX_STATUS
    ):
        return existing
    if normalized == _STOPPED_SANDBOX_STATUS:
        return _restart_sandbox(client, name, existing)
    return None


def _is_sandbox_name_conflict(error: Exception) -> bool:
    """True when a create failed because the sandbox name is already taken."""
    return bool(_SANDBOX_NAME_CONFLICT_RE.search(f"{type(error).__name__}: {error}"))


def _resolve_sandbox_instance(
    client: LangSmithSandboxClient,
    create_kwargs: dict[str, object],
    name: str | None,
    adopt_aliases: Iterable[str] = (),
) -> tuple[Sandbox, bool]:
    """Adopt this deployment's existing sandbox for ``name``, or create it.

    Names are deterministic per scope, so a redeployed or restarted container
    finds the sandbox its predecessor created instead of stranding it until the
    idle TTL fires. When ``name`` is ``None`` (local dev) this is a plain create.

    ``adopt_aliases`` are 0.9.0 and 0.5.x names for this thread: reconnect a box that
    already exists, never create under the old formula.

    Only a confirmed not-found lookup permits a create, and the create never falls
    back to another name: a second sandbox would hold none of the thread's work,
    and replicas could each cache a different one.

    Returns the sandbox and whether it was adopted rather than created.
    """
    # Options are a validated bag of provider kwargs, not individually typed.
    create_sandbox = cast("Callable[..., Sandbox]", client.create_sandbox)
    if name is None:
        return _await_if_needed(create_sandbox(**create_kwargs)), False

    # After invalidate, refuse to adopt the same Host name even if delete lags —
    # otherwise recreate loops on the broken box that just failed provision.
    candidates = [name, *[alias for alias in adopt_aliases if alias != name]]
    for candidate in candidates:
        existing = _adopt_sandbox(client, candidate)
        if existing is not None and not _sandbox_name_blocked(candidate):
            return existing, True

    try:
        created = _await_if_needed(create_sandbox(name=name, **create_kwargs))
        _unblock_sandbox_name(name)
        return created, False
    except Exception as error:
        if not _is_sandbox_name_conflict(error):
            raise
        # Either a concurrent container won the create race (its sandbox may
        # still be provisioning), or an unusable sandbox (failed, mid-delete)
        # still holds the name. Never adopt a name we just invalidated.
        winner = None if _sandbox_name_blocked(name) else _adopt_sandbox(client, name)
        if winner is None:
            raise RuntimeError(
                f"Sandbox name {name!r} is held by a sandbox that cannot be used; retry the run"
            ) from error
        return winner, True


def _create_replacement_sandbox(
    client: LangSmithSandboxClient, create_kwargs: dict[str, object], name: str
) -> tuple[Sandbox, bool]:
    from langsmith.sandbox import (  # noqa: PLC0415
        ResourceAlreadyExistsError,
        ResourceNameConflictError,
    )

    # Options are a validated bag of provider kwargs, not individually typed.
    create_sandbox = cast("Callable[..., Sandbox]", client.create_sandbox)
    try:
        return _await_if_needed(create_sandbox(name=name, **create_kwargs)), False
    except (ResourceAlreadyExistsError, ResourceNameConflictError):
        return _await_if_needed(client.get_sandbox(name)), True


def _ready_sandbox(claim: _SandboxClaim) -> Sandbox:
    """The claimed sandbox once it has booted; raises if it fails to boot."""
    sandbox = claim.sandbox
    status = _string_option(getattr(sandbox, "status", None))
    name = _sandbox_handle_name(sandbox) or claim.host_name
    if status is None or status.lower() != _PROVISIONING_SANDBOX_STATUS or name is None:
        return sandbox
    return _await_if_needed(claim.client.wait_for_sandbox(name))


def _create_langsmith_sandbox(
    sandbox: SandboxDefinition,
    *,
    config: ManagedRunConfig | None = None,
    connectors: list[Connector] | None = None,
    identity: IdentityDefinitionLike | None = None,
    sandbox_mode: Literal["create", "reuse"] = "create",
    adopted_mode: SandboxMode = "reuse",
    scope_key: str,
    selection: _SandboxSelection | None = None,
    recovery_name: str | None = None,
    existing_sandbox: Sandbox | None = None,
    claim: _SandboxClaim | None = None,
) -> tuple[SandboxBackendProtocol, str | None, str | None]:
    """Build a LangSmith sandbox, optionally from the baked recipe, and wrap it.

    A ``claim`` already adopted or created the sandbox; it is waited for here.
    """
    if claim is None:
        claim = _claim_langsmith_sandbox(
            sandbox,
            config=config,
            scope_key=scope_key,
            selection=selection,
            recovery_name=recovery_name,
            existing_sandbox=existing_sandbox,
        )
    langsmith_sandbox = _ready_sandbox(claim)
    adopted = claim.adopted
    host_name = _sandbox_handle_name(langsmith_sandbox) or claim.host_name
    logger.info(
        "sandbox resolve: %s name=%r id=%r scope=%r",
        "adopted" if adopted else "created",
        host_name,
        _sandbox_handle_id(langsmith_sandbox),
        scope_key,
    )
    # The optional SDK client returns its provider handle across a dynamic boundary.
    backend = LangSmithSandbox(sandbox=langsmith_sandbox)

    configured_timeout = cast("int | None", sandbox.options.get("default_timeout"))
    resolved = backend
    if configured_timeout is not None and hasattr(resolved, "_default_timeout"):
        resolved._default_timeout = configured_timeout  # noqa: SLF001

    run_connector_sandbox_hooks(
        connectors,
        backend=resolved,
        # An adopted sandbox already ran create-time connector hooks in an
        # earlier process, so treat it as a reuse for connector purposes.
        mode=adopted_mode if adopted else sandbox_mode,
        config=config,
        identity=identity,
    )

    return resolved, host_name, _sandbox_handle_id(langsmith_sandbox)


def _claim_langsmith_sandbox(
    sandbox: SandboxDefinition,
    *,
    config: ManagedRunConfig | None,
    scope_key: str,
    selection: _SandboxSelection | None,
    recovery_name: str | None = None,
    existing_sandbox: Sandbox | None = None,
    wait: bool = True,
) -> _SandboxClaim:
    """Adopt this scope's LangSmith sandbox or create it; without ``wait``, before it boots.

    A stopped sandbox still restarts here and waits: the SDK's start always waits.
    """
    create_kwargs = _sandbox_create_kwargs(sandbox, selection)
    if not wait:
        create_kwargs["wait_for_ready"] = False
    client = _sandbox_client_for(sandbox)
    deployment = _managed_deployment_name()
    lookup_names = (
        _managed_sandbox_lookup_names(deployment, scope_key, sandbox, config, selection)
        if deployment
        else []
    )
    sandbox_name = recovery_name or (lookup_names[0] if lookup_names else None)
    if existing_sandbox is not None:
        langsmith_sandbox, adopted = existing_sandbox, True
    elif recovery_name:
        langsmith_sandbox, adopted = _create_replacement_sandbox(
            client, create_kwargs, recovery_name
        )
    else:
        langsmith_sandbox, adopted = _resolve_sandbox_instance(
            client, create_kwargs, sandbox_name, lookup_names[1:]
        )
    return _SandboxClaim(
        client,
        langsmith_sandbox,
        adopted=adopted,
        host_name=_sandbox_handle_name(langsmith_sandbox) or sandbox_name,
    )


def _string_option(value: object) -> str | None:
    if isinstance(value, str) and value.strip():
        return value.strip()
    return None
