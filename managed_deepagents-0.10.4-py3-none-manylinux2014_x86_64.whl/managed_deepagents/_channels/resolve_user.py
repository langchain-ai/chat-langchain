"""Map a channel's verified sender to one of the app's users."""

from __future__ import annotations

import asyncio
import inspect
import json
from collections.abc import Awaitable, Callable, Mapping
from typing import TYPE_CHECKING, Annotated, Literal, NotRequired, TypeAlias, cast

from pydantic import AfterValidator, BaseModel, ConfigDict, Field, TypeAdapter, ValidationError
from typing_extensions import TypedDict

from managed_deepagents._agent_auth import WORKSPACE_SETTING
from managed_deepagents._agent_auth_http import ConnectionsNotConfiguredError
from managed_deepagents._channels.actor import EndpointActor, actor_identity, endpoint_actor
from managed_deepagents._channels.http.endpoint import (
    EndpointClient,
    EndpointLimits,
    EventEndpoint,
    is_event_endpoint,
)
from managed_deepagents._channels.runtime import create_runtime_channel, validate_message
from managed_deepagents._channels.scalars import Nonblank  # noqa: TC001 - pydantic reads it
from managed_deepagents._connections import (
    TRUSTED_BACKEND_PROVIDER,
    resolve_external_principal_id,
    resolve_workspace_id,
)
from managed_deepagents._log import logger

if TYPE_CHECKING:
    from managed_deepagents._agent_auth import ResolvePrincipalIdentity
    from managed_deepagents._channels.actor import ChannelActor
    from managed_deepagents._channels.runtime import ChannelMessagingAdapter
    from managed_deepagents._channels.types import ChannelMessage, JsonValue


class ResolveUserChannel(TypedDict):
    name: str


class ResolveUserRequest(TypedDict):
    """What ``resolve_user`` gets: the verified sender of a channel delivery.

    Experimental: this may change in a minor release.
    """

    actor: ChannelActor | None
    """``None`` when the channel could not verify who sent the delivery."""
    channel: ResolveUserChannel


class ResolvedAppUser(TypedDict):
    """One of your users: the principal a backend call with ``auth="backend"`` gets."""

    type: Literal["user"]
    id: str


class ResolvedIdentity(TypedDict):
    """An exact Agent Auth identity, such as the IdP ``sub`` your web users sign in with."""

    type: Literal["identity"]
    provider: str
    issuer: str
    subject: str


class ResolvedReply(TypedDict):
    """Start nothing, and post ``message`` where the delivery came from, as
    ``runtime.channel.post`` would."""

    type: Literal["reply"]
    message: ChannelMessage


class ResolvedIgnore(TypedDict):
    """Start nothing."""

    type: Literal["ignore"]


ResolveUserResult: TypeAlias = (
    ResolvedAppUser | ResolvedIdentity | ResolvedReply | ResolvedIgnore | None
)
"""Who a channel delivery runs as; ``None`` keeps the channel's own principal.

Experimental: this may change in a minor release.
"""

ResolveUser: TypeAlias = Callable[
    [ResolveUserRequest], ResolveUserResult | Awaitable[ResolveUserResult]
]
"""Map a channel's verified sender to one of your users.

Experimental: this may change in a minor release.
"""


class ResolveUserEndpointRequest(TypedDict):
    """What a ``resolve_user`` endpoint is POSTed: the ``ResolveUserRequest``, with
    the actor in camelCase, as TypeScript's, and absent when unverified."""

    actor: NotRequired[EndpointActor]
    channel: ResolveUserChannel


_ENDPOINT_TIMEOUT_SECONDS = 5.0
"""How long a ``resolve_user`` endpoint may take, both attempts and the pause
between. The delivery waits on it before MDA acknowledges it, and Trigger Server
gives up on a delivery after 10 seconds."""
_ENDPOINT_RETRY_DELAYS_SECONDS = (0.5,)
"""The pause before the one more attempt after a network error, HTTP 429 or a 5xx."""


class ResolveUserEndpoint:
    """A ``resolve_user`` that is an endpoint: a URL, or an ``httpx.Request`` that
    also carries headers, such as a credential the service checks.

    Before a delivery starts a run, MDA POSTs a ``ResolveUserEndpointRequest`` as
    JSON to the URL, with the request's headers, signed when the deployment has
    ``MDA_SERVICE_SECRET``, with the webhook ID ``msg_<deliveryId>_resolve_user``.
    The service answers with a ``ResolveUserResult``, checked as a function's;
    ``null`` or HTTP 204 keeps the channel's own principal. A network error, HTTP
    429 or a 5xx is tried again once. Any other answer, a redirect, or no answer
    within 5 seconds fails the delivery, as a function that raises does. A retry
    and a redelivery keep the webhook ID, so the service answers each request
    and never dedupes on it.
    """

    def __init__(self, endpoint: EventEndpoint, label: str) -> None:
        self._client = EndpointClient(endpoint, label, "resolve_user endpoint")

    async def ask(self, request: ResolveUserRequest, delivery_id: str) -> JsonValue | None:
        """The service's answer about one delivery's sender, not yet checked."""
        sent: ResolveUserEndpointRequest = {"channel": request["channel"]}
        if request["actor"] is not None:
            sent["actor"] = endpoint_actor(request["actor"])
        return await self._client.ask(
            f"msg_{delivery_id}_resolve_user",
            json.dumps(sent).encode(),
            EndpointLimits(_ENDPOINT_TIMEOUT_SECONDS, _ENDPOINT_RETRY_DELAYS_SECONDS, total=True),
        )


ChannelResolveUser: TypeAlias = ResolveUser | ResolveUserEndpoint
"""A declared ``resolve_user``: a function, or the service an endpoint names."""


class ChannelPrincipal(TypedDict):
    type: Literal["principal"]
    id: str


ChannelUser: TypeAlias = ChannelPrincipal | ResolvedReply | ResolvedIgnore
"""What a delivery does after ``resolve_user``.

Experimental: this may change in a minor release.
"""

_RESULT_SHAPE = (
    'resolve_user must return {"type": "user", "id"}, {"type": "identity", "provider", '
    '"issuer", "subject"}, {"type": "reply", "message"}, {"type": "ignore"} or None'
)


def _channel_message(value: object) -> object:
    if not isinstance(value, Mapping):
        raise ValueError("must be a ChannelMessage")
    validate_message(cast("Mapping[str, object]", value))
    return value


class _Result(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True)


class _UserResult(_Result):
    type: Literal["user"]
    id: Nonblank


class _IdentityResult(_Result):
    type: Literal["identity"]
    provider: Nonblank
    issuer: Nonblank
    subject: Nonblank


class _ReplyResult(_Result):
    type: Literal["reply"]
    message: Annotated[object, AfterValidator(_channel_message)]


class _IgnoreResult(_Result):
    type: Literal["ignore"]


_RESULT = TypeAdapter(
    Annotated[
        _UserResult | _IdentityResult | _ReplyResult | _IgnoreResult, Field(discriminator="type")
    ]
)
"""A result ``resolve_user`` returns, or an endpoint answers, other than ``None``."""


def checked_resolve_user(
    owner: str, resolve_user: ResolveUser | EventEndpoint | None
) -> ChannelResolveUser | None:
    """A declared ``resolve_user``, with an endpoint's URL and the deployment's
    secret checked; one that is neither callable nor an endpoint raises."""
    if is_event_endpoint(resolve_user):
        return ResolveUserEndpoint(resolve_user, f"{owner}(...) resolve_user")
    if resolve_user is not None and not callable(resolve_user):
        raise TypeError(f"{owner}(...) resolve_user must be callable or an endpoint URL")
    return resolve_user


async def resolve_channel_user(
    resolve_user: ChannelResolveUser | None,
    actor: ChannelActor | None,
    channel_name: str,
    delivery_id: str,
    resolve_principal: Callable[[ResolvePrincipalIdentity], str] | None = None,
) -> ChannelUser | None:
    """Ask ``resolve_user`` about the actor of delivery ``delivery_id``; ``None``
    keeps the channel's principal."""
    if resolve_user is None:
        return None
    request: ResolveUserRequest = {"actor": actor, "channel": {"name": channel_name}}
    result: object
    if isinstance(resolve_user, ResolveUserEndpoint):
        result = await resolve_user.ask(request, delivery_id)
    else:
        # A synchronous hook may block, so it runs off the event loop.
        result = (
            resolve_user(request)
            if inspect.iscoroutinefunction(resolve_user)
            else await asyncio.to_thread(resolve_user, request)
        )
        if inspect.isawaitable(result):
            result = await result
    if result is None:
        return None
    # An endpoint's answer is any JSON, and a function's is checked the same way.
    try:
        checked = _RESULT.validate_python(result)
    except ValidationError:
        raise TypeError(_RESULT_SHAPE) from None
    identity: ResolvePrincipalIdentity
    match checked:
        case _UserResult():
            identity = _app_user_identity(checked.id)
        case _IdentityResult():
            identity = {
                "provider": checked.provider,
                "issuer": checked.issuer,
                "subject": checked.subject,
            }
        case _ReplyResult():
            return {"type": "reply", "message": cast("ChannelMessage", checked.message)}
        case _IgnoreResult():
            return {"type": "ignore"}
    principal_id = await asyncio.to_thread(
        resolve_principal or resolve_external_principal_id, identity
    )
    return {"type": "principal", "id": principal_id}


UserResolution: TypeAlias = Literal["application_resolved", "agent_auth_principal", "channel"]
"""How ingress chose a run's user: ``application_resolved`` when ``resolve_user``
mapped the sender to one of the app's users, ``agent_auth_principal`` when the
sender ran as their own Agent Auth principal, else ``channel``."""


def user_resolution(user: ChannelUser | None, *, ran_as_sender: bool) -> UserResolution:
    if user is not None and user["type"] == "principal":
        return "application_resolved"
    if ran_as_sender:
        return "agent_auth_principal"
    return "channel"


# Whether the fallback without Agent Auth was logged already.
_logged_sender_fallback = False


async def sender_principal_id(
    actor: ChannelActor | None,
    resolve_principal: Callable[[ResolvePrincipalIdentity], str] | None = None,
) -> str | None:
    """The principal a webhook channel's sender runs as when no ``resolve_user``
    maps them, from ``actor_identity``; ``None`` runs the delivery as the channel.

    Unlike a mapped user's, it owns no user connections: whoever completes a
    connection's sign-in from a public thread would attach their account to it.
    Without Agent Auth (``mda dev`` without a LangSmith key) the channel's own
    user ID stays.
    """
    global _logged_sender_fallback  # noqa: PLW0603 - log the fallback once per process
    identity = actor_identity(actor) if actor is not None else None
    if identity is None:
        return None
    try:
        return await asyncio.to_thread(resolve_principal or resolve_external_principal_id, identity)
    except ConnectionsNotConfiguredError as error:
        if not _logged_sender_fallback:
            _logged_sender_fallback = True
            logger.warning("channel senders keep the channel's user ID: %s", error)
        return None


# Deliveries already replied to; a provider may redeliver one.
_replied_deliveries: dict[str, None] = {}
_REPLIED_DELIVERIES_KEPT = 1000


async def post_reply(
    message: ChannelMessage,
    *,
    name: str,
    provider: str,
    target: JsonValue,
    transport: ChannelMessagingAdapter | None,
    delivery_key: str | None = None,
) -> None:
    """Post ``resolve_user``'s reply through the path ``runtime.channel.post`` takes,
    once per ``delivery_key``."""
    if delivery_key is not None:
        if delivery_key in _replied_deliveries:
            return
        _replied_deliveries[delivery_key] = None
        if len(_replied_deliveries) > _REPLIED_DELIVERIES_KEPT:
            del _replied_deliveries[next(iter(_replied_deliveries))]
    post = create_runtime_channel(
        name=name, provider=provider, event=None, target=target, transport=transport
    ).post
    if post is None:
        logger.warning("channel cannot post resolve_user's reply")
        return
    try:
        await post(message)
    except Exception as error:  # noqa: BLE001 - a failed reply must not fail the delivery
        logger.error("channel resolve_user reply failed (%s)", logger.safe_error_label(error))


def _app_user_identity(user_id: str) -> ResolvePrincipalIdentity:
    workspace_id = resolve_workspace_id()
    if workspace_id is None:
        raise ConnectionsNotConfiguredError(WORKSPACE_SETTING)
    return {"provider": TRUSTED_BACKEND_PROVIDER, "issuer": workspace_id, "subject": user_id}


__all__ = [
    "ChannelResolveUser",
    "ChannelUser",
    "ResolveUser",
    "ResolveUserEndpoint",
    "ResolveUserEndpointRequest",
    "ResolveUserRequest",
    "ResolveUserResult",
    "ResolvedAppUser",
    "ResolvedIdentity",
    "ResolvedIgnore",
    "ResolvedReply",
    "checked_resolve_user",
    "post_reply",
    "resolve_channel_user",
    "sender_principal_id",
]
