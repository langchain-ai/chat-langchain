from __future__ import annotations

from typing import Optional
from typing_extensions import Literal

import httpx2

from ..._types import Body, Omit, Query, Headers, NotGiven, omit, not_given
from ..._utils import path_template
from ..._compat import cached_property
from ..._resource import SyncAPIResource, AsyncAPIResource
from ..._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ...pagination import SyncPageCursor, AsyncPageCursor
from ..._base_client import AsyncPaginator, make_request_options
from ...types.organization import external_key_create_params, external_key_update_params
from ...types.organization.external_key import ExternalKey
from ...types.organization.external_key_delete_response import ExternalKeyDeleteResponse
from ...types.organization.external_key_validate_response import ExternalKeyValidateResponse

__all__ = ["ExternalKeys", "AsyncExternalKeys"]


class ExternalKeys(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> ExternalKeysWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://platform.claude.com/docs/en/api/sdks/python
        """
        return ExternalKeysWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> ExternalKeysWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://platform.claude.com/docs/en/api/sdks/python
        """
        return ExternalKeysWithStreamingResponse(self)

    def create(
        self,
        *,
        provider_config: external_key_create_params.ProviderConfig,
        display_name: Optional[str] | Omit = omit,
        geo: Literal["us"] | Omit = omit,
        user_profile_id: Optional[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> ExternalKey:
        """
        Create an external key config owned by the caller's organization.

        Args:
          provider_config: KMS provider identity and auth coordinates.

          display_name: Human-friendly display name.

          geo: Data residency geo. Only `us` is supported.

          user_profile_id: ID of a user profile to bind the key to. A user profile represents one of your
              customers: bind a customer's key to that customer's user profile. A key bound to
              a user profile can only be attached to a Workspace that has the same user
              profile, and the binding cannot be changed later. Omit this field only for your
              organization's own key, because a key created without a user profile ID can be
              attached to any Workspace, including another customer's.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds

        Raises:
          UserProfileNotFoundError:

          SandboxEgressRestrictedError:
        """
        return self._post(
            "/v1/organizations/external_keys",
            body={
                "provider_config": provider_config,
                "display_name": display_name,
                "geo": geo,
                "user_profile_id": user_profile_id,
            },
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                span_name="anthropic.organization.external_keys.create",
                span_route="/v1/organizations/external_keys",
                span_created_id="anthropic.organization.external_key.id",
            ),
            cast_to=ExternalKey,
        )

    def retrieve(
        self,
        external_key_id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> ExternalKey:
        """
        Retrieve a single external key config in the caller's organization by ID.

        Args:
          external_key_id: ID of the External Key.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not external_key_id:
            raise ValueError(f"Expected a non-empty value for `external_key_id` but received {external_key_id!r}")
        return self._get(
            path_template("/v1/organizations/external_keys/{external_key_id}", external_key_id=external_key_id),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                span_name="anthropic.organization.external_keys.retrieve",
                span_route="/v1/organizations/external_keys/{external_key_id}",
                span_attributes={"anthropic.organization.external_key.id": external_key_id},
            ),
            cast_to=ExternalKey,
        )

    def update(
        self,
        external_key_id: str,
        *,
        display_name: Optional[str] | Omit = omit,
        geo: Optional[Literal["us"]] | Omit = omit,
        provider_config: Optional[external_key_update_params.ProviderConfig] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> ExternalKey:
        """Partially update an external key config.

        Omitted fields are left unchanged.

        `display_name` is always editable. `geo` and `provider_config` cannot be changed
        once any workspace references this config, because previously encrypted data
        requires the original key identity to decrypt.

        Args:
          external_key_id: ID of the External Key.

          display_name: Human-friendly display name.

          geo: Data residency geo. Only `us` is supported.

          provider_config: KMS provider identity and auth coordinates.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds

        Raises:
          ExternalKeyInWorkspacePolicyError:

          SandboxEgressRestrictedError:
        """
        if not external_key_id:
            raise ValueError(f"Expected a non-empty value for `external_key_id` but received {external_key_id!r}")
        return self._post(
            path_template("/v1/organizations/external_keys/{external_key_id}", external_key_id=external_key_id),
            body={
                "display_name": display_name,
                "geo": geo,
                "provider_config": provider_config,
            },
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                span_name="anthropic.organization.external_keys.update",
                span_route="/v1/organizations/external_keys/{external_key_id}",
                span_attributes={"anthropic.organization.external_key.id": external_key_id},
            ),
            cast_to=ExternalKey,
        )

    def list(
        self,
        *,
        limit: int | Omit = omit,
        page: Optional[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> SyncPageCursor[ExternalKey]:
        """
        List external key configs in the caller's organization.

        Results are ordered by creation time (newest first). Use the `next_page` cursor
        from the response to fetch subsequent pages.

        Args:
          limit: Number of results per page.

          page: Opaque cursor from a previous response's `next_page`.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get_api_list(
            "/v1/organizations/external_keys",
            page=SyncPageCursor[ExternalKey],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query={
                    "limit": limit,
                    "page": page,
                },
                span_name="anthropic.organization.external_keys.list",
                span_route="/v1/organizations/external_keys",
            ),
            model=ExternalKey,
        )

    def delete(
        self,
        external_key_id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> ExternalKeyDeleteResponse:
        """
        Delete an external key config.

        The request is rejected if any workspace still references this config.

        Args:
          external_key_id: ID of the External Key.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds

        Raises:
          ExternalKeyInWorkspacePolicyError:

          SandboxEgressRestrictedError:
        """
        if not external_key_id:
            raise ValueError(f"Expected a non-empty value for `external_key_id` but received {external_key_id!r}")
        return self._delete(
            path_template("/v1/organizations/external_keys/{external_key_id}", external_key_id=external_key_id),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                span_name="anthropic.organization.external_keys.delete",
                span_route="/v1/organizations/external_keys/{external_key_id}",
                span_attributes={"anthropic.organization.external_key.id": external_key_id},
            ),
            cast_to=ExternalKeyDeleteResponse,
        )

    def validate(
        self,
        external_key_id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> ExternalKeyValidateResponse:
        """
        Validate an external key config against the customer's KMS.

        Anthropic performs an encrypt/decrypt roundtrip against the configured KMS key
        and waits up to 30 seconds for the result. The response status is `success` if
        the roundtrip succeeded, or `failure` with an error message if it failed or
        timed out.

        Args:
          external_key_id: ID of the External Key.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds

        Raises:
          SandboxEgressRestrictedError:
        """
        if not external_key_id:
            raise ValueError(f"Expected a non-empty value for `external_key_id` but received {external_key_id!r}")
        return self._post(
            path_template(
                "/v1/organizations/external_keys/{external_key_id}/validate", external_key_id=external_key_id
            ),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                span_name="anthropic.organization.external_keys.validate",
                span_route="/v1/organizations/external_keys/{external_key_id}/validate",
                span_attributes={"anthropic.organization.external_key.id": external_key_id},
            ),
            cast_to=ExternalKeyValidateResponse,
        )


class AsyncExternalKeys(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncExternalKeysWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://platform.claude.com/docs/en/api/sdks/python
        """
        return AsyncExternalKeysWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncExternalKeysWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://platform.claude.com/docs/en/api/sdks/python
        """
        return AsyncExternalKeysWithStreamingResponse(self)

    async def create(
        self,
        *,
        provider_config: external_key_create_params.ProviderConfig,
        display_name: Optional[str] | Omit = omit,
        geo: Literal["us"] | Omit = omit,
        user_profile_id: Optional[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> ExternalKey:
        """
        Create an external key config owned by the caller's organization.

        Args:
          provider_config: KMS provider identity and auth coordinates.

          display_name: Human-friendly display name.

          geo: Data residency geo. Only `us` is supported.

          user_profile_id: ID of a user profile to bind the key to. A user profile represents one of your
              customers: bind a customer's key to that customer's user profile. A key bound to
              a user profile can only be attached to a Workspace that has the same user
              profile, and the binding cannot be changed later. Omit this field only for your
              organization's own key, because a key created without a user profile ID can be
              attached to any Workspace, including another customer's.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds

        Raises:
          UserProfileNotFoundError:

          SandboxEgressRestrictedError:
        """
        return await self._post(
            "/v1/organizations/external_keys",
            body={
                "provider_config": provider_config,
                "display_name": display_name,
                "geo": geo,
                "user_profile_id": user_profile_id,
            },
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                span_name="anthropic.organization.external_keys.create",
                span_route="/v1/organizations/external_keys",
                span_created_id="anthropic.organization.external_key.id",
            ),
            cast_to=ExternalKey,
        )

    async def retrieve(
        self,
        external_key_id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> ExternalKey:
        """
        Retrieve a single external key config in the caller's organization by ID.

        Args:
          external_key_id: ID of the External Key.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not external_key_id:
            raise ValueError(f"Expected a non-empty value for `external_key_id` but received {external_key_id!r}")
        return await self._get(
            path_template("/v1/organizations/external_keys/{external_key_id}", external_key_id=external_key_id),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                span_name="anthropic.organization.external_keys.retrieve",
                span_route="/v1/organizations/external_keys/{external_key_id}",
                span_attributes={"anthropic.organization.external_key.id": external_key_id},
            ),
            cast_to=ExternalKey,
        )

    async def update(
        self,
        external_key_id: str,
        *,
        display_name: Optional[str] | Omit = omit,
        geo: Optional[Literal["us"]] | Omit = omit,
        provider_config: Optional[external_key_update_params.ProviderConfig] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> ExternalKey:
        """Partially update an external key config.

        Omitted fields are left unchanged.

        `display_name` is always editable. `geo` and `provider_config` cannot be changed
        once any workspace references this config, because previously encrypted data
        requires the original key identity to decrypt.

        Args:
          external_key_id: ID of the External Key.

          display_name: Human-friendly display name.

          geo: Data residency geo. Only `us` is supported.

          provider_config: KMS provider identity and auth coordinates.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds

        Raises:
          ExternalKeyInWorkspacePolicyError:

          SandboxEgressRestrictedError:
        """
        if not external_key_id:
            raise ValueError(f"Expected a non-empty value for `external_key_id` but received {external_key_id!r}")
        return await self._post(
            path_template("/v1/organizations/external_keys/{external_key_id}", external_key_id=external_key_id),
            body={
                "display_name": display_name,
                "geo": geo,
                "provider_config": provider_config,
            },
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                span_name="anthropic.organization.external_keys.update",
                span_route="/v1/organizations/external_keys/{external_key_id}",
                span_attributes={"anthropic.organization.external_key.id": external_key_id},
            ),
            cast_to=ExternalKey,
        )

    def list(
        self,
        *,
        limit: int | Omit = omit,
        page: Optional[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> AsyncPaginator[ExternalKey, AsyncPageCursor[ExternalKey]]:
        """
        List external key configs in the caller's organization.

        Results are ordered by creation time (newest first). Use the `next_page` cursor
        from the response to fetch subsequent pages.

        Args:
          limit: Number of results per page.

          page: Opaque cursor from a previous response's `next_page`.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get_api_list(
            "/v1/organizations/external_keys",
            page=AsyncPageCursor[ExternalKey],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query={
                    "limit": limit,
                    "page": page,
                },
                span_name="anthropic.organization.external_keys.list",
                span_route="/v1/organizations/external_keys",
            ),
            model=ExternalKey,
        )

    async def delete(
        self,
        external_key_id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> ExternalKeyDeleteResponse:
        """
        Delete an external key config.

        The request is rejected if any workspace still references this config.

        Args:
          external_key_id: ID of the External Key.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds

        Raises:
          ExternalKeyInWorkspacePolicyError:

          SandboxEgressRestrictedError:
        """
        if not external_key_id:
            raise ValueError(f"Expected a non-empty value for `external_key_id` but received {external_key_id!r}")
        return await self._delete(
            path_template("/v1/organizations/external_keys/{external_key_id}", external_key_id=external_key_id),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                span_name="anthropic.organization.external_keys.delete",
                span_route="/v1/organizations/external_keys/{external_key_id}",
                span_attributes={"anthropic.organization.external_key.id": external_key_id},
            ),
            cast_to=ExternalKeyDeleteResponse,
        )

    async def validate(
        self,
        external_key_id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> ExternalKeyValidateResponse:
        """
        Validate an external key config against the customer's KMS.

        Anthropic performs an encrypt/decrypt roundtrip against the configured KMS key
        and waits up to 30 seconds for the result. The response status is `success` if
        the roundtrip succeeded, or `failure` with an error message if it failed or
        timed out.

        Args:
          external_key_id: ID of the External Key.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds

        Raises:
          SandboxEgressRestrictedError:
        """
        if not external_key_id:
            raise ValueError(f"Expected a non-empty value for `external_key_id` but received {external_key_id!r}")
        return await self._post(
            path_template(
                "/v1/organizations/external_keys/{external_key_id}/validate", external_key_id=external_key_id
            ),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                span_name="anthropic.organization.external_keys.validate",
                span_route="/v1/organizations/external_keys/{external_key_id}/validate",
                span_attributes={"anthropic.organization.external_key.id": external_key_id},
            ),
            cast_to=ExternalKeyValidateResponse,
        )


class ExternalKeysWithRawResponse:
    def __init__(self, external_keys: ExternalKeys) -> None:
        self._external_keys = external_keys

        self.create = to_raw_response_wrapper(
            external_keys.create,
        )
        self.retrieve = to_raw_response_wrapper(
            external_keys.retrieve,
        )
        self.update = to_raw_response_wrapper(
            external_keys.update,
        )
        self.list = to_raw_response_wrapper(
            external_keys.list,
        )
        self.delete = to_raw_response_wrapper(
            external_keys.delete,
        )
        self.validate = to_raw_response_wrapper(
            external_keys.validate,
        )


class AsyncExternalKeysWithRawResponse:
    def __init__(self, external_keys: AsyncExternalKeys) -> None:
        self._external_keys = external_keys

        self.create = async_to_raw_response_wrapper(
            external_keys.create,
        )
        self.retrieve = async_to_raw_response_wrapper(
            external_keys.retrieve,
        )
        self.update = async_to_raw_response_wrapper(
            external_keys.update,
        )
        self.list = async_to_raw_response_wrapper(
            external_keys.list,
        )
        self.delete = async_to_raw_response_wrapper(
            external_keys.delete,
        )
        self.validate = async_to_raw_response_wrapper(
            external_keys.validate,
        )


class ExternalKeysWithStreamingResponse:
    def __init__(self, external_keys: ExternalKeys) -> None:
        self._external_keys = external_keys

        self.create = to_streamed_response_wrapper(
            external_keys.create,
        )
        self.retrieve = to_streamed_response_wrapper(
            external_keys.retrieve,
        )
        self.update = to_streamed_response_wrapper(
            external_keys.update,
        )
        self.list = to_streamed_response_wrapper(
            external_keys.list,
        )
        self.delete = to_streamed_response_wrapper(
            external_keys.delete,
        )
        self.validate = to_streamed_response_wrapper(
            external_keys.validate,
        )


class AsyncExternalKeysWithStreamingResponse:
    def __init__(self, external_keys: AsyncExternalKeys) -> None:
        self._external_keys = external_keys

        self.create = async_to_streamed_response_wrapper(
            external_keys.create,
        )
        self.retrieve = async_to_streamed_response_wrapper(
            external_keys.retrieve,
        )
        self.update = async_to_streamed_response_wrapper(
            external_keys.update,
        )
        self.list = async_to_streamed_response_wrapper(
            external_keys.list,
        )
        self.delete = async_to_streamed_response_wrapper(
            external_keys.delete,
        )
        self.validate = async_to_streamed_response_wrapper(
            external_keys.validate,
        )
