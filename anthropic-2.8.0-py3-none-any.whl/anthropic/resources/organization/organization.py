from __future__ import annotations

import httpx2

from .users import (
    Users,
    AsyncUsers,
    UsersWithRawResponse,
    AsyncUsersWithRawResponse,
    UsersWithStreamingResponse,
    AsyncUsersWithStreamingResponse,
)
from .invites import (
    Invites,
    AsyncInvites,
    InvitesWithRawResponse,
    AsyncInvitesWithRawResponse,
    InvitesWithStreamingResponse,
    AsyncInvitesWithStreamingResponse,
)
from ..._types import Body, Query, Headers, NotGiven, not_given
from .api_keys import (
    APIKeys,
    AsyncAPIKeys,
    APIKeysWithRawResponse,
    AsyncAPIKeysWithRawResponse,
    APIKeysWithStreamingResponse,
    AsyncAPIKeysWithStreamingResponse,
)
from ..._compat import cached_property
from ..._resource import SyncAPIResource, AsyncAPIResource
from ..._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from .rate_limits import (
    RateLimits,
    AsyncRateLimits,
    RateLimitsWithRawResponse,
    AsyncRateLimitsWithRawResponse,
    RateLimitsWithStreamingResponse,
    AsyncRateLimitsWithStreamingResponse,
)
from .external_keys import (
    ExternalKeys,
    AsyncExternalKeys,
    ExternalKeysWithRawResponse,
    AsyncExternalKeysWithRawResponse,
    ExternalKeysWithStreamingResponse,
    AsyncExternalKeysWithStreamingResponse,
)
from ..._base_client import make_request_options
from .analytics.analytics import (
    Analytics,
    AsyncAnalytics,
    AnalyticsWithRawResponse,
    AsyncAnalyticsWithRawResponse,
    AnalyticsWithStreamingResponse,
    AsyncAnalyticsWithStreamingResponse,
)
from .compliance_settings import (
    ComplianceSettings,
    AsyncComplianceSettings,
    ComplianceSettingsWithRawResponse,
    AsyncComplianceSettingsWithRawResponse,
    ComplianceSettingsWithStreamingResponse,
    AsyncComplianceSettingsWithStreamingResponse,
)
from .federation.federation import (
    Federation,
    AsyncFederation,
    FederationWithRawResponse,
    AsyncFederationWithRawResponse,
    FederationWithStreamingResponse,
    AsyncFederationWithStreamingResponse,
)
from .rbac_roles.rbac_roles import (
    RBACRoles,
    AsyncRBACRoles,
    RBACRolesWithRawResponse,
    AsyncRBACRolesWithRawResponse,
    RBACRolesWithStreamingResponse,
    AsyncRBACRolesWithStreamingResponse,
)
from .workspaces.workspaces import (
    Workspaces,
    AsyncWorkspaces,
    WorkspacesWithRawResponse,
    AsyncWorkspacesWithRawResponse,
    WorkspacesWithStreamingResponse,
    AsyncWorkspacesWithStreamingResponse,
)
from .rbac_groups.rbac_groups import (
    RBACGroups,
    AsyncRBACGroups,
    RBACGroupsWithRawResponse,
    AsyncRBACGroupsWithRawResponse,
    RBACGroupsWithStreamingResponse,
    AsyncRBACGroupsWithStreamingResponse,
)
from ...types.organization_info import OrganizationInfo
from .spend_limits.spend_limits import (
    SpendLimits,
    AsyncSpendLimits,
    SpendLimitsWithRawResponse,
    AsyncSpendLimitsWithRawResponse,
    SpendLimitsWithStreamingResponse,
    AsyncSpendLimitsWithStreamingResponse,
)
from .service_accounts.service_accounts import (
    ServiceAccounts,
    AsyncServiceAccounts,
    ServiceAccountsWithRawResponse,
    AsyncServiceAccountsWithRawResponse,
    ServiceAccountsWithStreamingResponse,
    AsyncServiceAccountsWithStreamingResponse,
)

__all__ = ["Organization", "AsyncOrganization"]


class Organization(SyncAPIResource):
    @cached_property
    def api_keys(self) -> APIKeys:
        return APIKeys(self._client)

    @cached_property
    def external_keys(self) -> ExternalKeys:
        return ExternalKeys(self._client)

    @cached_property
    def federation(self) -> Federation:
        return Federation(self._client)

    @cached_property
    def invites(self) -> Invites:
        return Invites(self._client)

    @cached_property
    def service_accounts(self) -> ServiceAccounts:
        return ServiceAccounts(self._client)

    @cached_property
    def users(self) -> Users:
        return Users(self._client)

    @cached_property
    def workspaces(self) -> Workspaces:
        return Workspaces(self._client)

    @cached_property
    def rate_limits(self) -> RateLimits:
        return RateLimits(self._client)

    @cached_property
    def compliance_settings(self) -> ComplianceSettings:
        return ComplianceSettings(self._client)

    @cached_property
    def analytics(self) -> Analytics:
        return Analytics(self._client)

    @cached_property
    def spend_limits(self) -> SpendLimits:
        return SpendLimits(self._client)

    @cached_property
    def rbac_groups(self) -> RBACGroups:
        return RBACGroups(self._client)

    @cached_property
    def rbac_roles(self) -> RBACRoles:
        return RBACRoles(self._client)

    @cached_property
    def with_raw_response(self) -> OrganizationWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://platform.claude.com/docs/en/api/sdks/python
        """
        return OrganizationWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> OrganizationWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://platform.claude.com/docs/en/api/sdks/python
        """
        return OrganizationWithStreamingResponse(self)

    def retrieve(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> OrganizationInfo:
        """
        Retrieve information about the organization associated with the authenticated
        API key.
        """
        return self._get(
            "/v1/organizations/me",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                span_name="anthropic.organization.retrieve",
                span_route="/v1/organizations/me",
            ),
            cast_to=OrganizationInfo,
        )


class AsyncOrganization(AsyncAPIResource):
    @cached_property
    def api_keys(self) -> AsyncAPIKeys:
        return AsyncAPIKeys(self._client)

    @cached_property
    def external_keys(self) -> AsyncExternalKeys:
        return AsyncExternalKeys(self._client)

    @cached_property
    def federation(self) -> AsyncFederation:
        return AsyncFederation(self._client)

    @cached_property
    def invites(self) -> AsyncInvites:
        return AsyncInvites(self._client)

    @cached_property
    def service_accounts(self) -> AsyncServiceAccounts:
        return AsyncServiceAccounts(self._client)

    @cached_property
    def users(self) -> AsyncUsers:
        return AsyncUsers(self._client)

    @cached_property
    def workspaces(self) -> AsyncWorkspaces:
        return AsyncWorkspaces(self._client)

    @cached_property
    def rate_limits(self) -> AsyncRateLimits:
        return AsyncRateLimits(self._client)

    @cached_property
    def compliance_settings(self) -> AsyncComplianceSettings:
        return AsyncComplianceSettings(self._client)

    @cached_property
    def analytics(self) -> AsyncAnalytics:
        return AsyncAnalytics(self._client)

    @cached_property
    def spend_limits(self) -> AsyncSpendLimits:
        return AsyncSpendLimits(self._client)

    @cached_property
    def rbac_groups(self) -> AsyncRBACGroups:
        return AsyncRBACGroups(self._client)

    @cached_property
    def rbac_roles(self) -> AsyncRBACRoles:
        return AsyncRBACRoles(self._client)

    @cached_property
    def with_raw_response(self) -> AsyncOrganizationWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://platform.claude.com/docs/en/api/sdks/python
        """
        return AsyncOrganizationWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncOrganizationWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://platform.claude.com/docs/en/api/sdks/python
        """
        return AsyncOrganizationWithStreamingResponse(self)

    async def retrieve(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> OrganizationInfo:
        """
        Retrieve information about the organization associated with the authenticated
        API key.
        """
        return await self._get(
            "/v1/organizations/me",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                span_name="anthropic.organization.retrieve",
                span_route="/v1/organizations/me",
            ),
            cast_to=OrganizationInfo,
        )


class OrganizationWithRawResponse:
    def __init__(self, organization: Organization) -> None:
        self._organization = organization

        self.retrieve = to_raw_response_wrapper(
            organization.retrieve,
        )

    @cached_property
    def api_keys(self) -> APIKeysWithRawResponse:
        return APIKeysWithRawResponse(self._organization.api_keys)

    @cached_property
    def external_keys(self) -> ExternalKeysWithRawResponse:
        return ExternalKeysWithRawResponse(self._organization.external_keys)

    @cached_property
    def federation(self) -> FederationWithRawResponse:
        return FederationWithRawResponse(self._organization.federation)

    @cached_property
    def invites(self) -> InvitesWithRawResponse:
        return InvitesWithRawResponse(self._organization.invites)

    @cached_property
    def service_accounts(self) -> ServiceAccountsWithRawResponse:
        return ServiceAccountsWithRawResponse(self._organization.service_accounts)

    @cached_property
    def users(self) -> UsersWithRawResponse:
        return UsersWithRawResponse(self._organization.users)

    @cached_property
    def workspaces(self) -> WorkspacesWithRawResponse:
        return WorkspacesWithRawResponse(self._organization.workspaces)

    @cached_property
    def rate_limits(self) -> RateLimitsWithRawResponse:
        return RateLimitsWithRawResponse(self._organization.rate_limits)

    @cached_property
    def compliance_settings(self) -> ComplianceSettingsWithRawResponse:
        return ComplianceSettingsWithRawResponse(self._organization.compliance_settings)

    @cached_property
    def analytics(self) -> AnalyticsWithRawResponse:
        return AnalyticsWithRawResponse(self._organization.analytics)

    @cached_property
    def spend_limits(self) -> SpendLimitsWithRawResponse:
        return SpendLimitsWithRawResponse(self._organization.spend_limits)

    @cached_property
    def rbac_groups(self) -> RBACGroupsWithRawResponse:
        return RBACGroupsWithRawResponse(self._organization.rbac_groups)

    @cached_property
    def rbac_roles(self) -> RBACRolesWithRawResponse:
        return RBACRolesWithRawResponse(self._organization.rbac_roles)


class AsyncOrganizationWithRawResponse:
    def __init__(self, organization: AsyncOrganization) -> None:
        self._organization = organization

        self.retrieve = async_to_raw_response_wrapper(
            organization.retrieve,
        )

    @cached_property
    def api_keys(self) -> AsyncAPIKeysWithRawResponse:
        return AsyncAPIKeysWithRawResponse(self._organization.api_keys)

    @cached_property
    def external_keys(self) -> AsyncExternalKeysWithRawResponse:
        return AsyncExternalKeysWithRawResponse(self._organization.external_keys)

    @cached_property
    def federation(self) -> AsyncFederationWithRawResponse:
        return AsyncFederationWithRawResponse(self._organization.federation)

    @cached_property
    def invites(self) -> AsyncInvitesWithRawResponse:
        return AsyncInvitesWithRawResponse(self._organization.invites)

    @cached_property
    def service_accounts(self) -> AsyncServiceAccountsWithRawResponse:
        return AsyncServiceAccountsWithRawResponse(self._organization.service_accounts)

    @cached_property
    def users(self) -> AsyncUsersWithRawResponse:
        return AsyncUsersWithRawResponse(self._organization.users)

    @cached_property
    def workspaces(self) -> AsyncWorkspacesWithRawResponse:
        return AsyncWorkspacesWithRawResponse(self._organization.workspaces)

    @cached_property
    def rate_limits(self) -> AsyncRateLimitsWithRawResponse:
        return AsyncRateLimitsWithRawResponse(self._organization.rate_limits)

    @cached_property
    def compliance_settings(self) -> AsyncComplianceSettingsWithRawResponse:
        return AsyncComplianceSettingsWithRawResponse(self._organization.compliance_settings)

    @cached_property
    def analytics(self) -> AsyncAnalyticsWithRawResponse:
        return AsyncAnalyticsWithRawResponse(self._organization.analytics)

    @cached_property
    def spend_limits(self) -> AsyncSpendLimitsWithRawResponse:
        return AsyncSpendLimitsWithRawResponse(self._organization.spend_limits)

    @cached_property
    def rbac_groups(self) -> AsyncRBACGroupsWithRawResponse:
        return AsyncRBACGroupsWithRawResponse(self._organization.rbac_groups)

    @cached_property
    def rbac_roles(self) -> AsyncRBACRolesWithRawResponse:
        return AsyncRBACRolesWithRawResponse(self._organization.rbac_roles)


class OrganizationWithStreamingResponse:
    def __init__(self, organization: Organization) -> None:
        self._organization = organization

        self.retrieve = to_streamed_response_wrapper(
            organization.retrieve,
        )

    @cached_property
    def api_keys(self) -> APIKeysWithStreamingResponse:
        return APIKeysWithStreamingResponse(self._organization.api_keys)

    @cached_property
    def external_keys(self) -> ExternalKeysWithStreamingResponse:
        return ExternalKeysWithStreamingResponse(self._organization.external_keys)

    @cached_property
    def federation(self) -> FederationWithStreamingResponse:
        return FederationWithStreamingResponse(self._organization.federation)

    @cached_property
    def invites(self) -> InvitesWithStreamingResponse:
        return InvitesWithStreamingResponse(self._organization.invites)

    @cached_property
    def service_accounts(self) -> ServiceAccountsWithStreamingResponse:
        return ServiceAccountsWithStreamingResponse(self._organization.service_accounts)

    @cached_property
    def users(self) -> UsersWithStreamingResponse:
        return UsersWithStreamingResponse(self._organization.users)

    @cached_property
    def workspaces(self) -> WorkspacesWithStreamingResponse:
        return WorkspacesWithStreamingResponse(self._organization.workspaces)

    @cached_property
    def rate_limits(self) -> RateLimitsWithStreamingResponse:
        return RateLimitsWithStreamingResponse(self._organization.rate_limits)

    @cached_property
    def compliance_settings(self) -> ComplianceSettingsWithStreamingResponse:
        return ComplianceSettingsWithStreamingResponse(self._organization.compliance_settings)

    @cached_property
    def analytics(self) -> AnalyticsWithStreamingResponse:
        return AnalyticsWithStreamingResponse(self._organization.analytics)

    @cached_property
    def spend_limits(self) -> SpendLimitsWithStreamingResponse:
        return SpendLimitsWithStreamingResponse(self._organization.spend_limits)

    @cached_property
    def rbac_groups(self) -> RBACGroupsWithStreamingResponse:
        return RBACGroupsWithStreamingResponse(self._organization.rbac_groups)

    @cached_property
    def rbac_roles(self) -> RBACRolesWithStreamingResponse:
        return RBACRolesWithStreamingResponse(self._organization.rbac_roles)


class AsyncOrganizationWithStreamingResponse:
    def __init__(self, organization: AsyncOrganization) -> None:
        self._organization = organization

        self.retrieve = async_to_streamed_response_wrapper(
            organization.retrieve,
        )

    @cached_property
    def api_keys(self) -> AsyncAPIKeysWithStreamingResponse:
        return AsyncAPIKeysWithStreamingResponse(self._organization.api_keys)

    @cached_property
    def external_keys(self) -> AsyncExternalKeysWithStreamingResponse:
        return AsyncExternalKeysWithStreamingResponse(self._organization.external_keys)

    @cached_property
    def federation(self) -> AsyncFederationWithStreamingResponse:
        return AsyncFederationWithStreamingResponse(self._organization.federation)

    @cached_property
    def invites(self) -> AsyncInvitesWithStreamingResponse:
        return AsyncInvitesWithStreamingResponse(self._organization.invites)

    @cached_property
    def service_accounts(self) -> AsyncServiceAccountsWithStreamingResponse:
        return AsyncServiceAccountsWithStreamingResponse(self._organization.service_accounts)

    @cached_property
    def users(self) -> AsyncUsersWithStreamingResponse:
        return AsyncUsersWithStreamingResponse(self._organization.users)

    @cached_property
    def workspaces(self) -> AsyncWorkspacesWithStreamingResponse:
        return AsyncWorkspacesWithStreamingResponse(self._organization.workspaces)

    @cached_property
    def rate_limits(self) -> AsyncRateLimitsWithStreamingResponse:
        return AsyncRateLimitsWithStreamingResponse(self._organization.rate_limits)

    @cached_property
    def compliance_settings(self) -> AsyncComplianceSettingsWithStreamingResponse:
        return AsyncComplianceSettingsWithStreamingResponse(self._organization.compliance_settings)

    @cached_property
    def analytics(self) -> AsyncAnalyticsWithStreamingResponse:
        return AsyncAnalyticsWithStreamingResponse(self._organization.analytics)

    @cached_property
    def spend_limits(self) -> AsyncSpendLimitsWithStreamingResponse:
        return AsyncSpendLimitsWithStreamingResponse(self._organization.spend_limits)

    @cached_property
    def rbac_groups(self) -> AsyncRBACGroupsWithStreamingResponse:
        return AsyncRBACGroupsWithStreamingResponse(self._organization.rbac_groups)

    @cached_property
    def rbac_roles(self) -> AsyncRBACRolesWithStreamingResponse:
        return AsyncRBACRolesWithStreamingResponse(self._organization.rbac_roles)
