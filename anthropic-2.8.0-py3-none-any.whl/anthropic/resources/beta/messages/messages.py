from __future__ import annotations

import warnings
from typing import TYPE_CHECKING, List, Type, Union, Iterable, Optional, cast
from functools import partial
from itertools import chain
from typing_extensions import Unpack, Literal, overload

import httpx2

from .batches import (
    Batches,
    AsyncBatches,
    BatchesWithRawResponse,
    AsyncBatchesWithRawResponse,
    BatchesWithStreamingResponse,
    AsyncBatchesWithStreamingResponse,
)
from ...._types import Body, Omit, Query, Headers, NotGiven, SequenceNotStr, omit, not_given
from ...._utils import is_given, required_args, strip_not_given
from ...._compat import cached_property
from ...._resource import SyncAPIResource, AsyncAPIResource
from ...._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ....lib.tools import (
    BetaToolRunner,
    BetaAsyncToolRunner,
    BetaStreamingToolRunner,
    BetaAsyncStreamingToolRunner,
)
from ...._constants import DEFAULT_TIMEOUT, MODEL_NONSTREAMING_TOKENS
from ...._streaming import Stream, AsyncStream
from ....types.beta import (
    BetaFallbacksParam,
    ThreadCreateParams,
    BetaDiagnosticsParam,
    BetaMessageThreadParam,
    BetaThinkingConfigParam,
    message_create_params,
)
from ....lib.threads import BetaMessageThread, BetaAsyncMessageThread, UnsupportedRequestBehavior
from ...._base_client import (
    merge_headers,
    make_request_options,
)
from ....lib._tracing import messages_create_request_attributes
from ....lib.streaming import BetaMessageStreamManager, BetaAsyncMessageStreamManager
from ...messages.messages import DEPRECATED_MODELS, MODELS_TO_WARN_WITH_THINKING_ENABLED
from ....types.model_param import ModelParam
from ....lib.threads._params import given, turn_overrides
from ....lib.tools._toolsets import BetaRunnableToolset, BetaAsyncRunnableToolset
from ....lib._parse._response import ResponseFormatT, parse_beta_response
from ....lib._parse._transform import (
    merge_output_config,
    to_json_output_format,
    validate_output_config_conflict as _validate_output_config_conflict,
)
from ....lib._stainless_helpers import (
    HELPER_METHOD_STREAM as _HELPER_METHOD_STREAM,
    STAINLESS_HELPER_METHOD_HEADER as _STAINLESS_HELPER_METHOD_HEADER,
    STAINLESS_STREAM_HELPER_HEADER as _STAINLESS_STREAM_HELPER_HEADER,
    helper_header as _helper_header,
    stainless_helper_header as _stainless_helper_header,
)
from ....lib.tools._tool_params import BetaToolLike, to_tool_params as _to_tool_params
from ....types.beta.beta_message import BetaMessage
from ....lib.tools._tool_dispatch import partition_sync_tools, partition_async_tools
from ....lib.tools._beta_functions import BetaRunnableTool, BetaAsyncRunnableTool
from ....types.anthropic_beta_param import AnthropicBetaParam
from ....types.beta.beta_message_param import BetaMessageParam
from ....types.beta.beta_metadata_param import BetaMetadataParam
from ....types.beta.parsed_beta_message import ParsedBetaMessage
from ....types.beta.beta_fallbacks_param import BetaFallbacksParam
from ....types.beta.beta_text_block_param import BetaTextBlockParam
from ....types.beta.beta_tool_union_param import BetaToolUnionParam
from ....types.beta.beta_diagnostics_param import BetaDiagnosticsParam
from ....types.beta.beta_tool_choice_param import BetaToolChoiceParam
from ....types.beta.beta_output_config_param import BetaOutputConfigParam
from ....types.beta.beta_message_thread_param import BetaMessageThreadParam
from ....types.beta.beta_message_tokens_count import BetaMessageTokensCount
from ....types.beta.beta_thinking_config_param import BetaThinkingConfigParam
from ....types.beta.beta_compaction_config_param import BetaCompactionConfigParam
from ....types.beta.beta_json_output_format_param import BetaJSONOutputFormatParam
from ....types.beta.beta_raw_message_stream_event import BetaRawMessageStreamEvent
from ....types.beta.beta_cache_control_ephemeral_param import BetaCacheControlEphemeralParam
from ....types.beta.beta_context_management_config_param import BetaContextManagementConfigParam
from ....types.beta.beta_request_mcp_server_url_definition_param import BetaRequestMCPServerURLDefinitionParam

if TYPE_CHECKING:
    from ...._client import Anthropic, AsyncAnthropic


__all__ = ["Messages", "AsyncMessages"]


class Messages(SyncAPIResource):
    @cached_property
    def batches(self) -> Batches:
        return Batches(self._client)

    @cached_property
    def with_raw_response(self) -> MessagesWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://platform.claude.com/docs/en/api/sdks/python
        """
        return MessagesWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> MessagesWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://platform.claude.com/docs/en/api/sdks/python
        """
        return MessagesWithStreamingResponse(self)

    @overload
    def create(
        self,
        *,
        max_tokens: int,
        messages: Iterable[BetaMessageParam],
        model: ModelParam,
        cache_control: Optional[BetaCacheControlEphemeralParam] | Omit = omit,
        compaction: Optional[BetaCompactionConfigParam] | Omit = omit,
        container: Optional[message_create_params.Container] | Omit = omit,
        context_management: Optional[BetaContextManagementConfigParam] | Omit = omit,
        diagnostics: Optional[BetaDiagnosticsParam] | Omit = omit,
        fallback_credit_token: Optional[message_create_params.FallbackCreditToken] | Omit = omit,
        fallbacks: Optional[BetaFallbacksParam] | Omit = omit,
        inference_geo: Optional[str] | Omit = omit,
        mcp_servers: Iterable[BetaRequestMCPServerURLDefinitionParam] | Omit = omit,
        metadata: BetaMetadataParam | Omit = omit,
        output_config: BetaOutputConfigParam | Omit = omit,
        service_tier: Literal["auto", "standard_only"] | Omit = omit,
        speed: Optional[Literal["standard", "fast"]] | Omit = omit,
        stop_sequences: SequenceNotStr[str] | Omit = omit,
        stream: Literal[False] | Omit = omit,
        system: Union[str, Iterable[BetaTextBlockParam]] | Omit = omit,
        thinking: BetaThinkingConfigParam | Omit = omit,
        thread: Optional[BetaMessageThreadParam] | Omit = omit,
        tool_choice: BetaToolChoiceParam | Omit = omit,
        tools: Iterable[BetaToolLike] | Omit = omit,
        betas: List[AnthropicBetaParam] | Omit = omit,
        user_profile_id: str | Omit = omit,
        workspace_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> BetaMessage:
        """
        Send a structured list of input messages with text and/or image content, and the
        model will generate the next message in the conversation.

        The Messages API can be used for either single queries or stateless multi-turn
        conversations.

        Learn more about the Messages API in our
        [user guide](https://platform.claude.com/docs/en/get-started)

        Args:
          max_tokens: The maximum number of tokens to generate before stopping.

              Note that our models may stop _before_ reaching this maximum. This parameter
              only specifies the absolute maximum number of tokens to generate.

              Set to `0` to populate the
              [prompt cache](https://platform.claude.com/docs/en/build-with-claude/prompt-caching#pre-warming-the-cache)
              without generating a response.

              Different models have different maximum values for this parameter. See
              [models](https://platform.claude.com/docs/en/about-claude/models/overview) for
              details.

          messages: Input messages.

              Our models are trained to operate on alternating `user` and `assistant`
              conversational turns. When creating a new `Message`, you specify the prior
              conversational turns with the `messages` parameter, and the model then generates
              the next `Message` in the conversation. Consecutive `user` or `assistant` turns
              in your request will be combined into a single turn.

              Each input message must be an object with a `role` and `content`. You can
              specify a single `user`-role message, or you can include multiple `user` and
              `assistant` messages.

              If the final message uses the `assistant` role, the response content will
              continue immediately from the content in that message. This can be used to
              constrain part of the model's response. This is called prefill. On models that
              don't support prefill, creating a message that ends with a partial `assistant`
              response returns a 400 error. See
              [Prefill not supported](https://platform.claude.com/docs/en/api/errors#prefill-not-supported).

              Example with a single `user` message:

              ```json
              [{ "role": "user", "content": "Hello, Claude" }]
              ```

              Example with multiple conversational turns:

              ```json
              [
                { "role": "user", "content": "Hello there." },
                { "role": "assistant", "content": "Hi, I'm Claude. How can I help you?" },
                { "role": "user", "content": "Can you explain LLMs in plain English?" }
              ]
              ```

              Example with a partially-filled response from Claude, for models that support
              prefill:

              ```json
              [
                {
                  "role": "user",
                  "content": "What's the Greek name for Sun? (A) Sol (B) Helios (C) Sun"
                },
                { "role": "assistant", "content": "The best answer is (" }
              ]
              ```

              Each input message `content` may be either a single `string` or an array of
              content blocks, where each block has a specific `type`. Using a `string` for
              `content` is shorthand for an array of one content block of type `"text"`. The
              following input messages are equivalent:

              ```json
              { "role": "user", "content": "Hello, Claude" }
              ```

              ```json
              { "role": "user", "content": [{ "type": "text", "text": "Hello, Claude" }] }
              ```

              See
              [input examples](https://platform.claude.com/docs/en/build-with-claude/working-with-messages).

              Note that if you want to include a
              [system prompt](https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/claude-prompting-best-practices#give-claude-a-role),
              you can use the top-level `system` parameter.

              There is a limit of 100,000 messages in a single request.

          model: The model that will complete your prompt.

              See [models](https://docs.anthropic.com/en/docs/models-overview) for additional
              details and options.

          cache_control: Top-level cache control automatically applies a cache_control marker to the last
              cacheable block in the request.

          compaction: Compaction configuration.

              When set on `POST /v1/messages`, the request is a compaction request: the
              conversation in `messages` is summarized and the response holds only the
              resulting `compaction` block (`stop_reason` `"compaction"`), which later
              requests send first in `messages` in place of the messages it summarizes.
              `POST /v1/messages/count_tokens` accepts this parameter and ignores it: the
              count it returns is for the conversation in `messages` as sent. Cannot be
              combined with `context_management`.

          container: Container identifier for reuse across requests.

          context_management: Context management configuration.

              This allows you to control how Claude manages context across multiple requests,
              such as whether to clear function results or not.

          diagnostics: Request-level diagnostics. Supply `previous_message_id` to have the response
              include `diagnostics.cache_miss_reason` explaining any prompt-cache divergence
              from that prior request.

          fallback_credit_token: The `fallback_credit_token` from a prior refusal's `stop_details`.

              When a preceding request was refused and returned a `fallback_credit_token`,
              pass that code here on the retry to have the retry's cache-creation tokens for
              the prefix that was warm on the refused model billed at the cache-read rate.
              Must be redeemed by the same organization and workspace, with the same request
              body (optionally extended by one appended `assistant` message whose content is
              the partial text — with any trailing whitespace stripped from the final text
              block — and paired server-tool blocks streamed before the refusal; the
              appended-assistant form is not available for requests with `output_format` set
              or forced `tool_choice`), on an eligible fallback model, on the same platform,
              and within 5 minutes of the refusal; a mismatch is a 400. A token minted
              mid-server-tool-loop whose partial content was continuable may only be redeemed
              with the appended-assistant form — if an exact-body retry is rejected with a 400
              saying the token must be redeemed by continuing the partial response, retry with
              the appended-assistant form instead.

              When the appended-assistant form is used on a model that otherwise disallows
              assistant-turn prefill, this token also authorizes that one prefill.

          fallbacks: Opt-in server-side retry on one or more substitute models when the requested
              model declines for policy reasons. Tried in order: if the first entry also
              declines, the second is tried, and so on. Some models don't support fallbacks;
              on those models, a list of fallback models returns a 400 error. See
              [Server-side fallback](https://platform.claude.com/docs/en/build-with-claude/refusals-and-fallback#server-side-fallback).
              The string "default" requests the requested model's server-defined default
              fallback configuration. On a model that doesn't support fallbacks, the request
              runs on the requested model alone, so a declined request stays declined.

          inference_geo: Specifies the geographic region for inference processing. If not specified, the
              workspace's `default_inference_geo` is used.

          mcp_servers: MCP servers to be utilized in this request

          metadata: An object describing metadata about the request.

          output_config: Configuration options for the model's output, such as the output format.

          service_tier: Determines whether to use priority capacity (if available) or standard capacity
              for this request.

              Anthropic offers different levels of service for your API requests. See
              [service-tiers](https://platform.claude.com/docs/en/api/service-tiers) for
              details.

          speed: The inference speed mode for this request. `"fast"` enables high
              output-tokens-per-second inference.

              Some models require the `fast-mode-2026-02-01` beta header for any `speed`
              value. See
              [fast mode](https://platform.claude.com/docs/en/build-with-claude/fast-mode) for
              which models.

          stop_sequences: Custom text sequences that will cause the model to stop generating.

              Our models will normally stop when they have naturally completed their turn,
              which will result in a response `stop_reason` of `"end_turn"`.

              If you want the model to stop generating when it encounters custom strings of
              text, you can use the `stop_sequences` parameter. If the model encounters one of
              the custom sequences, the response `stop_reason` value will be `"stop_sequence"`
              and the response `stop_sequence` value will contain the matched stop sequence.

          stream: Whether to incrementally stream the response using server-sent events. When
              `true`, SDKs return a raw event stream.

              In the TypeScript, Python and Ruby SDKs, the recommended way to stream is
              `messages.stream()`. It sets `stream` for you and accumulates the events into
              the final message. See
              [Streaming with SDKs](https://platform.claude.com/docs/en/build-with-claude/streaming#streaming-with-sdks)
              for an example in each language.

          system: System prompt.

              A system prompt is a way of providing context and instructions to Claude, such
              as specifying a particular goal or role. See our
              [guide to system prompts](https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/claude-prompting-best-practices#give-claude-a-role).

          thinking: Configuration for Claude's thinking.

              With `{"type": "adaptive"}`, Claude decides when and how much to think. With
              `{"type": "enabled"}` (manual extended thinking), you set a `budget_tokens` of
              at least 1,024. Thinking tokens count toward your `max_tokens` limit.

              Which `type` values are accepted, and what happens when you omit `thinking`,
              depend on the model. See
              [thinking](https://platform.claude.com/docs/en/build-with-claude/thinking#configuring-thinking)
              for each model's behavior.

          thread: Server-held conversation state (a Thread). `{"type": "create"}` asks the server
              to hold this conversation's state under the response's `id`;
              `{"type": "continue", "previous_message_id": ...}` resumes from a previous
              response so only the new turn's messages are sent. The response shape is
              unchanged.

          tool_choice: How the model should use the provided tools. The model can use a specific tool,
              any available tool, decide by itself, or not use tools at all.

          tools: Definitions of tools that the model may use.

              If you include `tools` in your API request, the model may return `tool_use`
              content blocks that represent the model's use of those tools. You can then run
              those tools using the tool input generated by the model and then optionally
              return results back to the model using `tool_result` content blocks.

              There are two types of tools: **client tools** and **server tools**. The
              behavior described below applies to client tools. For
              [server tools](https://platform.claude.com/docs/en/agents-and-tools/tool-use/server-tools),
              see their individual documentation as each has its own behavior (e.g., the
              [web search tool](https://platform.claude.com/docs/en/agents-and-tools/tool-use/web-search-tool)).

              Each tool definition includes:

              - `name`: Name of the tool.
              - `description`: Optional, but strongly-recommended description of the tool.
              - `input_schema`: [JSON schema](https://json-schema.org/draft/2020-12) for the
                tool `input` shape that the model will produce in `tool_use` output content
                blocks.

              For example, if you defined `tools` as:

              ```json
              [
                {
                  "name": "get_stock_price",
                  "description": "Get the current stock price for a given ticker symbol.",
                  "input_schema": {
                    "type": "object",
                    "properties": {
                      "ticker": {
                        "type": "string",
                        "description": "The stock ticker symbol, e.g. AAPL for Apple Inc."
                      }
                    },
                    "required": ["ticker"]
                  }
                }
              ]
              ```

              And then asked the model "What's the S&P 500 at today?", the model might produce
              `tool_use` content blocks in the response like this:

              ```json
              [
                {
                  "type": "tool_use",
                  "id": "toolu_01D7FLrfh4GYq7yT1ULFeyMV",
                  "name": "get_stock_price",
                  "input": { "ticker": "^GSPC" }
                }
              ]
              ```

              You might then run your `get_stock_price` tool with `{"ticker": "^GSPC"}` as an
              input, and return the following back to the model in a subsequent `user`
              message:

              ```json
              [
                {
                  "type": "tool_result",
                  "tool_use_id": "toolu_01D7FLrfh4GYq7yT1ULFeyMV",
                  "content": "259.75 USD"
                }
              ]
              ```

              Tools can be used for workflows that include running client-side tools and
              functions, or more generally whenever you want the model to produce a particular
              JSON structure of output.

              See our
              [guide](https://platform.claude.com/docs/en/agents-and-tools/tool-use/overview)
              for more details.

          betas: Optional header to specify the beta version(s) you want to use.

          user_profile_id: The user profile ID to attribute this request to. Use when acting on behalf of a
              party other than your organization.

          workspace_id: Optional header to select the Workspace for this request. The value is a
              Workspace ID (for example, `wrkspc_011CZkZaBF1tNoB5wlCeusgy`).

              Only needed for credentials that can act on more than one Workspace. A
              credential that belongs to a specific Workspace may omit it; if sent, it must
              match that Workspace.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds

        Raises:
          AvailableToolsLimitExceededError:

          ClaudeCodeKeyCreatorNotMemberError:

          ClaudeCodeVersionTooOldError:

          CMEKKeyDisabledError:

          CMEKKeyNetworkBlockedError:

          CompactionBlockAmbiguousError:

          CompactionBlockMisplacedError:

          CompactionContentMismatchError:

          CompactionIncompleteTurnError:

          CompactionNothingToSummarizeError:

          CompactionSignatureInvalidError:

          CompactionTooManyToolReferencesError:

          CompactionToolChangesMismatchError:

          OrganizationOnHoldError:

          RequestBodyEncodingInvalidError:

          RequestBodyEncodingUnsupportedError:

          ThreadAlreadyContinuedError:

          ThreadContinueInFlightError:

          ThreadFingerprintMismatchError:

          ThreadUnsupportedRequestError:

          ToolNameConflictError:

          ToolReferenceUnresolvedError:

          ThreadNotFoundError:

          SkillReadBlockedUndecryptableError:

          RequestBodyTooLargeAfterDecodingError:

          EnforcedSpendLimitReachedError:

          RampLimitExceededError:

          CMEKKeyUnreachableError:

          CompactionUnavailableError:
        """
        ...

    @overload
    def create(
        self,
        *,
        max_tokens: int,
        messages: Iterable[BetaMessageParam],
        model: ModelParam,
        stream: Literal[True],
        cache_control: Optional[BetaCacheControlEphemeralParam] | Omit = omit,
        compaction: Optional[BetaCompactionConfigParam] | Omit = omit,
        container: Optional[message_create_params.Container] | Omit = omit,
        context_management: Optional[BetaContextManagementConfigParam] | Omit = omit,
        diagnostics: Optional[BetaDiagnosticsParam] | Omit = omit,
        fallback_credit_token: Optional[message_create_params.FallbackCreditToken] | Omit = omit,
        fallbacks: Optional[BetaFallbacksParam] | Omit = omit,
        inference_geo: Optional[str] | Omit = omit,
        mcp_servers: Iterable[BetaRequestMCPServerURLDefinitionParam] | Omit = omit,
        metadata: BetaMetadataParam | Omit = omit,
        output_config: BetaOutputConfigParam | Omit = omit,
        service_tier: Literal["auto", "standard_only"] | Omit = omit,
        speed: Optional[Literal["standard", "fast"]] | Omit = omit,
        stop_sequences: SequenceNotStr[str] | Omit = omit,
        system: Union[str, Iterable[BetaTextBlockParam]] | Omit = omit,
        thinking: BetaThinkingConfigParam | Omit = omit,
        thread: Optional[BetaMessageThreadParam] | Omit = omit,
        tool_choice: BetaToolChoiceParam | Omit = omit,
        tools: Iterable[BetaToolLike] | Omit = omit,
        betas: List[AnthropicBetaParam] | Omit = omit,
        user_profile_id: str | Omit = omit,
        workspace_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> Stream[BetaRawMessageStreamEvent]:
        """
        Send a structured list of input messages with text and/or image content, and the
        model will generate the next message in the conversation.

        The Messages API can be used for either single queries or stateless multi-turn
        conversations.

        Learn more about the Messages API in our
        [user guide](https://platform.claude.com/docs/en/get-started)

        Args:
          max_tokens: The maximum number of tokens to generate before stopping.

              Note that our models may stop _before_ reaching this maximum. This parameter
              only specifies the absolute maximum number of tokens to generate.

              Set to `0` to populate the
              [prompt cache](https://platform.claude.com/docs/en/build-with-claude/prompt-caching#pre-warming-the-cache)
              without generating a response.

              Different models have different maximum values for this parameter. See
              [models](https://platform.claude.com/docs/en/about-claude/models/overview) for
              details.

          messages: Input messages.

              Our models are trained to operate on alternating `user` and `assistant`
              conversational turns. When creating a new `Message`, you specify the prior
              conversational turns with the `messages` parameter, and the model then generates
              the next `Message` in the conversation. Consecutive `user` or `assistant` turns
              in your request will be combined into a single turn.

              Each input message must be an object with a `role` and `content`. You can
              specify a single `user`-role message, or you can include multiple `user` and
              `assistant` messages.

              If the final message uses the `assistant` role, the response content will
              continue immediately from the content in that message. This can be used to
              constrain part of the model's response. This is called prefill. On models that
              don't support prefill, creating a message that ends with a partial `assistant`
              response returns a 400 error. See
              [Prefill not supported](https://platform.claude.com/docs/en/api/errors#prefill-not-supported).

              Example with a single `user` message:

              ```json
              [{ "role": "user", "content": "Hello, Claude" }]
              ```

              Example with multiple conversational turns:

              ```json
              [
                { "role": "user", "content": "Hello there." },
                { "role": "assistant", "content": "Hi, I'm Claude. How can I help you?" },
                { "role": "user", "content": "Can you explain LLMs in plain English?" }
              ]
              ```

              Example with a partially-filled response from Claude, for models that support
              prefill:

              ```json
              [
                {
                  "role": "user",
                  "content": "What's the Greek name for Sun? (A) Sol (B) Helios (C) Sun"
                },
                { "role": "assistant", "content": "The best answer is (" }
              ]
              ```

              Each input message `content` may be either a single `string` or an array of
              content blocks, where each block has a specific `type`. Using a `string` for
              `content` is shorthand for an array of one content block of type `"text"`. The
              following input messages are equivalent:

              ```json
              { "role": "user", "content": "Hello, Claude" }
              ```

              ```json
              { "role": "user", "content": [{ "type": "text", "text": "Hello, Claude" }] }
              ```

              See
              [input examples](https://platform.claude.com/docs/en/build-with-claude/working-with-messages).

              Note that if you want to include a
              [system prompt](https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/claude-prompting-best-practices#give-claude-a-role),
              you can use the top-level `system` parameter.

              There is a limit of 100,000 messages in a single request.

          model: The model that will complete your prompt.

              See [models](https://docs.anthropic.com/en/docs/models-overview) for additional
              details and options.

          stream: Whether to incrementally stream the response using server-sent events. When
              `true`, SDKs return a raw event stream.

              In the TypeScript, Python and Ruby SDKs, the recommended way to stream is
              `messages.stream()`. It sets `stream` for you and accumulates the events into
              the final message. See
              [Streaming with SDKs](https://platform.claude.com/docs/en/build-with-claude/streaming#streaming-with-sdks)
              for an example in each language.

          cache_control: Top-level cache control automatically applies a cache_control marker to the last
              cacheable block in the request.

          compaction: Compaction configuration.

              When set on `POST /v1/messages`, the request is a compaction request: the
              conversation in `messages` is summarized and the response holds only the
              resulting `compaction` block (`stop_reason` `"compaction"`), which later
              requests send first in `messages` in place of the messages it summarizes.
              `POST /v1/messages/count_tokens` accepts this parameter and ignores it: the
              count it returns is for the conversation in `messages` as sent. Cannot be
              combined with `context_management`.

          container: Container identifier for reuse across requests.

          context_management: Context management configuration.

              This allows you to control how Claude manages context across multiple requests,
              such as whether to clear function results or not.

          diagnostics: Request-level diagnostics. Supply `previous_message_id` to have the response
              include `diagnostics.cache_miss_reason` explaining any prompt-cache divergence
              from that prior request.

          fallback_credit_token: The `fallback_credit_token` from a prior refusal's `stop_details`.

              When a preceding request was refused and returned a `fallback_credit_token`,
              pass that code here on the retry to have the retry's cache-creation tokens for
              the prefix that was warm on the refused model billed at the cache-read rate.
              Must be redeemed by the same organization and workspace, with the same request
              body (optionally extended by one appended `assistant` message whose content is
              the partial text — with any trailing whitespace stripped from the final text
              block — and paired server-tool blocks streamed before the refusal; the
              appended-assistant form is not available for requests with `output_format` set
              or forced `tool_choice`), on an eligible fallback model, on the same platform,
              and within 5 minutes of the refusal; a mismatch is a 400. A token minted
              mid-server-tool-loop whose partial content was continuable may only be redeemed
              with the appended-assistant form — if an exact-body retry is rejected with a 400
              saying the token must be redeemed by continuing the partial response, retry with
              the appended-assistant form instead.

              When the appended-assistant form is used on a model that otherwise disallows
              assistant-turn prefill, this token also authorizes that one prefill.

          fallbacks: Opt-in server-side retry on one or more substitute models when the requested
              model declines for policy reasons. Tried in order: if the first entry also
              declines, the second is tried, and so on. Some models don't support fallbacks;
              on those models, a list of fallback models returns a 400 error. See
              [Server-side fallback](https://platform.claude.com/docs/en/build-with-claude/refusals-and-fallback#server-side-fallback).
              The string "default" requests the requested model's server-defined default
              fallback configuration. On a model that doesn't support fallbacks, the request
              runs on the requested model alone, so a declined request stays declined.

          inference_geo: Specifies the geographic region for inference processing. If not specified, the
              workspace's `default_inference_geo` is used.

          mcp_servers: MCP servers to be utilized in this request

          metadata: An object describing metadata about the request.

          output_config: Configuration options for the model's output, such as the output format.

          service_tier: Determines whether to use priority capacity (if available) or standard capacity
              for this request.

              Anthropic offers different levels of service for your API requests. See
              [service-tiers](https://platform.claude.com/docs/en/api/service-tiers) for
              details.

          speed: The inference speed mode for this request. `"fast"` enables high
              output-tokens-per-second inference.

              Some models require the `fast-mode-2026-02-01` beta header for any `speed`
              value. See
              [fast mode](https://platform.claude.com/docs/en/build-with-claude/fast-mode) for
              which models.

          stop_sequences: Custom text sequences that will cause the model to stop generating.

              Our models will normally stop when they have naturally completed their turn,
              which will result in a response `stop_reason` of `"end_turn"`.

              If you want the model to stop generating when it encounters custom strings of
              text, you can use the `stop_sequences` parameter. If the model encounters one of
              the custom sequences, the response `stop_reason` value will be `"stop_sequence"`
              and the response `stop_sequence` value will contain the matched stop sequence.

          system: System prompt.

              A system prompt is a way of providing context and instructions to Claude, such
              as specifying a particular goal or role. See our
              [guide to system prompts](https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/claude-prompting-best-practices#give-claude-a-role).

          thinking: Configuration for Claude's thinking.

              With `{"type": "adaptive"}`, Claude decides when and how much to think. With
              `{"type": "enabled"}` (manual extended thinking), you set a `budget_tokens` of
              at least 1,024. Thinking tokens count toward your `max_tokens` limit.

              Which `type` values are accepted, and what happens when you omit `thinking`,
              depend on the model. See
              [thinking](https://platform.claude.com/docs/en/build-with-claude/thinking#configuring-thinking)
              for each model's behavior.

          thread: Server-held conversation state (a Thread). `{"type": "create"}` asks the server
              to hold this conversation's state under the response's `id`;
              `{"type": "continue", "previous_message_id": ...}` resumes from a previous
              response so only the new turn's messages are sent. The response shape is
              unchanged.

          tool_choice: How the model should use the provided tools. The model can use a specific tool,
              any available tool, decide by itself, or not use tools at all.

          tools: Definitions of tools that the model may use.

              If you include `tools` in your API request, the model may return `tool_use`
              content blocks that represent the model's use of those tools. You can then run
              those tools using the tool input generated by the model and then optionally
              return results back to the model using `tool_result` content blocks.

              There are two types of tools: **client tools** and **server tools**. The
              behavior described below applies to client tools. For
              [server tools](https://platform.claude.com/docs/en/agents-and-tools/tool-use/server-tools),
              see their individual documentation as each has its own behavior (e.g., the
              [web search tool](https://platform.claude.com/docs/en/agents-and-tools/tool-use/web-search-tool)).

              Each tool definition includes:

              - `name`: Name of the tool.
              - `description`: Optional, but strongly-recommended description of the tool.
              - `input_schema`: [JSON schema](https://json-schema.org/draft/2020-12) for the
                tool `input` shape that the model will produce in `tool_use` output content
                blocks.

              For example, if you defined `tools` as:

              ```json
              [
                {
                  "name": "get_stock_price",
                  "description": "Get the current stock price for a given ticker symbol.",
                  "input_schema": {
                    "type": "object",
                    "properties": {
                      "ticker": {
                        "type": "string",
                        "description": "The stock ticker symbol, e.g. AAPL for Apple Inc."
                      }
                    },
                    "required": ["ticker"]
                  }
                }
              ]
              ```

              And then asked the model "What's the S&P 500 at today?", the model might produce
              `tool_use` content blocks in the response like this:

              ```json
              [
                {
                  "type": "tool_use",
                  "id": "toolu_01D7FLrfh4GYq7yT1ULFeyMV",
                  "name": "get_stock_price",
                  "input": { "ticker": "^GSPC" }
                }
              ]
              ```

              You might then run your `get_stock_price` tool with `{"ticker": "^GSPC"}` as an
              input, and return the following back to the model in a subsequent `user`
              message:

              ```json
              [
                {
                  "type": "tool_result",
                  "tool_use_id": "toolu_01D7FLrfh4GYq7yT1ULFeyMV",
                  "content": "259.75 USD"
                }
              ]
              ```

              Tools can be used for workflows that include running client-side tools and
              functions, or more generally whenever you want the model to produce a particular
              JSON structure of output.

              See our
              [guide](https://platform.claude.com/docs/en/agents-and-tools/tool-use/overview)
              for more details.

          betas: Optional header to specify the beta version(s) you want to use.

          user_profile_id: The user profile ID to attribute this request to. Use when acting on behalf of a
              party other than your organization.

          workspace_id: Optional header to select the Workspace for this request. The value is a
              Workspace ID (for example, `wrkspc_011CZkZaBF1tNoB5wlCeusgy`).

              Only needed for credentials that can act on more than one Workspace. A
              credential that belongs to a specific Workspace may omit it; if sent, it must
              match that Workspace.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds

        Raises:
          AvailableToolsLimitExceededError:

          ClaudeCodeKeyCreatorNotMemberError:

          ClaudeCodeVersionTooOldError:

          CMEKKeyDisabledError:

          CMEKKeyNetworkBlockedError:

          CompactionBlockAmbiguousError:

          CompactionBlockMisplacedError:

          CompactionContentMismatchError:

          CompactionIncompleteTurnError:

          CompactionNothingToSummarizeError:

          CompactionSignatureInvalidError:

          CompactionTooManyToolReferencesError:

          CompactionToolChangesMismatchError:

          OrganizationOnHoldError:

          RequestBodyEncodingInvalidError:

          RequestBodyEncodingUnsupportedError:

          ThreadAlreadyContinuedError:

          ThreadContinueInFlightError:

          ThreadFingerprintMismatchError:

          ThreadUnsupportedRequestError:

          ToolNameConflictError:

          ToolReferenceUnresolvedError:

          ThreadNotFoundError:

          SkillReadBlockedUndecryptableError:

          RequestBodyTooLargeAfterDecodingError:

          EnforcedSpendLimitReachedError:

          RampLimitExceededError:

          CMEKKeyUnreachableError:

          CompactionUnavailableError:
        """
        ...

    @overload
    def create(
        self,
        *,
        max_tokens: int,
        messages: Iterable[BetaMessageParam],
        model: ModelParam,
        stream: bool,
        cache_control: Optional[BetaCacheControlEphemeralParam] | Omit = omit,
        compaction: Optional[BetaCompactionConfigParam] | Omit = omit,
        container: Optional[message_create_params.Container] | Omit = omit,
        context_management: Optional[BetaContextManagementConfigParam] | Omit = omit,
        diagnostics: Optional[BetaDiagnosticsParam] | Omit = omit,
        fallback_credit_token: Optional[message_create_params.FallbackCreditToken] | Omit = omit,
        fallbacks: Optional[BetaFallbacksParam] | Omit = omit,
        inference_geo: Optional[str] | Omit = omit,
        mcp_servers: Iterable[BetaRequestMCPServerURLDefinitionParam] | Omit = omit,
        metadata: BetaMetadataParam | Omit = omit,
        output_config: BetaOutputConfigParam | Omit = omit,
        service_tier: Literal["auto", "standard_only"] | Omit = omit,
        speed: Optional[Literal["standard", "fast"]] | Omit = omit,
        stop_sequences: SequenceNotStr[str] | Omit = omit,
        system: Union[str, Iterable[BetaTextBlockParam]] | Omit = omit,
        thinking: BetaThinkingConfigParam | Omit = omit,
        thread: Optional[BetaMessageThreadParam] | Omit = omit,
        tool_choice: BetaToolChoiceParam | Omit = omit,
        tools: Iterable[BetaToolLike] | Omit = omit,
        betas: List[AnthropicBetaParam] | Omit = omit,
        user_profile_id: str | Omit = omit,
        workspace_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> BetaMessage | Stream[BetaRawMessageStreamEvent]:
        """
        Send a structured list of input messages with text and/or image content, and the
        model will generate the next message in the conversation.

        The Messages API can be used for either single queries or stateless multi-turn
        conversations.

        Learn more about the Messages API in our
        [user guide](https://platform.claude.com/docs/en/get-started)

        Args:
          max_tokens: The maximum number of tokens to generate before stopping.

              Note that our models may stop _before_ reaching this maximum. This parameter
              only specifies the absolute maximum number of tokens to generate.

              Set to `0` to populate the
              [prompt cache](https://platform.claude.com/docs/en/build-with-claude/prompt-caching#pre-warming-the-cache)
              without generating a response.

              Different models have different maximum values for this parameter. See
              [models](https://platform.claude.com/docs/en/about-claude/models/overview) for
              details.

          messages: Input messages.

              Our models are trained to operate on alternating `user` and `assistant`
              conversational turns. When creating a new `Message`, you specify the prior
              conversational turns with the `messages` parameter, and the model then generates
              the next `Message` in the conversation. Consecutive `user` or `assistant` turns
              in your request will be combined into a single turn.

              Each input message must be an object with a `role` and `content`. You can
              specify a single `user`-role message, or you can include multiple `user` and
              `assistant` messages.

              If the final message uses the `assistant` role, the response content will
              continue immediately from the content in that message. This can be used to
              constrain part of the model's response. This is called prefill. On models that
              don't support prefill, creating a message that ends with a partial `assistant`
              response returns a 400 error. See
              [Prefill not supported](https://platform.claude.com/docs/en/api/errors#prefill-not-supported).

              Example with a single `user` message:

              ```json
              [{ "role": "user", "content": "Hello, Claude" }]
              ```

              Example with multiple conversational turns:

              ```json
              [
                { "role": "user", "content": "Hello there." },
                { "role": "assistant", "content": "Hi, I'm Claude. How can I help you?" },
                { "role": "user", "content": "Can you explain LLMs in plain English?" }
              ]
              ```

              Example with a partially-filled response from Claude, for models that support
              prefill:

              ```json
              [
                {
                  "role": "user",
                  "content": "What's the Greek name for Sun? (A) Sol (B) Helios (C) Sun"
                },
                { "role": "assistant", "content": "The best answer is (" }
              ]
              ```

              Each input message `content` may be either a single `string` or an array of
              content blocks, where each block has a specific `type`. Using a `string` for
              `content` is shorthand for an array of one content block of type `"text"`. The
              following input messages are equivalent:

              ```json
              { "role": "user", "content": "Hello, Claude" }
              ```

              ```json
              { "role": "user", "content": [{ "type": "text", "text": "Hello, Claude" }] }
              ```

              See
              [input examples](https://platform.claude.com/docs/en/build-with-claude/working-with-messages).

              Note that if you want to include a
              [system prompt](https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/claude-prompting-best-practices#give-claude-a-role),
              you can use the top-level `system` parameter.

              There is a limit of 100,000 messages in a single request.

          model: The model that will complete your prompt.

              See [models](https://docs.anthropic.com/en/docs/models-overview) for additional
              details and options.

          stream: Whether to incrementally stream the response using server-sent events. When
              `true`, SDKs return a raw event stream.

              In the TypeScript, Python and Ruby SDKs, the recommended way to stream is
              `messages.stream()`. It sets `stream` for you and accumulates the events into
              the final message. See
              [Streaming with SDKs](https://platform.claude.com/docs/en/build-with-claude/streaming#streaming-with-sdks)
              for an example in each language.

          cache_control: Top-level cache control automatically applies a cache_control marker to the last
              cacheable block in the request.

          compaction: Compaction configuration.

              When set on `POST /v1/messages`, the request is a compaction request: the
              conversation in `messages` is summarized and the response holds only the
              resulting `compaction` block (`stop_reason` `"compaction"`), which later
              requests send first in `messages` in place of the messages it summarizes.
              `POST /v1/messages/count_tokens` accepts this parameter and ignores it: the
              count it returns is for the conversation in `messages` as sent. Cannot be
              combined with `context_management`.

          container: Container identifier for reuse across requests.

          context_management: Context management configuration.

              This allows you to control how Claude manages context across multiple requests,
              such as whether to clear function results or not.

          diagnostics: Request-level diagnostics. Supply `previous_message_id` to have the response
              include `diagnostics.cache_miss_reason` explaining any prompt-cache divergence
              from that prior request.

          fallback_credit_token: The `fallback_credit_token` from a prior refusal's `stop_details`.

              When a preceding request was refused and returned a `fallback_credit_token`,
              pass that code here on the retry to have the retry's cache-creation tokens for
              the prefix that was warm on the refused model billed at the cache-read rate.
              Must be redeemed by the same organization and workspace, with the same request
              body (optionally extended by one appended `assistant` message whose content is
              the partial text — with any trailing whitespace stripped from the final text
              block — and paired server-tool blocks streamed before the refusal; the
              appended-assistant form is not available for requests with `output_format` set
              or forced `tool_choice`), on an eligible fallback model, on the same platform,
              and within 5 minutes of the refusal; a mismatch is a 400. A token minted
              mid-server-tool-loop whose partial content was continuable may only be redeemed
              with the appended-assistant form — if an exact-body retry is rejected with a 400
              saying the token must be redeemed by continuing the partial response, retry with
              the appended-assistant form instead.

              When the appended-assistant form is used on a model that otherwise disallows
              assistant-turn prefill, this token also authorizes that one prefill.

          fallbacks: Opt-in server-side retry on one or more substitute models when the requested
              model declines for policy reasons. Tried in order: if the first entry also
              declines, the second is tried, and so on. Some models don't support fallbacks;
              on those models, a list of fallback models returns a 400 error. See
              [Server-side fallback](https://platform.claude.com/docs/en/build-with-claude/refusals-and-fallback#server-side-fallback).
              The string "default" requests the requested model's server-defined default
              fallback configuration. On a model that doesn't support fallbacks, the request
              runs on the requested model alone, so a declined request stays declined.

          inference_geo: Specifies the geographic region for inference processing. If not specified, the
              workspace's `default_inference_geo` is used.

          mcp_servers: MCP servers to be utilized in this request

          metadata: An object describing metadata about the request.

          output_config: Configuration options for the model's output, such as the output format.

          service_tier: Determines whether to use priority capacity (if available) or standard capacity
              for this request.

              Anthropic offers different levels of service for your API requests. See
              [service-tiers](https://platform.claude.com/docs/en/api/service-tiers) for
              details.

          speed: The inference speed mode for this request. `"fast"` enables high
              output-tokens-per-second inference.

              Some models require the `fast-mode-2026-02-01` beta header for any `speed`
              value. See
              [fast mode](https://platform.claude.com/docs/en/build-with-claude/fast-mode) for
              which models.

          stop_sequences: Custom text sequences that will cause the model to stop generating.

              Our models will normally stop when they have naturally completed their turn,
              which will result in a response `stop_reason` of `"end_turn"`.

              If you want the model to stop generating when it encounters custom strings of
              text, you can use the `stop_sequences` parameter. If the model encounters one of
              the custom sequences, the response `stop_reason` value will be `"stop_sequence"`
              and the response `stop_sequence` value will contain the matched stop sequence.

          system: System prompt.

              A system prompt is a way of providing context and instructions to Claude, such
              as specifying a particular goal or role. See our
              [guide to system prompts](https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/claude-prompting-best-practices#give-claude-a-role).

          thinking: Configuration for Claude's thinking.

              With `{"type": "adaptive"}`, Claude decides when and how much to think. With
              `{"type": "enabled"}` (manual extended thinking), you set a `budget_tokens` of
              at least 1,024. Thinking tokens count toward your `max_tokens` limit.

              Which `type` values are accepted, and what happens when you omit `thinking`,
              depend on the model. See
              [thinking](https://platform.claude.com/docs/en/build-with-claude/thinking#configuring-thinking)
              for each model's behavior.

          thread: Server-held conversation state (a Thread). `{"type": "create"}` asks the server
              to hold this conversation's state under the response's `id`;
              `{"type": "continue", "previous_message_id": ...}` resumes from a previous
              response so only the new turn's messages are sent. The response shape is
              unchanged.

          tool_choice: How the model should use the provided tools. The model can use a specific tool,
              any available tool, decide by itself, or not use tools at all.

          tools: Definitions of tools that the model may use.

              If you include `tools` in your API request, the model may return `tool_use`
              content blocks that represent the model's use of those tools. You can then run
              those tools using the tool input generated by the model and then optionally
              return results back to the model using `tool_result` content blocks.

              There are two types of tools: **client tools** and **server tools**. The
              behavior described below applies to client tools. For
              [server tools](https://platform.claude.com/docs/en/agents-and-tools/tool-use/server-tools),
              see their individual documentation as each has its own behavior (e.g., the
              [web search tool](https://platform.claude.com/docs/en/agents-and-tools/tool-use/web-search-tool)).

              Each tool definition includes:

              - `name`: Name of the tool.
              - `description`: Optional, but strongly-recommended description of the tool.
              - `input_schema`: [JSON schema](https://json-schema.org/draft/2020-12) for the
                tool `input` shape that the model will produce in `tool_use` output content
                blocks.

              For example, if you defined `tools` as:

              ```json
              [
                {
                  "name": "get_stock_price",
                  "description": "Get the current stock price for a given ticker symbol.",
                  "input_schema": {
                    "type": "object",
                    "properties": {
                      "ticker": {
                        "type": "string",
                        "description": "The stock ticker symbol, e.g. AAPL for Apple Inc."
                      }
                    },
                    "required": ["ticker"]
                  }
                }
              ]
              ```

              And then asked the model "What's the S&P 500 at today?", the model might produce
              `tool_use` content blocks in the response like this:

              ```json
              [
                {
                  "type": "tool_use",
                  "id": "toolu_01D7FLrfh4GYq7yT1ULFeyMV",
                  "name": "get_stock_price",
                  "input": { "ticker": "^GSPC" }
                }
              ]
              ```

              You might then run your `get_stock_price` tool with `{"ticker": "^GSPC"}` as an
              input, and return the following back to the model in a subsequent `user`
              message:

              ```json
              [
                {
                  "type": "tool_result",
                  "tool_use_id": "toolu_01D7FLrfh4GYq7yT1ULFeyMV",
                  "content": "259.75 USD"
                }
              ]
              ```

              Tools can be used for workflows that include running client-side tools and
              functions, or more generally whenever you want the model to produce a particular
              JSON structure of output.

              See our
              [guide](https://platform.claude.com/docs/en/agents-and-tools/tool-use/overview)
              for more details.

          betas: Optional header to specify the beta version(s) you want to use.

          user_profile_id: The user profile ID to attribute this request to. Use when acting on behalf of a
              party other than your organization.

          workspace_id: Optional header to select the Workspace for this request. The value is a
              Workspace ID (for example, `wrkspc_011CZkZaBF1tNoB5wlCeusgy`).

              Only needed for credentials that can act on more than one Workspace. A
              credential that belongs to a specific Workspace may omit it; if sent, it must
              match that Workspace.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds

        Raises:
          AvailableToolsLimitExceededError:

          ClaudeCodeKeyCreatorNotMemberError:

          ClaudeCodeVersionTooOldError:

          CMEKKeyDisabledError:

          CMEKKeyNetworkBlockedError:

          CompactionBlockAmbiguousError:

          CompactionBlockMisplacedError:

          CompactionContentMismatchError:

          CompactionIncompleteTurnError:

          CompactionNothingToSummarizeError:

          CompactionSignatureInvalidError:

          CompactionTooManyToolReferencesError:

          CompactionToolChangesMismatchError:

          OrganizationOnHoldError:

          RequestBodyEncodingInvalidError:

          RequestBodyEncodingUnsupportedError:

          ThreadAlreadyContinuedError:

          ThreadContinueInFlightError:

          ThreadFingerprintMismatchError:

          ThreadUnsupportedRequestError:

          ToolNameConflictError:

          ToolReferenceUnresolvedError:

          ThreadNotFoundError:

          SkillReadBlockedUndecryptableError:

          RequestBodyTooLargeAfterDecodingError:

          EnforcedSpendLimitReachedError:

          RampLimitExceededError:

          CMEKKeyUnreachableError:

          CompactionUnavailableError:
        """
        ...

    @required_args(["max_tokens", "messages", "model"], ["max_tokens", "messages", "model", "stream"])
    def create(
        self,
        *,
        max_tokens: int,
        messages: Iterable[BetaMessageParam],
        model: ModelParam,
        cache_control: Optional[BetaCacheControlEphemeralParam] | Omit = omit,
        compaction: Optional[BetaCompactionConfigParam] | Omit = omit,
        container: Optional[message_create_params.Container] | Omit = omit,
        context_management: Optional[BetaContextManagementConfigParam] | Omit = omit,
        diagnostics: Optional[BetaDiagnosticsParam] | Omit = omit,
        fallback_credit_token: Optional[message_create_params.FallbackCreditToken] | Omit = omit,
        fallbacks: Optional[BetaFallbacksParam] | Omit = omit,
        inference_geo: Optional[str] | Omit = omit,
        mcp_servers: Iterable[BetaRequestMCPServerURLDefinitionParam] | Omit = omit,
        metadata: BetaMetadataParam | Omit = omit,
        output_config: BetaOutputConfigParam | Omit = omit,
        service_tier: Literal["auto", "standard_only"] | Omit = omit,
        speed: Optional[Literal["standard", "fast"]] | Omit = omit,
        stop_sequences: SequenceNotStr[str] | Omit = omit,
        stream: Literal[False] | Literal[True] | Omit = omit,
        system: Union[str, Iterable[BetaTextBlockParam]] | Omit = omit,
        thinking: BetaThinkingConfigParam | Omit = omit,
        thread: Optional[BetaMessageThreadParam] | Omit = omit,
        tool_choice: BetaToolChoiceParam | Omit = omit,
        tools: Iterable[BetaToolLike] | Omit = omit,
        betas: List[AnthropicBetaParam] | Omit = omit,
        user_profile_id: str | Omit = omit,
        workspace_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> BetaMessage | Stream[BetaRawMessageStreamEvent]:
        if not stream and not is_given(timeout) and self._client.timeout == DEFAULT_TIMEOUT:
            timeout = self._client._calculate_nonstreaming_timeout(
                max_tokens, MODEL_NONSTREAMING_TOKENS.get(model, None)
            )

        if model in DEPRECATED_MODELS:
            warnings.warn(
                f"The model '{model}' is deprecated and will reach end-of-life on {DEPRECATED_MODELS[model]}.\nPlease migrate to a newer model. Visit https://docs.anthropic.com/en/docs/resources/model-deprecations for more information.",
                DeprecationWarning,
                stacklevel=3,
            )

        if model in MODELS_TO_WARN_WITH_THINKING_ENABLED and thinking and thinking["type"] == "enabled":
            warnings.warn(
                f"Using Claude with {model} and 'thinking.type=enabled' is deprecated. Use 'thinking.type=adaptive' instead which results in better model performance in our testing: https://platform.claude.com/docs/en/build-with-claude/adaptive-thinking",
                UserWarning,
                stacklevel=3,
            )

        tools = _to_tool_params(tools)
        extra_headers = merge_headers(
            strip_not_given(
                {
                    "anthropic-beta": ",".join(str(e) for e in betas) if is_given(betas) else not_given,
                    "anthropic-user-profile-id": user_profile_id,
                    "anthropic-workspace-id": workspace_id,
                }
            ),
            _stainless_helper_header(tools, messages),
            extra_headers or {},
        )
        return self._post(
            "/v1/messages",
            body={
                "max_tokens": max_tokens,
                "messages": messages,
                "model": model,
                "cache_control": cache_control,
                "compaction": compaction,
                "container": container,
                "context_management": context_management,
                "diagnostics": diagnostics,
                "fallback_credit_token": fallback_credit_token,
                "fallbacks": fallbacks,
                "inference_geo": inference_geo,
                "mcp_servers": mcp_servers,
                "metadata": metadata,
                "output_config": output_config,
                "service_tier": service_tier,
                "speed": speed,
                "stop_sequences": stop_sequences,
                "stream": stream,
                "system": system,
                "thinking": thinking,
                "thread": thread,
                "tool_choice": tool_choice,
                "tools": tools,
            },
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                qualifiers={"beta": "true"},
                span_name="anthropic.messages.create",
                span_route="/v1/messages",
                span_attributes=messages_create_request_attributes,
            ),
            cast_to=BetaMessage,
            stream=stream or False,
            stream_cls=Stream[BetaRawMessageStreamEvent],
        )

    def parse(
        self,
        *,
        max_tokens: int,
        messages: Iterable[BetaMessageParam],
        model: ModelParam,
        cache_control: Optional[BetaCacheControlEphemeralParam] | Omit = omit,
        compaction: Optional[BetaCompactionConfigParam] | Omit = omit,
        container: Optional[message_create_params.Container] | Omit = omit,
        context_management: Optional[BetaContextManagementConfigParam] | Omit = omit,
        diagnostics: Optional[BetaDiagnosticsParam] | Omit = omit,
        fallback_credit_token: Optional[message_create_params.FallbackCreditToken] | Omit = omit,
        fallbacks: Optional[BetaFallbacksParam] | Omit = omit,
        inference_geo: Optional[str] | Omit = omit,
        mcp_servers: Iterable[BetaRequestMCPServerURLDefinitionParam] | Omit = omit,
        metadata: BetaMetadataParam | Omit = omit,
        output_config: BetaOutputConfigParam | Omit = omit,
        output_format: Optional[type[ResponseFormatT]] | Omit = omit,
        service_tier: Literal["auto", "standard_only"] | Omit = omit,
        speed: Optional[Literal["standard", "fast"]] | Omit = omit,
        stop_sequences: SequenceNotStr[str] | Omit = omit,
        system: Union[str, Iterable[BetaTextBlockParam]] | Omit = omit,
        thinking: BetaThinkingConfigParam | Omit = omit,
        thread: Optional[BetaMessageThreadParam] | Omit = omit,
        tool_choice: BetaToolChoiceParam | Omit = omit,
        tools: Iterable[BetaToolLike] | Omit = omit,
        betas: List[AnthropicBetaParam] | Omit = omit,
        user_profile_id: str | Omit = omit,
        workspace_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> ParsedBetaMessage[ResponseFormatT]:
        _validate_output_config_conflict(output_config, output_format)

        if not is_given(timeout) and self._client.timeout == DEFAULT_TIMEOUT:
            timeout = self._client._calculate_nonstreaming_timeout(
                max_tokens, MODEL_NONSTREAMING_TOKENS.get(model, None)
            )

        if model in DEPRECATED_MODELS:
            warnings.warn(
                f"The model '{model}' is deprecated and will reach end-of-life on {DEPRECATED_MODELS[model]}.\nPlease migrate to a newer model. Visit https://docs.anthropic.com/en/docs/resources/model-deprecations for more information.",
                DeprecationWarning,
                stacklevel=3,
            )

        if model in MODELS_TO_WARN_WITH_THINKING_ENABLED and thinking and thinking["type"] == "enabled":
            warnings.warn(
                f"Using Claude with {model} and 'thinking.type=enabled' is deprecated. Use 'thinking.type=adaptive' instead which results in better model performance in our testing: https://platform.claude.com/docs/en/build-with-claude/adaptive-thinking",
                UserWarning,
                stacklevel=3,
            )

        tools = _to_tool_params(tools)
        extra_headers = merge_headers(
            _helper_header("beta.messages.parse"),
            strip_not_given(
                {
                    "anthropic-beta": ",".join(str(e) for e in betas) if is_given(betas) else not_given,
                    "anthropic-user-profile-id": user_profile_id,
                    "anthropic-workspace-id": workspace_id,
                }
            ),
            _stainless_helper_header(tools, messages),
            extra_headers or {},
        )

        if is_given(output_format) and output_format is not None:
            merged_output_config = merge_output_config(output_config, to_json_output_format(output_format))
        else:
            merged_output_config = output_config

        def parser(response: BetaMessage) -> ParsedBetaMessage[ResponseFormatT]:
            return parse_beta_response(
                response=response,
                output_format=cast(
                    ResponseFormatT,
                    output_format if is_given(output_format) and output_format is not None else not_given,
                ),
            )

        return self._post(
            "/v1/messages",
            body={
                "max_tokens": max_tokens,
                "messages": messages,
                "model": model,
                "cache_control": cache_control,
                "compaction": compaction,
                "container": container,
                "context_management": context_management,
                "diagnostics": diagnostics,
                "fallback_credit_token": fallback_credit_token,
                "fallbacks": fallbacks,
                "inference_geo": inference_geo,
                "mcp_servers": mcp_servers,
                "metadata": metadata,
                "output_config": merged_output_config,
                "output_format": omit,
                "service_tier": service_tier,
                "speed": speed,
                "stop_sequences": stop_sequences,
                "system": system,
                "thinking": thinking,
                "thread": thread,
                "tool_choice": tool_choice,
                "tools": tools,
            },
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                post_parser=parser,
                qualifiers={"beta": "true"},
                span_name="anthropic.messages.create",
                span_route="/v1/messages",
                span_attributes=messages_create_request_attributes,
            ),
            cast_to=cast(Type[ParsedBetaMessage[ResponseFormatT]], BetaMessage),
            stream=False,
        )

    @overload
    def tool_runner(
        self,
        *,
        max_tokens: int,
        messages: Iterable[BetaMessageParam],
        model: ModelParam,
        tools: Iterable[BetaRunnableTool | BetaRunnableToolset | BetaToolUnionParam],
        cache_control: Optional[BetaCacheControlEphemeralParam] | Omit = omit,
        container: Optional[message_create_params.Container] | Omit = omit,
        context_management: Optional[BetaContextManagementConfigParam] | Omit = omit,
        diagnostics: Optional[BetaDiagnosticsParam] | Omit = omit,
        fallback_credit_token: Optional[message_create_params.FallbackCreditToken] | Omit = omit,
        fallbacks: Optional[BetaFallbacksParam] | Omit = omit,
        inference_geo: Optional[str] | Omit = omit,
        max_iterations: int | Omit = omit,
        mcp_servers: Iterable[BetaRequestMCPServerURLDefinitionParam] | Omit = omit,
        metadata: BetaMetadataParam | Omit = omit,
        output_config: BetaOutputConfigParam | Omit = omit,
        output_format: Optional[type[ResponseFormatT]] | Omit = omit,
        service_tier: Literal["auto", "standard_only"] | Omit = omit,
        speed: Optional[Literal["standard", "fast"]] | Omit = omit,
        stop_sequences: SequenceNotStr[str] | Omit = omit,
        stream: Literal[False] | Omit = omit,
        system: Union[str, Iterable[BetaTextBlockParam]] | Omit = omit,
        thinking: BetaThinkingConfigParam | Omit = omit,
        thread: Optional[Literal[False]] | Omit = omit,
        tool_choice: BetaToolChoiceParam | Omit = omit,
        betas: List[AnthropicBetaParam] | Omit = omit,
        user_profile_id: str | Omit = omit,
        workspace_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> BetaToolRunner[ResponseFormatT]: ...

    @overload
    def tool_runner(
        self,
        *,
        max_tokens: int,
        messages: Iterable[BetaMessageParam],
        model: ModelParam,
        tools: Iterable[BetaRunnableTool | BetaRunnableToolset | BetaToolUnionParam],
        cache_control: Optional[BetaCacheControlEphemeralParam] | Omit = omit,
        stream: Literal[True],
        max_iterations: int | Omit = omit,
        run_tools_eagerly: bool = False,
        container: Optional[message_create_params.Container] | Omit = omit,
        context_management: Optional[BetaContextManagementConfigParam] | Omit = omit,
        diagnostics: Optional[BetaDiagnosticsParam] | Omit = omit,
        fallback_credit_token: Optional[message_create_params.FallbackCreditToken] | Omit = omit,
        fallbacks: Optional[BetaFallbacksParam] | Omit = omit,
        inference_geo: Optional[str] | Omit = omit,
        mcp_servers: Iterable[BetaRequestMCPServerURLDefinitionParam] | Omit = omit,
        metadata: BetaMetadataParam | Omit = omit,
        output_config: BetaOutputConfigParam | Omit = omit,
        output_format: Optional[type[ResponseFormatT]] | Omit = omit,
        service_tier: Literal["auto", "standard_only"] | Omit = omit,
        speed: Optional[Literal["standard", "fast"]] | Omit = omit,
        stop_sequences: SequenceNotStr[str] | Omit = omit,
        system: Union[str, Iterable[BetaTextBlockParam]] | Omit = omit,
        thinking: BetaThinkingConfigParam | Omit = omit,
        thread: Optional[Literal[False]] | Omit = omit,
        tool_choice: BetaToolChoiceParam | Omit = omit,
        betas: List[AnthropicBetaParam] | Omit = omit,
        user_profile_id: str | Omit = omit,
        workspace_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> BetaStreamingToolRunner[ResponseFormatT]: ...

    @overload
    def tool_runner(
        self,
        *,
        max_tokens: int,
        messages: Iterable[BetaMessageParam],
        model: ModelParam,
        tools: Iterable[BetaRunnableTool | BetaRunnableToolset | BetaToolUnionParam],
        stream: bool,
        max_iterations: int | Omit = omit,
        run_tools_eagerly: bool = False,
        cache_control: Optional[BetaCacheControlEphemeralParam] | Omit = omit,
        container: Optional[message_create_params.Container] | Omit = omit,
        context_management: Optional[BetaContextManagementConfigParam] | Omit = omit,
        diagnostics: Optional[BetaDiagnosticsParam] | Omit = omit,
        fallback_credit_token: Optional[message_create_params.FallbackCreditToken] | Omit = omit,
        fallbacks: Optional[BetaFallbacksParam] | Omit = omit,
        inference_geo: Optional[str] | Omit = omit,
        mcp_servers: Iterable[BetaRequestMCPServerURLDefinitionParam] | Omit = omit,
        metadata: BetaMetadataParam | Omit = omit,
        output_config: BetaOutputConfigParam | Omit = omit,
        output_format: Optional[type[ResponseFormatT]] | Omit = omit,
        service_tier: Literal["auto", "standard_only"] | Omit = omit,
        speed: Optional[Literal["standard", "fast"]] | Omit = omit,
        stop_sequences: SequenceNotStr[str] | Omit = omit,
        system: Union[str, Iterable[BetaTextBlockParam]] | Omit = omit,
        thinking: BetaThinkingConfigParam | Omit = omit,
        thread: Optional[Literal[False]] | Omit = omit,
        tool_choice: BetaToolChoiceParam | Omit = omit,
        betas: List[AnthropicBetaParam] | Omit = omit,
        user_profile_id: str | Omit = omit,
        workspace_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> BetaStreamingToolRunner[ResponseFormatT] | BetaToolRunner[ResponseFormatT]: ...

    def tool_runner(
        self,
        *,
        max_tokens: int,
        messages: Iterable[BetaMessageParam],
        model: ModelParam,
        tools: Iterable[BetaRunnableTool | BetaRunnableToolset | BetaToolUnionParam],
        max_iterations: int | Omit = omit,
        run_tools_eagerly: bool = False,
        cache_control: Optional[BetaCacheControlEphemeralParam] | Omit = omit,
        container: Optional[message_create_params.Container] | Omit = omit,
        context_management: Optional[BetaContextManagementConfigParam] | Omit = omit,
        diagnostics: Optional[BetaDiagnosticsParam] | Omit = omit,
        fallback_credit_token: Optional[message_create_params.FallbackCreditToken] | Omit = omit,
        fallbacks: Optional[BetaFallbacksParam] | Omit = omit,
        inference_geo: Optional[str] | Omit = omit,
        mcp_servers: Iterable[BetaRequestMCPServerURLDefinitionParam] | Omit = omit,
        metadata: BetaMetadataParam | Omit = omit,
        output_config: BetaOutputConfigParam | Omit = omit,
        output_format: Optional[type[ResponseFormatT]] | Omit = omit,
        service_tier: Literal["auto", "standard_only"] | Omit = omit,
        speed: Optional[Literal["standard", "fast"]] | Omit = omit,
        stop_sequences: SequenceNotStr[str] | Omit = omit,
        stream: Literal[True] | Literal[False] | Omit = omit,
        system: Union[str, Iterable[BetaTextBlockParam]] | Omit = omit,
        thinking: BetaThinkingConfigParam | Omit = omit,
        thread: Optional[Literal[False]] | Omit = omit,
        tool_choice: BetaToolChoiceParam | Omit = omit,
        betas: List[AnthropicBetaParam] | Omit = omit,
        user_profile_id: str | Omit = omit,
        workspace_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> BetaStreamingToolRunner[ResponseFormatT] | BetaToolRunner[ResponseFormatT]:
        """Run the tools the model calls until it stops asking for them, yielding each assistant message.

        The loop runs over a message thread by default, so each turn sends only new messages. Pass `thread=False` to
        send the full history every turn.

        Args:
          run_tools_eagerly: Run each tool as soon as its call is complete, before the reply finishes, instead of
              once you are done with the reply. This is optimistic: if the reply is interrupted or changes
              course, the tool may have already run, so use `runner.defer_tool_call()` to hold the calls that
              aren't safe to run twice. The calls run one at a time, and reading the stream waits while one
              runs. A toolset call, such as a browser or computer action, runs early too, and its toolset's
              `confirm` is still asked before it runs. Requires `stream=True`.

              This will be the default in a future version.
        """
        _validate_output_config_conflict(output_config, output_format)

        if run_tools_eagerly and not stream:
            raise ValueError("`run_tools_eagerly=True` and `stream=False` are mutually exclusive")

        if model in DEPRECATED_MODELS:
            warnings.warn(
                f"The model '{model}' is deprecated and will reach end-of-life on {DEPRECATED_MODELS[model]}.\nPlease migrate to a newer model. Visit https://docs.anthropic.com/en/docs/resources/model-deprecations for more information.",
                DeprecationWarning,
                stacklevel=3,
            )

        if model in MODELS_TO_WARN_WITH_THINKING_ENABLED and thinking and thinking["type"] == "enabled":
            warnings.warn(
                f"Using Claude with {model} and 'thinking.type=enabled' is deprecated. Use 'thinking.type=adaptive' instead which results in better model performance in our testing: https://platform.claude.com/docs/en/build-with-claude/adaptive-thinking",
                UserWarning,
                stacklevel=3,
            )

        # An async tool or toolset is refused here, before anything is sent. The thread keeps the tools in the order
        # given and sends each toolset as its `tools[]` entry.
        tools = list(tools)
        partition_sync_tools(tools)

        params = cast(
            message_create_params.ParseMessageCreateParamsBase[ResponseFormatT],
            given(
                {
                    "max_tokens": max_tokens,
                    "messages": messages,
                    "model": model,
                    "cache_control": cache_control,
                    "container": container,
                    "context_management": context_management,
                    "diagnostics": diagnostics,
                    "fallback_credit_token": fallback_credit_token,
                    "fallbacks": fallbacks,
                    "inference_geo": inference_geo,
                    "mcp_servers": mcp_servers,
                    "metadata": metadata,
                    "output_config": output_config,
                    "output_format": output_format,
                    "service_tier": service_tier,
                    "speed": speed,
                    "stop_sequences": stop_sequences,
                    "system": system,
                    "thinking": thinking,
                    "thread": thread,
                    "tool_choice": tool_choice,
                    "tools": tools,
                    "betas": betas,
                    "user_profile_id": user_profile_id,
                    "workspace_id": workspace_id,
                }
            ),
        )
        message_thread = BetaMessageThread[ResponseFormatT]._for_tool_runner(cast("Anthropic", self._client), params)
        if run_tools_eagerly:
            # `thread.tool_runner()` has no `run_tools_eagerly` parameter, so the eager runner is made here.
            return BetaStreamingToolRunner[ResponseFormatT](
                thread=message_thread,
                options=turn_overrides(
                    extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
                ),
                max_iterations=max_iterations if is_given(max_iterations) else None,
                run_tools_eagerly=True,
            )
        return message_thread.tool_runner(
            max_iterations=max_iterations,
            stream=stream,
            extra_headers=extra_headers,
            extra_query=extra_query,
            extra_body=extra_body,
            timeout=timeout,
        )

    def thread(
        self,
        *,
        max_tokens: int,
        model: ModelParam,
        messages: Iterable[BetaMessageParam] | Omit = omit,
        tools: Iterable[BetaRunnableTool | BetaToolUnionParam] | Omit = omit,
        output_format: Optional[type[ResponseFormatT]] | Omit = omit,
        unsupported_request_behavior: UnsupportedRequestBehavior = "error",
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
        **params: Unpack[ThreadCreateParams],
    ) -> BetaMessageThread[ResponseFormatT]:
        """Start a message thread: a conversation the server holds between turns, so each request sends only the new
        messages. Takes the arguments of `create()` except `thread`, with `messages` optional, and sends nothing."""
        return BetaMessageThread(
            cast("Anthropic", self._client),
            max_tokens=max_tokens,
            model=model,
            messages=messages,
            tools=tools,
            output_format=output_format,
            unsupported_request_behavior=unsupported_request_behavior,
            extra_headers=extra_headers,
            extra_query=extra_query,
            extra_body=extra_body,
            timeout=timeout,
            **params,
        )

    def stream(
        self,
        *,
        max_tokens: int,
        messages: Iterable[BetaMessageParam],
        model: ModelParam,
        cache_control: Optional[BetaCacheControlEphemeralParam] | Omit = omit,
        compaction: Optional[BetaCompactionConfigParam] | Omit = omit,
        container: Optional[message_create_params.Container] | Omit = omit,
        context_management: Optional[BetaContextManagementConfigParam] | Omit = omit,
        diagnostics: Optional[BetaDiagnosticsParam] | Omit = omit,
        fallback_credit_token: Optional[message_create_params.FallbackCreditToken] | Omit = omit,
        fallbacks: Optional[BetaFallbacksParam] | Omit = omit,
        inference_geo: Optional[str] | Omit = omit,
        mcp_servers: Iterable[BetaRequestMCPServerURLDefinitionParam] | Omit = omit,
        metadata: BetaMetadataParam | Omit = omit,
        output_config: BetaOutputConfigParam | Omit = omit,
        output_format: Optional[type[ResponseFormatT]] | Omit = omit,
        service_tier: Literal["auto", "standard_only"] | Omit = omit,
        speed: Optional[Literal["standard", "fast"]] | Omit = omit,
        stop_sequences: SequenceNotStr[str] | Omit = omit,
        system: Union[str, Iterable[BetaTextBlockParam]] | Omit = omit,
        thinking: BetaThinkingConfigParam | Omit = omit,
        thread: Optional[BetaMessageThreadParam] | Omit = omit,
        tool_choice: BetaToolChoiceParam | Omit = omit,
        tools: Iterable[BetaToolLike] | Omit = omit,
        betas: List[AnthropicBetaParam] | Omit = omit,
        user_profile_id: str | Omit = omit,
        workspace_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> BetaMessageStreamManager[ResponseFormatT]:
        _validate_output_config_conflict(output_config, output_format)

        if model in DEPRECATED_MODELS:
            warnings.warn(
                f"The model '{model}' is deprecated and will reach end-of-life on {DEPRECATED_MODELS[model]}.\nPlease migrate to a newer model. Visit https://docs.anthropic.com/en/docs/resources/model-deprecations for more information.",
                DeprecationWarning,
                stacklevel=3,
            )

        if model in MODELS_TO_WARN_WITH_THINKING_ENABLED and thinking and thinking["type"] == "enabled":
            warnings.warn(
                f"Using Claude with {model} and 'thinking.type=enabled' is deprecated. Use 'thinking.type=adaptive' instead which results in better model performance in our testing: https://platform.claude.com/docs/en/build-with-claude/adaptive-thinking",
                UserWarning,
                stacklevel=3,
            )

        """Create a Message stream"""
        tools = _to_tool_params(tools)
        extra_headers = merge_headers(
            {
                _STAINLESS_HELPER_METHOD_HEADER: _HELPER_METHOD_STREAM,
                _STAINLESS_STREAM_HELPER_HEADER: "beta.messages",
            },
            strip_not_given(
                {
                    "anthropic-beta": ",".join(str(e) for e in betas) if is_given(betas) else not_given,
                    "anthropic-user-profile-id": user_profile_id,
                    "anthropic-workspace-id": workspace_id,
                }
            ),
            _stainless_helper_header(tools, messages),
            extra_headers or {},
        )

        transformed_output_format: BetaJSONOutputFormatParam | Omit = omit
        if is_given(output_format) and output_format is not None:
            transformed_output_format = to_json_output_format(output_format)
        merged_output_config = merge_output_config(output_config, transformed_output_format)

        make_request = partial(
            self._post,
            "/v1/messages",
            body={
                "max_tokens": max_tokens,
                "messages": messages,
                "model": model,
                "cache_control": cache_control,
                "compaction": compaction,
                "metadata": metadata,
                "output_config": merged_output_config,
                "output_format": omit,
                "container": container,
                "context_management": context_management,
                "diagnostics": diagnostics,
                "fallback_credit_token": fallback_credit_token,
                "fallbacks": fallbacks,
                "inference_geo": inference_geo,
                "mcp_servers": mcp_servers,
                "service_tier": service_tier,
                "speed": speed,
                "stop_sequences": stop_sequences,
                "system": system,
                "thinking": thinking,
                "thread": thread,
                "tools": tools,
                "tool_choice": tool_choice,
                "stream": True,
            },
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                qualifiers={"beta": "true"},
                span_name="anthropic.messages.create",
                span_route="/v1/messages",
                span_attributes=messages_create_request_attributes,
            ),
            cast_to=BetaMessage,
            stream=True,
            stream_cls=Stream[BetaRawMessageStreamEvent],
        )
        return BetaMessageStreamManager(
            make_request,
            output_format=cast(ResponseFormatT, output_format),
        )

    def count_tokens(
        self,
        *,
        messages: Iterable[BetaMessageParam],
        model: ModelParam,
        cache_control: Optional[BetaCacheControlEphemeralParam] | Omit = omit,
        compaction: Optional[BetaCompactionConfigParam] | Omit = omit,
        context_management: Optional[BetaContextManagementConfigParam] | Omit = omit,
        mcp_servers: Iterable[BetaRequestMCPServerURLDefinitionParam] | Omit = omit,
        output_config: BetaOutputConfigParam | Omit = omit,
        speed: Optional[Literal["standard", "fast"]] | Omit = omit,
        system: Union[str, Iterable[BetaTextBlockParam]] | Omit = omit,
        thinking: BetaThinkingConfigParam | Omit = omit,
        tool_choice: BetaToolChoiceParam | Omit = omit,
        tools: Iterable[BetaToolLike] | Omit = omit,
        betas: List[AnthropicBetaParam] | Omit = omit,
        user_profile_id: str | Omit = omit,
        workspace_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> BetaMessageTokensCount:
        """
        Count the number of tokens in a Message.

        The Token Count API can be used to count the number of tokens in a Message,
        including tools, images, and documents, without creating it.

        Learn more about token counting in our
        [user guide](https://platform.claude.com/docs/en/build-with-claude/token-counting)

        Args:
          messages: Input messages.

              Our models are trained to operate on alternating `user` and `assistant`
              conversational turns. When creating a new `Message`, you specify the prior
              conversational turns with the `messages` parameter, and the model then generates
              the next `Message` in the conversation. Consecutive `user` or `assistant` turns
              in your request will be combined into a single turn.

              Each input message must be an object with a `role` and `content`. You can
              specify a single `user`-role message, or you can include multiple `user` and
              `assistant` messages.

              If the final message uses the `assistant` role, the response content will
              continue immediately from the content in that message. This can be used to
              constrain part of the model's response. This is called prefill. On models that
              don't support prefill, creating a message that ends with a partial `assistant`
              response returns a 400 error. See
              [Prefill not supported](https://platform.claude.com/docs/en/api/errors#prefill-not-supported).

              Example with a single `user` message:

              ```json
              [{ "role": "user", "content": "Hello, Claude" }]
              ```

              Example with multiple conversational turns:

              ```json
              [
                { "role": "user", "content": "Hello there." },
                { "role": "assistant", "content": "Hi, I'm Claude. How can I help you?" },
                { "role": "user", "content": "Can you explain LLMs in plain English?" }
              ]
              ```

              Example with a partially-filled response from Claude, for models that support
              prefill:

              ```json
              [
                {
                  "role": "user",
                  "content": "What's the Greek name for Sun? (A) Sol (B) Helios (C) Sun"
                },
                { "role": "assistant", "content": "The best answer is (" }
              ]
              ```

              Each input message `content` may be either a single `string` or an array of
              content blocks, where each block has a specific `type`. Using a `string` for
              `content` is shorthand for an array of one content block of type `"text"`. The
              following input messages are equivalent:

              ```json
              { "role": "user", "content": "Hello, Claude" }
              ```

              ```json
              { "role": "user", "content": [{ "type": "text", "text": "Hello, Claude" }] }
              ```

              See
              [input examples](https://platform.claude.com/docs/en/build-with-claude/working-with-messages).

              Note that if you want to include a
              [system prompt](https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/claude-prompting-best-practices#give-claude-a-role),
              you can use the top-level `system` parameter.

              There is a limit of 100,000 messages in a single request.

          model: The model that will complete your prompt.

              See [models](https://docs.anthropic.com/en/docs/models-overview) for additional
              details and options.

          cache_control: Top-level cache control automatically applies a cache_control marker to the last
              cacheable block in the request.

          compaction: Compaction configuration.

              When set on `POST /v1/messages`, the request is a compaction request: the
              conversation in `messages` is summarized and the response holds only the
              resulting `compaction` block (`stop_reason` `"compaction"`), which later
              requests send first in `messages` in place of the messages it summarizes.
              `POST /v1/messages/count_tokens` accepts this parameter and ignores it: the
              count it returns is for the conversation in `messages` as sent. Cannot be
              combined with `context_management`.

          context_management: Context management configuration.

              This allows you to control how Claude manages context across multiple requests,
              such as whether to clear function results or not.

          mcp_servers: MCP servers to be utilized in this request

          output_config: Configuration options for the model's output, such as the output format.

          speed: The inference speed mode for this request. `"fast"` enables high
              output-tokens-per-second inference.

              Some models require the `fast-mode-2026-02-01` beta header for any `speed`
              value. See
              [fast mode](https://platform.claude.com/docs/en/build-with-claude/fast-mode) for
              which models.

          system: System prompt.

              A system prompt is a way of providing context and instructions to Claude, such
              as specifying a particular goal or role. See our
              [guide to system prompts](https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/claude-prompting-best-practices#give-claude-a-role).

          thinking: Configuration for Claude's thinking.

              With `{"type": "adaptive"}`, Claude decides when and how much to think. With
              `{"type": "enabled"}` (manual extended thinking), you set a `budget_tokens` of
              at least 1,024. Thinking tokens count toward your `max_tokens` limit.

              Which `type` values are accepted, and what happens when you omit `thinking`,
              depend on the model. See
              [thinking](https://platform.claude.com/docs/en/build-with-claude/thinking#configuring-thinking)
              for each model's behavior.

          tool_choice: How the model should use the provided tools. The model can use a specific tool,
              any available tool, decide by itself, or not use tools at all.

          tools: Definitions of tools that the model may use.

              If you include `tools` in your API request, the model may return `tool_use`
              content blocks that represent the model's use of those tools. You can then run
              those tools using the tool input generated by the model and then optionally
              return results back to the model using `tool_result` content blocks.

              There are two types of tools: **client tools** and **server tools**. The
              behavior described below applies to client tools. For
              [server tools](https://platform.claude.com/docs/en/agents-and-tools/tool-use/server-tools),
              see their individual documentation as each has its own behavior (e.g., the
              [web search tool](https://platform.claude.com/docs/en/agents-and-tools/tool-use/web-search-tool)).

              Each tool definition includes:

              - `name`: Name of the tool.
              - `description`: Optional, but strongly-recommended description of the tool.
              - `input_schema`: [JSON schema](https://json-schema.org/draft/2020-12) for the
                tool `input` shape that the model will produce in `tool_use` output content
                blocks.

              For example, if you defined `tools` as:

              ```json
              [
                {
                  "name": "get_stock_price",
                  "description": "Get the current stock price for a given ticker symbol.",
                  "input_schema": {
                    "type": "object",
                    "properties": {
                      "ticker": {
                        "type": "string",
                        "description": "The stock ticker symbol, e.g. AAPL for Apple Inc."
                      }
                    },
                    "required": ["ticker"]
                  }
                }
              ]
              ```

              And then asked the model "What's the S&P 500 at today?", the model might produce
              `tool_use` content blocks in the response like this:

              ```json
              [
                {
                  "type": "tool_use",
                  "id": "toolu_01D7FLrfh4GYq7yT1ULFeyMV",
                  "name": "get_stock_price",
                  "input": { "ticker": "^GSPC" }
                }
              ]
              ```

              You might then run your `get_stock_price` tool with `{"ticker": "^GSPC"}` as an
              input, and return the following back to the model in a subsequent `user`
              message:

              ```json
              [
                {
                  "type": "tool_result",
                  "tool_use_id": "toolu_01D7FLrfh4GYq7yT1ULFeyMV",
                  "content": "259.75 USD"
                }
              ]
              ```

              Tools can be used for workflows that include running client-side tools and
              functions, or more generally whenever you want the model to produce a particular
              JSON structure of output.

              See our
              [guide](https://platform.claude.com/docs/en/agents-and-tools/tool-use/overview)
              for more details.

          betas: Optional header to specify the beta version(s) you want to use.

          user_profile_id: The user profile ID to attribute this request to. Use when acting on behalf of a
              party other than your organization.

          workspace_id: Optional header to select the Workspace for this request. The value is a
              Workspace ID (for example, `wrkspc_011CZkZaBF1tNoB5wlCeusgy`).

              Only needed for credentials that can act on more than one Workspace. A
              credential that belongs to a specific Workspace may omit it; if sent, it must
              match that Workspace.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds

        Raises:
          AvailableToolsLimitExceededError:

          ClaudeCodeKeyCreatorNotMemberError:

          CompactionBlockAmbiguousError:

          CompactionBlockMisplacedError:

          CompactionContentMismatchError:

          CompactionNothingToSummarizeError:

          CompactionSignatureInvalidError:

          CompactionToolChangesMismatchError:

          OrganizationOnHoldError:

          RequestBodyEncodingInvalidError:

          RequestBodyEncodingUnsupportedError:

          ToolNameConflictError:

          ToolReferenceUnresolvedError:

          RequestBodyTooLargeAfterDecodingError:

          EnforcedSpendLimitReachedError:

          CompactionUnavailableError:
        """
        tools = _to_tool_params(tools)
        extra_headers = {
            **strip_not_given(
                {
                    "anthropic-beta": ",".join(chain((str(e) for e in betas), ["token-counting-2024-11-01"]))
                    if is_given(betas)
                    else not_given,
                    "anthropic-user-profile-id": user_profile_id,
                    "anthropic-workspace-id": workspace_id,
                }
            ),
            **(extra_headers or {}),
        }
        extra_headers = {"anthropic-beta": "token-counting-2024-11-01", **(extra_headers or {})}
        return self._post(
            "/v1/messages/count_tokens",
            body={
                "messages": messages,
                "model": model,
                "cache_control": cache_control,
                "compaction": compaction,
                "context_management": context_management,
                "mcp_servers": mcp_servers,
                "output_config": output_config,
                "speed": speed,
                "system": system,
                "thinking": thinking,
                "tool_choice": tool_choice,
                "tools": tools,
            },
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                qualifiers={"beta": "true"},
                span_name="anthropic.messages.count_tokens",
                span_route="/v1/messages/count_tokens",
            ),
            cast_to=BetaMessageTokensCount,
        )


class AsyncMessages(AsyncAPIResource):
    @cached_property
    def batches(self) -> AsyncBatches:
        return AsyncBatches(self._client)

    @cached_property
    def with_raw_response(self) -> AsyncMessagesWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://platform.claude.com/docs/en/api/sdks/python
        """
        return AsyncMessagesWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncMessagesWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://platform.claude.com/docs/en/api/sdks/python
        """
        return AsyncMessagesWithStreamingResponse(self)

    @overload
    async def create(
        self,
        *,
        max_tokens: int,
        messages: Iterable[BetaMessageParam],
        model: ModelParam,
        cache_control: Optional[BetaCacheControlEphemeralParam] | Omit = omit,
        compaction: Optional[BetaCompactionConfigParam] | Omit = omit,
        container: Optional[message_create_params.Container] | Omit = omit,
        context_management: Optional[BetaContextManagementConfigParam] | Omit = omit,
        diagnostics: Optional[BetaDiagnosticsParam] | Omit = omit,
        fallback_credit_token: Optional[message_create_params.FallbackCreditToken] | Omit = omit,
        fallbacks: Optional[BetaFallbacksParam] | Omit = omit,
        inference_geo: Optional[str] | Omit = omit,
        mcp_servers: Iterable[BetaRequestMCPServerURLDefinitionParam] | Omit = omit,
        metadata: BetaMetadataParam | Omit = omit,
        output_config: BetaOutputConfigParam | Omit = omit,
        service_tier: Literal["auto", "standard_only"] | Omit = omit,
        speed: Optional[Literal["standard", "fast"]] | Omit = omit,
        stop_sequences: SequenceNotStr[str] | Omit = omit,
        stream: Literal[False] | Omit = omit,
        system: Union[str, Iterable[BetaTextBlockParam]] | Omit = omit,
        thinking: BetaThinkingConfigParam | Omit = omit,
        thread: Optional[BetaMessageThreadParam] | Omit = omit,
        tool_choice: BetaToolChoiceParam | Omit = omit,
        tools: Iterable[BetaToolLike] | Omit = omit,
        betas: List[AnthropicBetaParam] | Omit = omit,
        user_profile_id: str | Omit = omit,
        workspace_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> BetaMessage:
        """
        Send a structured list of input messages with text and/or image content, and the
        model will generate the next message in the conversation.

        The Messages API can be used for either single queries or stateless multi-turn
        conversations.

        Learn more about the Messages API in our
        [user guide](https://platform.claude.com/docs/en/get-started)

        Args:
          max_tokens: The maximum number of tokens to generate before stopping.

              Note that our models may stop _before_ reaching this maximum. This parameter
              only specifies the absolute maximum number of tokens to generate.

              Set to `0` to populate the
              [prompt cache](https://platform.claude.com/docs/en/build-with-claude/prompt-caching#pre-warming-the-cache)
              without generating a response.

              Different models have different maximum values for this parameter. See
              [models](https://platform.claude.com/docs/en/about-claude/models/overview) for
              details.

          messages: Input messages.

              Our models are trained to operate on alternating `user` and `assistant`
              conversational turns. When creating a new `Message`, you specify the prior
              conversational turns with the `messages` parameter, and the model then generates
              the next `Message` in the conversation. Consecutive `user` or `assistant` turns
              in your request will be combined into a single turn.

              Each input message must be an object with a `role` and `content`. You can
              specify a single `user`-role message, or you can include multiple `user` and
              `assistant` messages.

              If the final message uses the `assistant` role, the response content will
              continue immediately from the content in that message. This can be used to
              constrain part of the model's response. This is called prefill. On models that
              don't support prefill, creating a message that ends with a partial `assistant`
              response returns a 400 error. See
              [Prefill not supported](https://platform.claude.com/docs/en/api/errors#prefill-not-supported).

              Example with a single `user` message:

              ```json
              [{ "role": "user", "content": "Hello, Claude" }]
              ```

              Example with multiple conversational turns:

              ```json
              [
                { "role": "user", "content": "Hello there." },
                { "role": "assistant", "content": "Hi, I'm Claude. How can I help you?" },
                { "role": "user", "content": "Can you explain LLMs in plain English?" }
              ]
              ```

              Example with a partially-filled response from Claude, for models that support
              prefill:

              ```json
              [
                {
                  "role": "user",
                  "content": "What's the Greek name for Sun? (A) Sol (B) Helios (C) Sun"
                },
                { "role": "assistant", "content": "The best answer is (" }
              ]
              ```

              Each input message `content` may be either a single `string` or an array of
              content blocks, where each block has a specific `type`. Using a `string` for
              `content` is shorthand for an array of one content block of type `"text"`. The
              following input messages are equivalent:

              ```json
              { "role": "user", "content": "Hello, Claude" }
              ```

              ```json
              { "role": "user", "content": [{ "type": "text", "text": "Hello, Claude" }] }
              ```

              See
              [input examples](https://platform.claude.com/docs/en/build-with-claude/working-with-messages).

              Note that if you want to include a
              [system prompt](https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/claude-prompting-best-practices#give-claude-a-role),
              you can use the top-level `system` parameter.

              There is a limit of 100,000 messages in a single request.

          model: The model that will complete your prompt.

              See [models](https://docs.anthropic.com/en/docs/models-overview) for additional
              details and options.

          cache_control: Top-level cache control automatically applies a cache_control marker to the last
              cacheable block in the request.

          compaction: Compaction configuration.

              When set on `POST /v1/messages`, the request is a compaction request: the
              conversation in `messages` is summarized and the response holds only the
              resulting `compaction` block (`stop_reason` `"compaction"`), which later
              requests send first in `messages` in place of the messages it summarizes.
              `POST /v1/messages/count_tokens` accepts this parameter and ignores it: the
              count it returns is for the conversation in `messages` as sent. Cannot be
              combined with `context_management`.

          container: Container identifier for reuse across requests.

          context_management: Context management configuration.

              This allows you to control how Claude manages context across multiple requests,
              such as whether to clear function results or not.

          diagnostics: Request-level diagnostics. Supply `previous_message_id` to have the response
              include `diagnostics.cache_miss_reason` explaining any prompt-cache divergence
              from that prior request.

          fallback_credit_token: The `fallback_credit_token` from a prior refusal's `stop_details`.

              When a preceding request was refused and returned a `fallback_credit_token`,
              pass that code here on the retry to have the retry's cache-creation tokens for
              the prefix that was warm on the refused model billed at the cache-read rate.
              Must be redeemed by the same organization and workspace, with the same request
              body (optionally extended by one appended `assistant` message whose content is
              the partial text — with any trailing whitespace stripped from the final text
              block — and paired server-tool blocks streamed before the refusal; the
              appended-assistant form is not available for requests with `output_format` set
              or forced `tool_choice`), on an eligible fallback model, on the same platform,
              and within 5 minutes of the refusal; a mismatch is a 400. A token minted
              mid-server-tool-loop whose partial content was continuable may only be redeemed
              with the appended-assistant form — if an exact-body retry is rejected with a 400
              saying the token must be redeemed by continuing the partial response, retry with
              the appended-assistant form instead.

              When the appended-assistant form is used on a model that otherwise disallows
              assistant-turn prefill, this token also authorizes that one prefill.

          fallbacks: Opt-in server-side retry on one or more substitute models when the requested
              model declines for policy reasons. Tried in order: if the first entry also
              declines, the second is tried, and so on. Some models don't support fallbacks;
              on those models, a list of fallback models returns a 400 error. See
              [Server-side fallback](https://platform.claude.com/docs/en/build-with-claude/refusals-and-fallback#server-side-fallback).
              The string "default" requests the requested model's server-defined default
              fallback configuration. On a model that doesn't support fallbacks, the request
              runs on the requested model alone, so a declined request stays declined.

          inference_geo: Specifies the geographic region for inference processing. If not specified, the
              workspace's `default_inference_geo` is used.

          mcp_servers: MCP servers to be utilized in this request

          metadata: An object describing metadata about the request.

          output_config: Configuration options for the model's output, such as the output format.

          service_tier: Determines whether to use priority capacity (if available) or standard capacity
              for this request.

              Anthropic offers different levels of service for your API requests. See
              [service-tiers](https://platform.claude.com/docs/en/api/service-tiers) for
              details.

          speed: The inference speed mode for this request. `"fast"` enables high
              output-tokens-per-second inference.

              Some models require the `fast-mode-2026-02-01` beta header for any `speed`
              value. See
              [fast mode](https://platform.claude.com/docs/en/build-with-claude/fast-mode) for
              which models.

          stop_sequences: Custom text sequences that will cause the model to stop generating.

              Our models will normally stop when they have naturally completed their turn,
              which will result in a response `stop_reason` of `"end_turn"`.

              If you want the model to stop generating when it encounters custom strings of
              text, you can use the `stop_sequences` parameter. If the model encounters one of
              the custom sequences, the response `stop_reason` value will be `"stop_sequence"`
              and the response `stop_sequence` value will contain the matched stop sequence.

          stream: Whether to incrementally stream the response using server-sent events. When
              `true`, SDKs return a raw event stream.

              In the TypeScript, Python and Ruby SDKs, the recommended way to stream is
              `messages.stream()`. It sets `stream` for you and accumulates the events into
              the final message. See
              [Streaming with SDKs](https://platform.claude.com/docs/en/build-with-claude/streaming#streaming-with-sdks)
              for an example in each language.

          system: System prompt.

              A system prompt is a way of providing context and instructions to Claude, such
              as specifying a particular goal or role. See our
              [guide to system prompts](https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/claude-prompting-best-practices#give-claude-a-role).

          thinking: Configuration for Claude's thinking.

              With `{"type": "adaptive"}`, Claude decides when and how much to think. With
              `{"type": "enabled"}` (manual extended thinking), you set a `budget_tokens` of
              at least 1,024. Thinking tokens count toward your `max_tokens` limit.

              Which `type` values are accepted, and what happens when you omit `thinking`,
              depend on the model. See
              [thinking](https://platform.claude.com/docs/en/build-with-claude/thinking#configuring-thinking)
              for each model's behavior.

          thread: Server-held conversation state (a Thread). `{"type": "create"}` asks the server
              to hold this conversation's state under the response's `id`;
              `{"type": "continue", "previous_message_id": ...}` resumes from a previous
              response so only the new turn's messages are sent. The response shape is
              unchanged.

          tool_choice: How the model should use the provided tools. The model can use a specific tool,
              any available tool, decide by itself, or not use tools at all.

          tools: Definitions of tools that the model may use.

              If you include `tools` in your API request, the model may return `tool_use`
              content blocks that represent the model's use of those tools. You can then run
              those tools using the tool input generated by the model and then optionally
              return results back to the model using `tool_result` content blocks.

              There are two types of tools: **client tools** and **server tools**. The
              behavior described below applies to client tools. For
              [server tools](https://platform.claude.com/docs/en/agents-and-tools/tool-use/server-tools),
              see their individual documentation as each has its own behavior (e.g., the
              [web search tool](https://platform.claude.com/docs/en/agents-and-tools/tool-use/web-search-tool)).

              Each tool definition includes:

              - `name`: Name of the tool.
              - `description`: Optional, but strongly-recommended description of the tool.
              - `input_schema`: [JSON schema](https://json-schema.org/draft/2020-12) for the
                tool `input` shape that the model will produce in `tool_use` output content
                blocks.

              For example, if you defined `tools` as:

              ```json
              [
                {
                  "name": "get_stock_price",
                  "description": "Get the current stock price for a given ticker symbol.",
                  "input_schema": {
                    "type": "object",
                    "properties": {
                      "ticker": {
                        "type": "string",
                        "description": "The stock ticker symbol, e.g. AAPL for Apple Inc."
                      }
                    },
                    "required": ["ticker"]
                  }
                }
              ]
              ```

              And then asked the model "What's the S&P 500 at today?", the model might produce
              `tool_use` content blocks in the response like this:

              ```json
              [
                {
                  "type": "tool_use",
                  "id": "toolu_01D7FLrfh4GYq7yT1ULFeyMV",
                  "name": "get_stock_price",
                  "input": { "ticker": "^GSPC" }
                }
              ]
              ```

              You might then run your `get_stock_price` tool with `{"ticker": "^GSPC"}` as an
              input, and return the following back to the model in a subsequent `user`
              message:

              ```json
              [
                {
                  "type": "tool_result",
                  "tool_use_id": "toolu_01D7FLrfh4GYq7yT1ULFeyMV",
                  "content": "259.75 USD"
                }
              ]
              ```

              Tools can be used for workflows that include running client-side tools and
              functions, or more generally whenever you want the model to produce a particular
              JSON structure of output.

              See our
              [guide](https://platform.claude.com/docs/en/agents-and-tools/tool-use/overview)
              for more details.

          betas: Optional header to specify the beta version(s) you want to use.

          user_profile_id: The user profile ID to attribute this request to. Use when acting on behalf of a
              party other than your organization.

          workspace_id: Optional header to select the Workspace for this request. The value is a
              Workspace ID (for example, `wrkspc_011CZkZaBF1tNoB5wlCeusgy`).

              Only needed for credentials that can act on more than one Workspace. A
              credential that belongs to a specific Workspace may omit it; if sent, it must
              match that Workspace.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds

        Raises:
          AvailableToolsLimitExceededError:

          ClaudeCodeKeyCreatorNotMemberError:

          ClaudeCodeVersionTooOldError:

          CMEKKeyDisabledError:

          CMEKKeyNetworkBlockedError:

          CompactionBlockAmbiguousError:

          CompactionBlockMisplacedError:

          CompactionContentMismatchError:

          CompactionIncompleteTurnError:

          CompactionNothingToSummarizeError:

          CompactionSignatureInvalidError:

          CompactionTooManyToolReferencesError:

          CompactionToolChangesMismatchError:

          OrganizationOnHoldError:

          RequestBodyEncodingInvalidError:

          RequestBodyEncodingUnsupportedError:

          ThreadAlreadyContinuedError:

          ThreadContinueInFlightError:

          ThreadFingerprintMismatchError:

          ThreadUnsupportedRequestError:

          ToolNameConflictError:

          ToolReferenceUnresolvedError:

          ThreadNotFoundError:

          SkillReadBlockedUndecryptableError:

          RequestBodyTooLargeAfterDecodingError:

          EnforcedSpendLimitReachedError:

          RampLimitExceededError:

          CMEKKeyUnreachableError:

          CompactionUnavailableError:
        """
        ...

    @overload
    async def create(
        self,
        *,
        max_tokens: int,
        messages: Iterable[BetaMessageParam],
        model: ModelParam,
        stream: Literal[True],
        cache_control: Optional[BetaCacheControlEphemeralParam] | Omit = omit,
        compaction: Optional[BetaCompactionConfigParam] | Omit = omit,
        container: Optional[message_create_params.Container] | Omit = omit,
        context_management: Optional[BetaContextManagementConfigParam] | Omit = omit,
        diagnostics: Optional[BetaDiagnosticsParam] | Omit = omit,
        fallback_credit_token: Optional[message_create_params.FallbackCreditToken] | Omit = omit,
        fallbacks: Optional[BetaFallbacksParam] | Omit = omit,
        inference_geo: Optional[str] | Omit = omit,
        mcp_servers: Iterable[BetaRequestMCPServerURLDefinitionParam] | Omit = omit,
        metadata: BetaMetadataParam | Omit = omit,
        output_config: BetaOutputConfigParam | Omit = omit,
        service_tier: Literal["auto", "standard_only"] | Omit = omit,
        speed: Optional[Literal["standard", "fast"]] | Omit = omit,
        stop_sequences: SequenceNotStr[str] | Omit = omit,
        system: Union[str, Iterable[BetaTextBlockParam]] | Omit = omit,
        thinking: BetaThinkingConfigParam | Omit = omit,
        thread: Optional[BetaMessageThreadParam] | Omit = omit,
        tool_choice: BetaToolChoiceParam | Omit = omit,
        tools: Iterable[BetaToolLike] | Omit = omit,
        betas: List[AnthropicBetaParam] | Omit = omit,
        user_profile_id: str | Omit = omit,
        workspace_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> AsyncStream[BetaRawMessageStreamEvent]:
        """
        Send a structured list of input messages with text and/or image content, and the
        model will generate the next message in the conversation.

        The Messages API can be used for either single queries or stateless multi-turn
        conversations.

        Learn more about the Messages API in our
        [user guide](https://platform.claude.com/docs/en/get-started)

        Args:
          max_tokens: The maximum number of tokens to generate before stopping.

              Note that our models may stop _before_ reaching this maximum. This parameter
              only specifies the absolute maximum number of tokens to generate.

              Set to `0` to populate the
              [prompt cache](https://platform.claude.com/docs/en/build-with-claude/prompt-caching#pre-warming-the-cache)
              without generating a response.

              Different models have different maximum values for this parameter. See
              [models](https://platform.claude.com/docs/en/about-claude/models/overview) for
              details.

          messages: Input messages.

              Our models are trained to operate on alternating `user` and `assistant`
              conversational turns. When creating a new `Message`, you specify the prior
              conversational turns with the `messages` parameter, and the model then generates
              the next `Message` in the conversation. Consecutive `user` or `assistant` turns
              in your request will be combined into a single turn.

              Each input message must be an object with a `role` and `content`. You can
              specify a single `user`-role message, or you can include multiple `user` and
              `assistant` messages.

              If the final message uses the `assistant` role, the response content will
              continue immediately from the content in that message. This can be used to
              constrain part of the model's response. This is called prefill. On models that
              don't support prefill, creating a message that ends with a partial `assistant`
              response returns a 400 error. See
              [Prefill not supported](https://platform.claude.com/docs/en/api/errors#prefill-not-supported).

              Example with a single `user` message:

              ```json
              [{ "role": "user", "content": "Hello, Claude" }]
              ```

              Example with multiple conversational turns:

              ```json
              [
                { "role": "user", "content": "Hello there." },
                { "role": "assistant", "content": "Hi, I'm Claude. How can I help you?" },
                { "role": "user", "content": "Can you explain LLMs in plain English?" }
              ]
              ```

              Example with a partially-filled response from Claude, for models that support
              prefill:

              ```json
              [
                {
                  "role": "user",
                  "content": "What's the Greek name for Sun? (A) Sol (B) Helios (C) Sun"
                },
                { "role": "assistant", "content": "The best answer is (" }
              ]
              ```

              Each input message `content` may be either a single `string` or an array of
              content blocks, where each block has a specific `type`. Using a `string` for
              `content` is shorthand for an array of one content block of type `"text"`. The
              following input messages are equivalent:

              ```json
              { "role": "user", "content": "Hello, Claude" }
              ```

              ```json
              { "role": "user", "content": [{ "type": "text", "text": "Hello, Claude" }] }
              ```

              See
              [input examples](https://platform.claude.com/docs/en/build-with-claude/working-with-messages).

              Note that if you want to include a
              [system prompt](https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/claude-prompting-best-practices#give-claude-a-role),
              you can use the top-level `system` parameter.

              There is a limit of 100,000 messages in a single request.

          model: The model that will complete your prompt.

              See [models](https://docs.anthropic.com/en/docs/models-overview) for additional
              details and options.

          stream: Whether to incrementally stream the response using server-sent events. When
              `true`, SDKs return a raw event stream.

              In the TypeScript, Python and Ruby SDKs, the recommended way to stream is
              `messages.stream()`. It sets `stream` for you and accumulates the events into
              the final message. See
              [Streaming with SDKs](https://platform.claude.com/docs/en/build-with-claude/streaming#streaming-with-sdks)
              for an example in each language.

          cache_control: Top-level cache control automatically applies a cache_control marker to the last
              cacheable block in the request.

          compaction: Compaction configuration.

              When set on `POST /v1/messages`, the request is a compaction request: the
              conversation in `messages` is summarized and the response holds only the
              resulting `compaction` block (`stop_reason` `"compaction"`), which later
              requests send first in `messages` in place of the messages it summarizes.
              `POST /v1/messages/count_tokens` accepts this parameter and ignores it: the
              count it returns is for the conversation in `messages` as sent. Cannot be
              combined with `context_management`.

          container: Container identifier for reuse across requests.

          context_management: Context management configuration.

              This allows you to control how Claude manages context across multiple requests,
              such as whether to clear function results or not.

          diagnostics: Request-level diagnostics. Supply `previous_message_id` to have the response
              include `diagnostics.cache_miss_reason` explaining any prompt-cache divergence
              from that prior request.

          fallback_credit_token: The `fallback_credit_token` from a prior refusal's `stop_details`.

              When a preceding request was refused and returned a `fallback_credit_token`,
              pass that code here on the retry to have the retry's cache-creation tokens for
              the prefix that was warm on the refused model billed at the cache-read rate.
              Must be redeemed by the same organization and workspace, with the same request
              body (optionally extended by one appended `assistant` message whose content is
              the partial text — with any trailing whitespace stripped from the final text
              block — and paired server-tool blocks streamed before the refusal; the
              appended-assistant form is not available for requests with `output_format` set
              or forced `tool_choice`), on an eligible fallback model, on the same platform,
              and within 5 minutes of the refusal; a mismatch is a 400. A token minted
              mid-server-tool-loop whose partial content was continuable may only be redeemed
              with the appended-assistant form — if an exact-body retry is rejected with a 400
              saying the token must be redeemed by continuing the partial response, retry with
              the appended-assistant form instead.

              When the appended-assistant form is used on a model that otherwise disallows
              assistant-turn prefill, this token also authorizes that one prefill.

          fallbacks: Opt-in server-side retry on one or more substitute models when the requested
              model declines for policy reasons. Tried in order: if the first entry also
              declines, the second is tried, and so on. Some models don't support fallbacks;
              on those models, a list of fallback models returns a 400 error. See
              [Server-side fallback](https://platform.claude.com/docs/en/build-with-claude/refusals-and-fallback#server-side-fallback).
              The string "default" requests the requested model's server-defined default
              fallback configuration. On a model that doesn't support fallbacks, the request
              runs on the requested model alone, so a declined request stays declined.

          inference_geo: Specifies the geographic region for inference processing. If not specified, the
              workspace's `default_inference_geo` is used.

          mcp_servers: MCP servers to be utilized in this request

          metadata: An object describing metadata about the request.

          output_config: Configuration options for the model's output, such as the output format.

          service_tier: Determines whether to use priority capacity (if available) or standard capacity
              for this request.

              Anthropic offers different levels of service for your API requests. See
              [service-tiers](https://platform.claude.com/docs/en/api/service-tiers) for
              details.

          speed: The inference speed mode for this request. `"fast"` enables high
              output-tokens-per-second inference.

              Some models require the `fast-mode-2026-02-01` beta header for any `speed`
              value. See
              [fast mode](https://platform.claude.com/docs/en/build-with-claude/fast-mode) for
              which models.

          stop_sequences: Custom text sequences that will cause the model to stop generating.

              Our models will normally stop when they have naturally completed their turn,
              which will result in a response `stop_reason` of `"end_turn"`.

              If you want the model to stop generating when it encounters custom strings of
              text, you can use the `stop_sequences` parameter. If the model encounters one of
              the custom sequences, the response `stop_reason` value will be `"stop_sequence"`
              and the response `stop_sequence` value will contain the matched stop sequence.

          system: System prompt.

              A system prompt is a way of providing context and instructions to Claude, such
              as specifying a particular goal or role. See our
              [guide to system prompts](https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/claude-prompting-best-practices#give-claude-a-role).

          thinking: Configuration for Claude's thinking.

              With `{"type": "adaptive"}`, Claude decides when and how much to think. With
              `{"type": "enabled"}` (manual extended thinking), you set a `budget_tokens` of
              at least 1,024. Thinking tokens count toward your `max_tokens` limit.

              Which `type` values are accepted, and what happens when you omit `thinking`,
              depend on the model. See
              [thinking](https://platform.claude.com/docs/en/build-with-claude/thinking#configuring-thinking)
              for each model's behavior.

          thread: Server-held conversation state (a Thread). `{"type": "create"}` asks the server
              to hold this conversation's state under the response's `id`;
              `{"type": "continue", "previous_message_id": ...}` resumes from a previous
              response so only the new turn's messages are sent. The response shape is
              unchanged.

          tool_choice: How the model should use the provided tools. The model can use a specific tool,
              any available tool, decide by itself, or not use tools at all.

          tools: Definitions of tools that the model may use.

              If you include `tools` in your API request, the model may return `tool_use`
              content blocks that represent the model's use of those tools. You can then run
              those tools using the tool input generated by the model and then optionally
              return results back to the model using `tool_result` content blocks.

              There are two types of tools: **client tools** and **server tools**. The
              behavior described below applies to client tools. For
              [server tools](https://platform.claude.com/docs/en/agents-and-tools/tool-use/server-tools),
              see their individual documentation as each has its own behavior (e.g., the
              [web search tool](https://platform.claude.com/docs/en/agents-and-tools/tool-use/web-search-tool)).

              Each tool definition includes:

              - `name`: Name of the tool.
              - `description`: Optional, but strongly-recommended description of the tool.
              - `input_schema`: [JSON schema](https://json-schema.org/draft/2020-12) for the
                tool `input` shape that the model will produce in `tool_use` output content
                blocks.

              For example, if you defined `tools` as:

              ```json
              [
                {
                  "name": "get_stock_price",
                  "description": "Get the current stock price for a given ticker symbol.",
                  "input_schema": {
                    "type": "object",
                    "properties": {
                      "ticker": {
                        "type": "string",
                        "description": "The stock ticker symbol, e.g. AAPL for Apple Inc."
                      }
                    },
                    "required": ["ticker"]
                  }
                }
              ]
              ```

              And then asked the model "What's the S&P 500 at today?", the model might produce
              `tool_use` content blocks in the response like this:

              ```json
              [
                {
                  "type": "tool_use",
                  "id": "toolu_01D7FLrfh4GYq7yT1ULFeyMV",
                  "name": "get_stock_price",
                  "input": { "ticker": "^GSPC" }
                }
              ]
              ```

              You might then run your `get_stock_price` tool with `{"ticker": "^GSPC"}` as an
              input, and return the following back to the model in a subsequent `user`
              message:

              ```json
              [
                {
                  "type": "tool_result",
                  "tool_use_id": "toolu_01D7FLrfh4GYq7yT1ULFeyMV",
                  "content": "259.75 USD"
                }
              ]
              ```

              Tools can be used for workflows that include running client-side tools and
              functions, or more generally whenever you want the model to produce a particular
              JSON structure of output.

              See our
              [guide](https://platform.claude.com/docs/en/agents-and-tools/tool-use/overview)
              for more details.

          betas: Optional header to specify the beta version(s) you want to use.

          user_profile_id: The user profile ID to attribute this request to. Use when acting on behalf of a
              party other than your organization.

          workspace_id: Optional header to select the Workspace for this request. The value is a
              Workspace ID (for example, `wrkspc_011CZkZaBF1tNoB5wlCeusgy`).

              Only needed for credentials that can act on more than one Workspace. A
              credential that belongs to a specific Workspace may omit it; if sent, it must
              match that Workspace.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds

        Raises:
          AvailableToolsLimitExceededError:

          ClaudeCodeKeyCreatorNotMemberError:

          ClaudeCodeVersionTooOldError:

          CMEKKeyDisabledError:

          CMEKKeyNetworkBlockedError:

          CompactionBlockAmbiguousError:

          CompactionBlockMisplacedError:

          CompactionContentMismatchError:

          CompactionIncompleteTurnError:

          CompactionNothingToSummarizeError:

          CompactionSignatureInvalidError:

          CompactionTooManyToolReferencesError:

          CompactionToolChangesMismatchError:

          OrganizationOnHoldError:

          RequestBodyEncodingInvalidError:

          RequestBodyEncodingUnsupportedError:

          ThreadAlreadyContinuedError:

          ThreadContinueInFlightError:

          ThreadFingerprintMismatchError:

          ThreadUnsupportedRequestError:

          ToolNameConflictError:

          ToolReferenceUnresolvedError:

          ThreadNotFoundError:

          SkillReadBlockedUndecryptableError:

          RequestBodyTooLargeAfterDecodingError:

          EnforcedSpendLimitReachedError:

          RampLimitExceededError:

          CMEKKeyUnreachableError:

          CompactionUnavailableError:
        """
        ...

    @overload
    async def create(
        self,
        *,
        max_tokens: int,
        messages: Iterable[BetaMessageParam],
        model: ModelParam,
        stream: bool,
        cache_control: Optional[BetaCacheControlEphemeralParam] | Omit = omit,
        compaction: Optional[BetaCompactionConfigParam] | Omit = omit,
        container: Optional[message_create_params.Container] | Omit = omit,
        context_management: Optional[BetaContextManagementConfigParam] | Omit = omit,
        diagnostics: Optional[BetaDiagnosticsParam] | Omit = omit,
        fallback_credit_token: Optional[message_create_params.FallbackCreditToken] | Omit = omit,
        fallbacks: Optional[BetaFallbacksParam] | Omit = omit,
        inference_geo: Optional[str] | Omit = omit,
        mcp_servers: Iterable[BetaRequestMCPServerURLDefinitionParam] | Omit = omit,
        metadata: BetaMetadataParam | Omit = omit,
        output_config: BetaOutputConfigParam | Omit = omit,
        service_tier: Literal["auto", "standard_only"] | Omit = omit,
        speed: Optional[Literal["standard", "fast"]] | Omit = omit,
        stop_sequences: SequenceNotStr[str] | Omit = omit,
        system: Union[str, Iterable[BetaTextBlockParam]] | Omit = omit,
        thinking: BetaThinkingConfigParam | Omit = omit,
        thread: Optional[BetaMessageThreadParam] | Omit = omit,
        tool_choice: BetaToolChoiceParam | Omit = omit,
        tools: Iterable[BetaToolLike] | Omit = omit,
        betas: List[AnthropicBetaParam] | Omit = omit,
        user_profile_id: str | Omit = omit,
        workspace_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> BetaMessage | AsyncStream[BetaRawMessageStreamEvent]:
        """
        Send a structured list of input messages with text and/or image content, and the
        model will generate the next message in the conversation.

        The Messages API can be used for either single queries or stateless multi-turn
        conversations.

        Learn more about the Messages API in our
        [user guide](https://platform.claude.com/docs/en/get-started)

        Args:
          max_tokens: The maximum number of tokens to generate before stopping.

              Note that our models may stop _before_ reaching this maximum. This parameter
              only specifies the absolute maximum number of tokens to generate.

              Set to `0` to populate the
              [prompt cache](https://platform.claude.com/docs/en/build-with-claude/prompt-caching#pre-warming-the-cache)
              without generating a response.

              Different models have different maximum values for this parameter. See
              [models](https://platform.claude.com/docs/en/about-claude/models/overview) for
              details.

          messages: Input messages.

              Our models are trained to operate on alternating `user` and `assistant`
              conversational turns. When creating a new `Message`, you specify the prior
              conversational turns with the `messages` parameter, and the model then generates
              the next `Message` in the conversation. Consecutive `user` or `assistant` turns
              in your request will be combined into a single turn.

              Each input message must be an object with a `role` and `content`. You can
              specify a single `user`-role message, or you can include multiple `user` and
              `assistant` messages.

              If the final message uses the `assistant` role, the response content will
              continue immediately from the content in that message. This can be used to
              constrain part of the model's response. This is called prefill. On models that
              don't support prefill, creating a message that ends with a partial `assistant`
              response returns a 400 error. See
              [Prefill not supported](https://platform.claude.com/docs/en/api/errors#prefill-not-supported).

              Example with a single `user` message:

              ```json
              [{ "role": "user", "content": "Hello, Claude" }]
              ```

              Example with multiple conversational turns:

              ```json
              [
                { "role": "user", "content": "Hello there." },
                { "role": "assistant", "content": "Hi, I'm Claude. How can I help you?" },
                { "role": "user", "content": "Can you explain LLMs in plain English?" }
              ]
              ```

              Example with a partially-filled response from Claude, for models that support
              prefill:

              ```json
              [
                {
                  "role": "user",
                  "content": "What's the Greek name for Sun? (A) Sol (B) Helios (C) Sun"
                },
                { "role": "assistant", "content": "The best answer is (" }
              ]
              ```

              Each input message `content` may be either a single `string` or an array of
              content blocks, where each block has a specific `type`. Using a `string` for
              `content` is shorthand for an array of one content block of type `"text"`. The
              following input messages are equivalent:

              ```json
              { "role": "user", "content": "Hello, Claude" }
              ```

              ```json
              { "role": "user", "content": [{ "type": "text", "text": "Hello, Claude" }] }
              ```

              See
              [input examples](https://platform.claude.com/docs/en/build-with-claude/working-with-messages).

              Note that if you want to include a
              [system prompt](https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/claude-prompting-best-practices#give-claude-a-role),
              you can use the top-level `system` parameter.

              There is a limit of 100,000 messages in a single request.

          model: The model that will complete your prompt.

              See [models](https://docs.anthropic.com/en/docs/models-overview) for additional
              details and options.

          stream: Whether to incrementally stream the response using server-sent events. When
              `true`, SDKs return a raw event stream.

              In the TypeScript, Python and Ruby SDKs, the recommended way to stream is
              `messages.stream()`. It sets `stream` for you and accumulates the events into
              the final message. See
              [Streaming with SDKs](https://platform.claude.com/docs/en/build-with-claude/streaming#streaming-with-sdks)
              for an example in each language.

          cache_control: Top-level cache control automatically applies a cache_control marker to the last
              cacheable block in the request.

          compaction: Compaction configuration.

              When set on `POST /v1/messages`, the request is a compaction request: the
              conversation in `messages` is summarized and the response holds only the
              resulting `compaction` block (`stop_reason` `"compaction"`), which later
              requests send first in `messages` in place of the messages it summarizes.
              `POST /v1/messages/count_tokens` accepts this parameter and ignores it: the
              count it returns is for the conversation in `messages` as sent. Cannot be
              combined with `context_management`.

          container: Container identifier for reuse across requests.

          context_management: Context management configuration.

              This allows you to control how Claude manages context across multiple requests,
              such as whether to clear function results or not.

          diagnostics: Request-level diagnostics. Supply `previous_message_id` to have the response
              include `diagnostics.cache_miss_reason` explaining any prompt-cache divergence
              from that prior request.

          fallback_credit_token: The `fallback_credit_token` from a prior refusal's `stop_details`.

              When a preceding request was refused and returned a `fallback_credit_token`,
              pass that code here on the retry to have the retry's cache-creation tokens for
              the prefix that was warm on the refused model billed at the cache-read rate.
              Must be redeemed by the same organization and workspace, with the same request
              body (optionally extended by one appended `assistant` message whose content is
              the partial text — with any trailing whitespace stripped from the final text
              block — and paired server-tool blocks streamed before the refusal; the
              appended-assistant form is not available for requests with `output_format` set
              or forced `tool_choice`), on an eligible fallback model, on the same platform,
              and within 5 minutes of the refusal; a mismatch is a 400. A token minted
              mid-server-tool-loop whose partial content was continuable may only be redeemed
              with the appended-assistant form — if an exact-body retry is rejected with a 400
              saying the token must be redeemed by continuing the partial response, retry with
              the appended-assistant form instead.

              When the appended-assistant form is used on a model that otherwise disallows
              assistant-turn prefill, this token also authorizes that one prefill.

          fallbacks: Opt-in server-side retry on one or more substitute models when the requested
              model declines for policy reasons. Tried in order: if the first entry also
              declines, the second is tried, and so on. Some models don't support fallbacks;
              on those models, a list of fallback models returns a 400 error. See
              [Server-side fallback](https://platform.claude.com/docs/en/build-with-claude/refusals-and-fallback#server-side-fallback).
              The string "default" requests the requested model's server-defined default
              fallback configuration. On a model that doesn't support fallbacks, the request
              runs on the requested model alone, so a declined request stays declined.

          inference_geo: Specifies the geographic region for inference processing. If not specified, the
              workspace's `default_inference_geo` is used.

          mcp_servers: MCP servers to be utilized in this request

          metadata: An object describing metadata about the request.

          output_config: Configuration options for the model's output, such as the output format.

          service_tier: Determines whether to use priority capacity (if available) or standard capacity
              for this request.

              Anthropic offers different levels of service for your API requests. See
              [service-tiers](https://platform.claude.com/docs/en/api/service-tiers) for
              details.

          speed: The inference speed mode for this request. `"fast"` enables high
              output-tokens-per-second inference.

              Some models require the `fast-mode-2026-02-01` beta header for any `speed`
              value. See
              [fast mode](https://platform.claude.com/docs/en/build-with-claude/fast-mode) for
              which models.

          stop_sequences: Custom text sequences that will cause the model to stop generating.

              Our models will normally stop when they have naturally completed their turn,
              which will result in a response `stop_reason` of `"end_turn"`.

              If you want the model to stop generating when it encounters custom strings of
              text, you can use the `stop_sequences` parameter. If the model encounters one of
              the custom sequences, the response `stop_reason` value will be `"stop_sequence"`
              and the response `stop_sequence` value will contain the matched stop sequence.

          system: System prompt.

              A system prompt is a way of providing context and instructions to Claude, such
              as specifying a particular goal or role. See our
              [guide to system prompts](https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/claude-prompting-best-practices#give-claude-a-role).

          thinking: Configuration for Claude's thinking.

              With `{"type": "adaptive"}`, Claude decides when and how much to think. With
              `{"type": "enabled"}` (manual extended thinking), you set a `budget_tokens` of
              at least 1,024. Thinking tokens count toward your `max_tokens` limit.

              Which `type` values are accepted, and what happens when you omit `thinking`,
              depend on the model. See
              [thinking](https://platform.claude.com/docs/en/build-with-claude/thinking#configuring-thinking)
              for each model's behavior.

          thread: Server-held conversation state (a Thread). `{"type": "create"}` asks the server
              to hold this conversation's state under the response's `id`;
              `{"type": "continue", "previous_message_id": ...}` resumes from a previous
              response so only the new turn's messages are sent. The response shape is
              unchanged.

          tool_choice: How the model should use the provided tools. The model can use a specific tool,
              any available tool, decide by itself, or not use tools at all.

          tools: Definitions of tools that the model may use.

              If you include `tools` in your API request, the model may return `tool_use`
              content blocks that represent the model's use of those tools. You can then run
              those tools using the tool input generated by the model and then optionally
              return results back to the model using `tool_result` content blocks.

              There are two types of tools: **client tools** and **server tools**. The
              behavior described below applies to client tools. For
              [server tools](https://platform.claude.com/docs/en/agents-and-tools/tool-use/server-tools),
              see their individual documentation as each has its own behavior (e.g., the
              [web search tool](https://platform.claude.com/docs/en/agents-and-tools/tool-use/web-search-tool)).

              Each tool definition includes:

              - `name`: Name of the tool.
              - `description`: Optional, but strongly-recommended description of the tool.
              - `input_schema`: [JSON schema](https://json-schema.org/draft/2020-12) for the
                tool `input` shape that the model will produce in `tool_use` output content
                blocks.

              For example, if you defined `tools` as:

              ```json
              [
                {
                  "name": "get_stock_price",
                  "description": "Get the current stock price for a given ticker symbol.",
                  "input_schema": {
                    "type": "object",
                    "properties": {
                      "ticker": {
                        "type": "string",
                        "description": "The stock ticker symbol, e.g. AAPL for Apple Inc."
                      }
                    },
                    "required": ["ticker"]
                  }
                }
              ]
              ```

              And then asked the model "What's the S&P 500 at today?", the model might produce
              `tool_use` content blocks in the response like this:

              ```json
              [
                {
                  "type": "tool_use",
                  "id": "toolu_01D7FLrfh4GYq7yT1ULFeyMV",
                  "name": "get_stock_price",
                  "input": { "ticker": "^GSPC" }
                }
              ]
              ```

              You might then run your `get_stock_price` tool with `{"ticker": "^GSPC"}` as an
              input, and return the following back to the model in a subsequent `user`
              message:

              ```json
              [
                {
                  "type": "tool_result",
                  "tool_use_id": "toolu_01D7FLrfh4GYq7yT1ULFeyMV",
                  "content": "259.75 USD"
                }
              ]
              ```

              Tools can be used for workflows that include running client-side tools and
              functions, or more generally whenever you want the model to produce a particular
              JSON structure of output.

              See our
              [guide](https://platform.claude.com/docs/en/agents-and-tools/tool-use/overview)
              for more details.

          betas: Optional header to specify the beta version(s) you want to use.

          user_profile_id: The user profile ID to attribute this request to. Use when acting on behalf of a
              party other than your organization.

          workspace_id: Optional header to select the Workspace for this request. The value is a
              Workspace ID (for example, `wrkspc_011CZkZaBF1tNoB5wlCeusgy`).

              Only needed for credentials that can act on more than one Workspace. A
              credential that belongs to a specific Workspace may omit it; if sent, it must
              match that Workspace.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds

        Raises:
          AvailableToolsLimitExceededError:

          ClaudeCodeKeyCreatorNotMemberError:

          ClaudeCodeVersionTooOldError:

          CMEKKeyDisabledError:

          CMEKKeyNetworkBlockedError:

          CompactionBlockAmbiguousError:

          CompactionBlockMisplacedError:

          CompactionContentMismatchError:

          CompactionIncompleteTurnError:

          CompactionNothingToSummarizeError:

          CompactionSignatureInvalidError:

          CompactionTooManyToolReferencesError:

          CompactionToolChangesMismatchError:

          OrganizationOnHoldError:

          RequestBodyEncodingInvalidError:

          RequestBodyEncodingUnsupportedError:

          ThreadAlreadyContinuedError:

          ThreadContinueInFlightError:

          ThreadFingerprintMismatchError:

          ThreadUnsupportedRequestError:

          ToolNameConflictError:

          ToolReferenceUnresolvedError:

          ThreadNotFoundError:

          SkillReadBlockedUndecryptableError:

          RequestBodyTooLargeAfterDecodingError:

          EnforcedSpendLimitReachedError:

          RampLimitExceededError:

          CMEKKeyUnreachableError:

          CompactionUnavailableError:
        """
        ...

    @required_args(["max_tokens", "messages", "model"], ["max_tokens", "messages", "model", "stream"])
    async def create(
        self,
        *,
        max_tokens: int,
        messages: Iterable[BetaMessageParam],
        model: ModelParam,
        cache_control: Optional[BetaCacheControlEphemeralParam] | Omit = omit,
        compaction: Optional[BetaCompactionConfigParam] | Omit = omit,
        container: Optional[message_create_params.Container] | Omit = omit,
        context_management: Optional[BetaContextManagementConfigParam] | Omit = omit,
        diagnostics: Optional[BetaDiagnosticsParam] | Omit = omit,
        fallback_credit_token: Optional[message_create_params.FallbackCreditToken] | Omit = omit,
        fallbacks: Optional[BetaFallbacksParam] | Omit = omit,
        inference_geo: Optional[str] | Omit = omit,
        mcp_servers: Iterable[BetaRequestMCPServerURLDefinitionParam] | Omit = omit,
        metadata: BetaMetadataParam | Omit = omit,
        output_config: BetaOutputConfigParam | Omit = omit,
        service_tier: Literal["auto", "standard_only"] | Omit = omit,
        speed: Optional[Literal["standard", "fast"]] | Omit = omit,
        stop_sequences: SequenceNotStr[str] | Omit = omit,
        stream: Literal[False] | Literal[True] | Omit = omit,
        system: Union[str, Iterable[BetaTextBlockParam]] | Omit = omit,
        thinking: BetaThinkingConfigParam | Omit = omit,
        thread: Optional[BetaMessageThreadParam] | Omit = omit,
        tool_choice: BetaToolChoiceParam | Omit = omit,
        tools: Iterable[BetaToolLike] | Omit = omit,
        betas: List[AnthropicBetaParam] | Omit = omit,
        user_profile_id: str | Omit = omit,
        workspace_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> BetaMessage | AsyncStream[BetaRawMessageStreamEvent]:
        if not stream and not is_given(timeout) and self._client.timeout == DEFAULT_TIMEOUT:
            timeout = self._client._calculate_nonstreaming_timeout(
                max_tokens, MODEL_NONSTREAMING_TOKENS.get(model, None)
            )

        if model in DEPRECATED_MODELS:
            warnings.warn(
                f"The model '{model}' is deprecated and will reach end-of-life on {DEPRECATED_MODELS[model]}.\nPlease migrate to a newer model. Visit https://docs.anthropic.com/en/docs/resources/model-deprecations for more information.",
                DeprecationWarning,
                stacklevel=3,
            )

        if model in MODELS_TO_WARN_WITH_THINKING_ENABLED and thinking and thinking["type"] == "enabled":
            warnings.warn(
                f"Using Claude with {model} and 'thinking.type=enabled' is deprecated. Use 'thinking.type=adaptive' instead which results in better model performance in our testing: https://platform.claude.com/docs/en/build-with-claude/adaptive-thinking",
                UserWarning,
                stacklevel=3,
            )

        tools = _to_tool_params(tools)
        extra_headers = merge_headers(
            strip_not_given(
                {
                    "anthropic-beta": ",".join(str(e) for e in betas) if is_given(betas) else not_given,
                    "anthropic-user-profile-id": user_profile_id,
                    "anthropic-workspace-id": workspace_id,
                }
            ),
            _stainless_helper_header(tools, messages),
            extra_headers or {},
        )
        return await self._post(
            "/v1/messages",
            body={
                "max_tokens": max_tokens,
                "messages": messages,
                "model": model,
                "cache_control": cache_control,
                "compaction": compaction,
                "container": container,
                "context_management": context_management,
                "diagnostics": diagnostics,
                "fallback_credit_token": fallback_credit_token,
                "fallbacks": fallbacks,
                "inference_geo": inference_geo,
                "mcp_servers": mcp_servers,
                "metadata": metadata,
                "output_config": output_config,
                "service_tier": service_tier,
                "speed": speed,
                "stop_sequences": stop_sequences,
                "stream": stream,
                "system": system,
                "thinking": thinking,
                "thread": thread,
                "tool_choice": tool_choice,
                "tools": tools,
            },
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                qualifiers={"beta": "true"},
                span_name="anthropic.messages.create",
                span_route="/v1/messages",
                span_attributes=messages_create_request_attributes,
            ),
            cast_to=BetaMessage,
            stream=stream or False,
            stream_cls=AsyncStream[BetaRawMessageStreamEvent],
        )

    async def parse(
        self,
        *,
        max_tokens: int,
        messages: Iterable[BetaMessageParam],
        model: ModelParam,
        cache_control: Optional[BetaCacheControlEphemeralParam] | Omit = omit,
        compaction: Optional[BetaCompactionConfigParam] | Omit = omit,
        container: Optional[message_create_params.Container] | Omit = omit,
        context_management: Optional[BetaContextManagementConfigParam] | Omit = omit,
        diagnostics: Optional[BetaDiagnosticsParam] | Omit = omit,
        fallback_credit_token: Optional[message_create_params.FallbackCreditToken] | Omit = omit,
        fallbacks: Optional[BetaFallbacksParam] | Omit = omit,
        inference_geo: Optional[str] | Omit = omit,
        mcp_servers: Iterable[BetaRequestMCPServerURLDefinitionParam] | Omit = omit,
        metadata: BetaMetadataParam | Omit = omit,
        output_config: BetaOutputConfigParam | Omit = omit,
        output_format: Optional[type[ResponseFormatT]] | Omit = omit,
        service_tier: Literal["auto", "standard_only"] | Omit = omit,
        speed: Optional[Literal["standard", "fast"]] | Omit = omit,
        stop_sequences: SequenceNotStr[str] | Omit = omit,
        system: Union[str, Iterable[BetaTextBlockParam]] | Omit = omit,
        thinking: BetaThinkingConfigParam | Omit = omit,
        thread: Optional[BetaMessageThreadParam] | Omit = omit,
        tool_choice: BetaToolChoiceParam | Omit = omit,
        tools: Iterable[BetaToolLike] | Omit = omit,
        betas: List[AnthropicBetaParam] | Omit = omit,
        user_profile_id: str | Omit = omit,
        workspace_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> ParsedBetaMessage[ResponseFormatT]:
        _validate_output_config_conflict(output_config, output_format)

        if not is_given(timeout) and self._client.timeout == DEFAULT_TIMEOUT:
            timeout = self._client._calculate_nonstreaming_timeout(
                max_tokens, MODEL_NONSTREAMING_TOKENS.get(model, None)
            )

        if model in DEPRECATED_MODELS:
            warnings.warn(
                f"The model '{model}' is deprecated and will reach end-of-life on {DEPRECATED_MODELS[model]}.\nPlease migrate to a newer model. Visit https://docs.anthropic.com/en/docs/resources/model-deprecations for more information.",
                DeprecationWarning,
                stacklevel=3,
            )

        if model in MODELS_TO_WARN_WITH_THINKING_ENABLED and thinking and thinking["type"] == "enabled":
            warnings.warn(
                f"Using Claude with {model} and 'thinking.type=enabled' is deprecated. Use 'thinking.type=adaptive' instead which results in better model performance in our testing: https://platform.claude.com/docs/en/build-with-claude/adaptive-thinking",
                UserWarning,
                stacklevel=3,
            )

        tools = _to_tool_params(tools)
        extra_headers = merge_headers(
            _helper_header("beta.messages.parse"),
            strip_not_given(
                {
                    "anthropic-beta": ",".join(str(e) for e in betas) if is_given(betas) else not_given,
                    "anthropic-user-profile-id": user_profile_id,
                    "anthropic-workspace-id": workspace_id,
                }
            ),
            _stainless_helper_header(tools, messages),
            extra_headers or {},
        )

        if is_given(output_format) and output_format is not None:
            merged_output_config = merge_output_config(output_config, to_json_output_format(output_format))
        else:
            merged_output_config = output_config

        def parser(response: BetaMessage) -> ParsedBetaMessage[ResponseFormatT]:
            return parse_beta_response(
                response=response,
                output_format=cast(
                    ResponseFormatT,
                    output_format if is_given(output_format) and output_format is not None else not_given,
                ),
            )

        return await self._post(
            "/v1/messages",
            body={
                "max_tokens": max_tokens,
                "messages": messages,
                "model": model,
                "cache_control": cache_control,
                "compaction": compaction,
                "container": container,
                "context_management": context_management,
                "diagnostics": diagnostics,
                "fallback_credit_token": fallback_credit_token,
                "fallbacks": fallbacks,
                "inference_geo": inference_geo,
                "mcp_servers": mcp_servers,
                "output_config": merged_output_config,
                "metadata": metadata,
                "output_format": omit,
                "service_tier": service_tier,
                "speed": speed,
                "stop_sequences": stop_sequences,
                "system": system,
                "thinking": thinking,
                "thread": thread,
                "tool_choice": tool_choice,
                "tools": tools,
            },
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                post_parser=parser,
                qualifiers={"beta": "true"},
                span_name="anthropic.messages.create",
                span_route="/v1/messages",
                span_attributes=messages_create_request_attributes,
            ),
            cast_to=cast(Type[ParsedBetaMessage[ResponseFormatT]], BetaMessage),
            stream=False,
        )

    @overload
    def tool_runner(
        self,
        *,
        max_tokens: int,
        messages: Iterable[BetaMessageParam],
        model: ModelParam,
        tools: Iterable[BetaAsyncRunnableTool | BetaAsyncRunnableToolset | BetaToolUnionParam],
        cache_control: Optional[BetaCacheControlEphemeralParam] | Omit = omit,
        max_iterations: int | Omit = omit,
        container: Optional[message_create_params.Container] | Omit = omit,
        context_management: Optional[BetaContextManagementConfigParam] | Omit = omit,
        diagnostics: Optional[BetaDiagnosticsParam] | Omit = omit,
        fallback_credit_token: Optional[message_create_params.FallbackCreditToken] | Omit = omit,
        fallbacks: Optional[BetaFallbacksParam] | Omit = omit,
        inference_geo: Optional[str] | Omit = omit,
        mcp_servers: Iterable[BetaRequestMCPServerURLDefinitionParam] | Omit = omit,
        metadata: BetaMetadataParam | Omit = omit,
        output_config: BetaOutputConfigParam | Omit = omit,
        output_format: Optional[type[ResponseFormatT]] | Omit = omit,
        service_tier: Literal["auto", "standard_only"] | Omit = omit,
        speed: Optional[Literal["standard", "fast"]] | Omit = omit,
        stop_sequences: SequenceNotStr[str] | Omit = omit,
        stream: Literal[False] | Omit = omit,
        system: Union[str, Iterable[BetaTextBlockParam]] | Omit = omit,
        thinking: BetaThinkingConfigParam | Omit = omit,
        thread: Optional[Literal[False]] | Omit = omit,
        tool_choice: BetaToolChoiceParam | Omit = omit,
        betas: List[AnthropicBetaParam] | Omit = omit,
        user_profile_id: str | Omit = omit,
        workspace_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> BetaAsyncToolRunner[ResponseFormatT]: ...

    @overload
    def tool_runner(
        self,
        *,
        max_tokens: int,
        messages: Iterable[BetaMessageParam],
        model: ModelParam,
        tools: Iterable[BetaAsyncRunnableTool | BetaAsyncRunnableToolset | BetaToolUnionParam],
        stream: Literal[True],
        max_iterations: int | Omit = omit,
        run_tools_eagerly: bool = False,
        cache_control: Optional[BetaCacheControlEphemeralParam] | Omit = omit,
        container: Optional[message_create_params.Container] | Omit = omit,
        context_management: Optional[BetaContextManagementConfigParam] | Omit = omit,
        diagnostics: Optional[BetaDiagnosticsParam] | Omit = omit,
        fallback_credit_token: Optional[message_create_params.FallbackCreditToken] | Omit = omit,
        fallbacks: Optional[BetaFallbacksParam] | Omit = omit,
        inference_geo: Optional[str] | Omit = omit,
        mcp_servers: Iterable[BetaRequestMCPServerURLDefinitionParam] | Omit = omit,
        metadata: BetaMetadataParam | Omit = omit,
        output_config: BetaOutputConfigParam | Omit = omit,
        output_format: Optional[type[ResponseFormatT]] | Omit = omit,
        service_tier: Literal["auto", "standard_only"] | Omit = omit,
        speed: Optional[Literal["standard", "fast"]] | Omit = omit,
        stop_sequences: SequenceNotStr[str] | Omit = omit,
        system: Union[str, Iterable[BetaTextBlockParam]] | Omit = omit,
        thinking: BetaThinkingConfigParam | Omit = omit,
        thread: Optional[Literal[False]] | Omit = omit,
        tool_choice: BetaToolChoiceParam | Omit = omit,
        betas: List[AnthropicBetaParam] | Omit = omit,
        user_profile_id: str | Omit = omit,
        workspace_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> BetaAsyncStreamingToolRunner[ResponseFormatT]: ...

    @overload
    def tool_runner(
        self,
        *,
        max_tokens: int,
        messages: Iterable[BetaMessageParam],
        model: ModelParam,
        tools: Iterable[BetaAsyncRunnableTool | BetaAsyncRunnableToolset | BetaToolUnionParam],
        stream: bool,
        max_iterations: int | Omit = omit,
        run_tools_eagerly: bool = False,
        cache_control: Optional[BetaCacheControlEphemeralParam] | Omit = omit,
        container: Optional[message_create_params.Container] | Omit = omit,
        context_management: Optional[BetaContextManagementConfigParam] | Omit = omit,
        diagnostics: Optional[BetaDiagnosticsParam] | Omit = omit,
        fallback_credit_token: Optional[message_create_params.FallbackCreditToken] | Omit = omit,
        fallbacks: Optional[BetaFallbacksParam] | Omit = omit,
        inference_geo: Optional[str] | Omit = omit,
        mcp_servers: Iterable[BetaRequestMCPServerURLDefinitionParam] | Omit = omit,
        metadata: BetaMetadataParam | Omit = omit,
        output_config: BetaOutputConfigParam | Omit = omit,
        output_format: Optional[type[ResponseFormatT]] | Omit = omit,
        service_tier: Literal["auto", "standard_only"] | Omit = omit,
        speed: Optional[Literal["standard", "fast"]] | Omit = omit,
        stop_sequences: SequenceNotStr[str] | Omit = omit,
        system: Union[str, Iterable[BetaTextBlockParam]] | Omit = omit,
        thinking: BetaThinkingConfigParam | Omit = omit,
        thread: Optional[Literal[False]] | Omit = omit,
        tool_choice: BetaToolChoiceParam | Omit = omit,
        betas: List[AnthropicBetaParam] | Omit = omit,
        user_profile_id: str | Omit = omit,
        workspace_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> BetaAsyncStreamingToolRunner[ResponseFormatT] | BetaAsyncToolRunner[ResponseFormatT]: ...

    def tool_runner(
        self,
        *,
        max_tokens: int,
        messages: Iterable[BetaMessageParam],
        model: ModelParam,
        tools: Iterable[BetaAsyncRunnableTool | BetaAsyncRunnableToolset | BetaToolUnionParam],
        max_iterations: int | Omit = omit,
        run_tools_eagerly: bool = False,
        cache_control: Optional[BetaCacheControlEphemeralParam] | Omit = omit,
        container: Optional[message_create_params.Container] | Omit = omit,
        context_management: Optional[BetaContextManagementConfigParam] | Omit = omit,
        diagnostics: Optional[BetaDiagnosticsParam] | Omit = omit,
        fallback_credit_token: Optional[message_create_params.FallbackCreditToken] | Omit = omit,
        fallbacks: Optional[BetaFallbacksParam] | Omit = omit,
        inference_geo: Optional[str] | Omit = omit,
        mcp_servers: Iterable[BetaRequestMCPServerURLDefinitionParam] | Omit = omit,
        metadata: BetaMetadataParam | Omit = omit,
        output_config: BetaOutputConfigParam | Omit = omit,
        output_format: Optional[type[ResponseFormatT]] | Omit = omit,
        service_tier: Literal["auto", "standard_only"] | Omit = omit,
        speed: Optional[Literal["standard", "fast"]] | Omit = omit,
        stop_sequences: SequenceNotStr[str] | Omit = omit,
        stream: Literal[True] | Literal[False] | Omit = omit,
        system: Union[str, Iterable[BetaTextBlockParam]] | Omit = omit,
        thinking: BetaThinkingConfigParam | Omit = omit,
        thread: Optional[Literal[False]] | Omit = omit,
        tool_choice: BetaToolChoiceParam | Omit = omit,
        betas: List[AnthropicBetaParam] | Omit = omit,
        user_profile_id: str | Omit = omit,
        workspace_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> BetaAsyncToolRunner[ResponseFormatT] | BetaAsyncStreamingToolRunner[ResponseFormatT]:
        """Run the tools the model calls until it stops asking for them, yielding each assistant message.

        The loop runs over a message thread by default, so each turn sends only new messages. Pass `thread=False` to
        send the full history every turn.

        Args:
          run_tools_eagerly: Run each tool as soon as its call is complete, before the reply finishes, instead of
              once you are done with the reply. This is optimistic: if the reply is interrupted or changes
              course, the tool may have already run, so use `runner.defer_tool_call()` to hold the calls that
              aren't safe to run twice. The calls run one at a time, and reading the stream waits while one
              runs. A toolset call, such as a browser or computer action, runs early too, and its toolset's
              `confirm` is still asked before it runs. Requires `stream=True`.

              This will be the default in a future version.
        """
        _validate_output_config_conflict(output_config, output_format)

        if run_tools_eagerly and not stream:
            raise ValueError("`run_tools_eagerly=True` and `stream=False` are mutually exclusive")

        if model in DEPRECATED_MODELS:
            warnings.warn(
                f"The model '{model}' is deprecated and will reach end-of-life on {DEPRECATED_MODELS[model]}.\nPlease migrate to a newer model. Visit https://docs.anthropic.com/en/docs/resources/model-deprecations for more information.",
                DeprecationWarning,
                stacklevel=3,
            )

        if model in MODELS_TO_WARN_WITH_THINKING_ENABLED and thinking and thinking["type"] == "enabled":
            warnings.warn(
                f"Using Claude with {model} and 'thinking.type=enabled' is deprecated. Use 'thinking.type=adaptive' instead which results in better model performance in our testing: https://platform.claude.com/docs/en/build-with-claude/adaptive-thinking",
                UserWarning,
                stacklevel=3,
            )

        # A synchronous tool or toolset is refused here, before anything is sent. The thread keeps the tools in the
        # order given and sends each toolset as its `tools[]` entry.
        tools = list(tools)
        partition_async_tools(tools)

        params = cast(
            message_create_params.ParseMessageCreateParamsBase[ResponseFormatT],
            given(
                {
                    "max_tokens": max_tokens,
                    "messages": messages,
                    "model": model,
                    "cache_control": cache_control,
                    "container": container,
                    "context_management": context_management,
                    "diagnostics": diagnostics,
                    "fallback_credit_token": fallback_credit_token,
                    "fallbacks": fallbacks,
                    "inference_geo": inference_geo,
                    "mcp_servers": mcp_servers,
                    "metadata": metadata,
                    "output_config": output_config,
                    "output_format": output_format,
                    "service_tier": service_tier,
                    "speed": speed,
                    "stop_sequences": stop_sequences,
                    "system": system,
                    "thinking": thinking,
                    "thread": thread,
                    "tool_choice": tool_choice,
                    "tools": tools,
                    "betas": betas,
                    "user_profile_id": user_profile_id,
                    "workspace_id": workspace_id,
                }
            ),
        )
        message_thread = BetaAsyncMessageThread[ResponseFormatT]._for_tool_runner(
            cast("AsyncAnthropic", self._client), params
        )
        if run_tools_eagerly:
            # `thread.tool_runner()` has no `run_tools_eagerly` parameter, so the eager runner is made here.
            return BetaAsyncStreamingToolRunner[ResponseFormatT](
                thread=message_thread,
                options=turn_overrides(
                    extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
                ),
                max_iterations=max_iterations if is_given(max_iterations) else None,
                run_tools_eagerly=True,
            )
        return message_thread.tool_runner(
            max_iterations=max_iterations,
            stream=stream,
            extra_headers=extra_headers,
            extra_query=extra_query,
            extra_body=extra_body,
            timeout=timeout,
        )

    def thread(
        self,
        *,
        max_tokens: int,
        model: ModelParam,
        messages: Iterable[BetaMessageParam] | Omit = omit,
        tools: Iterable[BetaAsyncRunnableTool | BetaToolUnionParam] | Omit = omit,
        output_format: Optional[type[ResponseFormatT]] | Omit = omit,
        unsupported_request_behavior: UnsupportedRequestBehavior = "error",
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
        **params: Unpack[ThreadCreateParams],
    ) -> BetaAsyncMessageThread[ResponseFormatT]:
        """Start a message thread: a conversation the server holds between turns, so each request sends only the new
        messages. Takes the arguments of `create()` except `thread`, with `messages` optional, and sends nothing."""
        return BetaAsyncMessageThread(
            cast("AsyncAnthropic", self._client),
            max_tokens=max_tokens,
            model=model,
            messages=messages,
            tools=tools,
            output_format=output_format,
            unsupported_request_behavior=unsupported_request_behavior,
            extra_headers=extra_headers,
            extra_query=extra_query,
            extra_body=extra_body,
            timeout=timeout,
            **params,
        )

    def stream(
        self,
        *,
        max_tokens: int,
        messages: Iterable[BetaMessageParam],
        model: ModelParam,
        cache_control: Optional[BetaCacheControlEphemeralParam] | Omit = omit,
        compaction: Optional[BetaCompactionConfigParam] | Omit = omit,
        metadata: BetaMetadataParam | Omit = omit,
        output_config: BetaOutputConfigParam | Omit = omit,
        output_format: Optional[type[ResponseFormatT]] | Omit = omit,
        container: Optional[message_create_params.Container] | Omit = omit,
        context_management: Optional[BetaContextManagementConfigParam] | Omit = omit,
        diagnostics: Optional[BetaDiagnosticsParam] | Omit = omit,
        fallback_credit_token: Optional[message_create_params.FallbackCreditToken] | Omit = omit,
        fallbacks: Optional[BetaFallbacksParam] | Omit = omit,
        inference_geo: Optional[str] | Omit = omit,
        mcp_servers: Iterable[BetaRequestMCPServerURLDefinitionParam] | Omit = omit,
        service_tier: Literal["auto", "standard_only"] | Omit = omit,
        speed: Optional[Literal["standard", "fast"]] | Omit = omit,
        stop_sequences: SequenceNotStr[str] | Omit = omit,
        system: Union[str, Iterable[BetaTextBlockParam]] | Omit = omit,
        thinking: BetaThinkingConfigParam | Omit = omit,
        thread: Optional[BetaMessageThreadParam] | Omit = omit,
        tool_choice: BetaToolChoiceParam | Omit = omit,
        tools: Iterable[BetaToolLike] | Omit = omit,
        betas: List[AnthropicBetaParam] | Omit = omit,
        user_profile_id: str | Omit = omit,
        workspace_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> BetaAsyncMessageStreamManager[ResponseFormatT]:
        _validate_output_config_conflict(output_config, output_format)

        if model in DEPRECATED_MODELS:
            warnings.warn(
                f"The model '{model}' is deprecated and will reach end-of-life on {DEPRECATED_MODELS[model]}.\nPlease migrate to a newer model. Visit https://docs.anthropic.com/en/docs/resources/model-deprecations for more information.",
                DeprecationWarning,
                stacklevel=3,
            )

        if model in MODELS_TO_WARN_WITH_THINKING_ENABLED and thinking and thinking["type"] == "enabled":
            warnings.warn(
                f"Using Claude with {model} and 'thinking.type=enabled' is deprecated. Use 'thinking.type=adaptive' instead which results in better model performance in our testing: https://platform.claude.com/docs/en/build-with-claude/adaptive-thinking",
                UserWarning,
                stacklevel=3,
            )

        tools = _to_tool_params(tools)
        extra_headers = merge_headers(
            {
                _STAINLESS_HELPER_METHOD_HEADER: _HELPER_METHOD_STREAM,
                _STAINLESS_STREAM_HELPER_HEADER: "beta.messages",
            },
            strip_not_given(
                {
                    "anthropic-beta": ",".join(str(e) for e in betas) if is_given(betas) else not_given,
                    "anthropic-user-profile-id": user_profile_id,
                    "anthropic-workspace-id": workspace_id,
                }
            ),
            _stainless_helper_header(tools, messages),
            extra_headers or {},
        )

        transformed_output_format: BetaJSONOutputFormatParam | Omit = omit
        if is_given(output_format) and output_format is not None:
            transformed_output_format = to_json_output_format(output_format)
        merged_output_config = merge_output_config(output_config, transformed_output_format)

        request = self._post(
            "/v1/messages",
            body={
                "max_tokens": max_tokens,
                "messages": messages,
                "model": model,
                "cache_control": cache_control,
                "compaction": compaction,
                "metadata": metadata,
                "output_config": merged_output_config,
                "output_format": omit,
                "container": container,
                "context_management": context_management,
                "diagnostics": diagnostics,
                "fallback_credit_token": fallback_credit_token,
                "fallbacks": fallbacks,
                "inference_geo": inference_geo,
                "mcp_servers": mcp_servers,
                "service_tier": service_tier,
                "speed": speed,
                "stop_sequences": stop_sequences,
                "system": system,
                "thinking": thinking,
                "thread": thread,
                "tools": tools,
                "tool_choice": tool_choice,
                "stream": True,
            },
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                qualifiers={"beta": "true"},
                span_name="anthropic.messages.create",
                span_route="/v1/messages",
                span_attributes=messages_create_request_attributes,
            ),
            cast_to=BetaMessage,
            stream=True,
            stream_cls=AsyncStream[BetaRawMessageStreamEvent],
        )
        return BetaAsyncMessageStreamManager(
            request,
            output_format=cast(ResponseFormatT, output_format),
        )

    async def count_tokens(
        self,
        *,
        messages: Iterable[BetaMessageParam],
        model: ModelParam,
        cache_control: Optional[BetaCacheControlEphemeralParam] | Omit = omit,
        compaction: Optional[BetaCompactionConfigParam] | Omit = omit,
        context_management: Optional[BetaContextManagementConfigParam] | Omit = omit,
        mcp_servers: Iterable[BetaRequestMCPServerURLDefinitionParam] | Omit = omit,
        output_config: BetaOutputConfigParam | Omit = omit,
        speed: Optional[Literal["standard", "fast"]] | Omit = omit,
        system: Union[str, Iterable[BetaTextBlockParam]] | Omit = omit,
        thinking: BetaThinkingConfigParam | Omit = omit,
        tool_choice: BetaToolChoiceParam | Omit = omit,
        tools: Iterable[BetaToolLike] | Omit = omit,
        betas: List[AnthropicBetaParam] | Omit = omit,
        user_profile_id: str | Omit = omit,
        workspace_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> BetaMessageTokensCount:
        """
        Count the number of tokens in a Message.

        The Token Count API can be used to count the number of tokens in a Message,
        including tools, images, and documents, without creating it.

        Learn more about token counting in our
        [user guide](https://platform.claude.com/docs/en/build-with-claude/token-counting)

        Args:
          messages: Input messages.

              Our models are trained to operate on alternating `user` and `assistant`
              conversational turns. When creating a new `Message`, you specify the prior
              conversational turns with the `messages` parameter, and the model then generates
              the next `Message` in the conversation. Consecutive `user` or `assistant` turns
              in your request will be combined into a single turn.

              Each input message must be an object with a `role` and `content`. You can
              specify a single `user`-role message, or you can include multiple `user` and
              `assistant` messages.

              If the final message uses the `assistant` role, the response content will
              continue immediately from the content in that message. This can be used to
              constrain part of the model's response. This is called prefill. On models that
              don't support prefill, creating a message that ends with a partial `assistant`
              response returns a 400 error. See
              [Prefill not supported](https://platform.claude.com/docs/en/api/errors#prefill-not-supported).

              Example with a single `user` message:

              ```json
              [{ "role": "user", "content": "Hello, Claude" }]
              ```

              Example with multiple conversational turns:

              ```json
              [
                { "role": "user", "content": "Hello there." },
                { "role": "assistant", "content": "Hi, I'm Claude. How can I help you?" },
                { "role": "user", "content": "Can you explain LLMs in plain English?" }
              ]
              ```

              Example with a partially-filled response from Claude, for models that support
              prefill:

              ```json
              [
                {
                  "role": "user",
                  "content": "What's the Greek name for Sun? (A) Sol (B) Helios (C) Sun"
                },
                { "role": "assistant", "content": "The best answer is (" }
              ]
              ```

              Each input message `content` may be either a single `string` or an array of
              content blocks, where each block has a specific `type`. Using a `string` for
              `content` is shorthand for an array of one content block of type `"text"`. The
              following input messages are equivalent:

              ```json
              { "role": "user", "content": "Hello, Claude" }
              ```

              ```json
              { "role": "user", "content": [{ "type": "text", "text": "Hello, Claude" }] }
              ```

              See
              [input examples](https://platform.claude.com/docs/en/build-with-claude/working-with-messages).

              Note that if you want to include a
              [system prompt](https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/claude-prompting-best-practices#give-claude-a-role),
              you can use the top-level `system` parameter.

              There is a limit of 100,000 messages in a single request.

          model: The model that will complete your prompt.

              See [models](https://docs.anthropic.com/en/docs/models-overview) for additional
              details and options.

          cache_control: Top-level cache control automatically applies a cache_control marker to the last
              cacheable block in the request.

          compaction: Compaction configuration.

              When set on `POST /v1/messages`, the request is a compaction request: the
              conversation in `messages` is summarized and the response holds only the
              resulting `compaction` block (`stop_reason` `"compaction"`), which later
              requests send first in `messages` in place of the messages it summarizes.
              `POST /v1/messages/count_tokens` accepts this parameter and ignores it: the
              count it returns is for the conversation in `messages` as sent. Cannot be
              combined with `context_management`.

          context_management: Context management configuration.

              This allows you to control how Claude manages context across multiple requests,
              such as whether to clear function results or not.

          mcp_servers: MCP servers to be utilized in this request

          output_config: Configuration options for the model's output, such as the output format.

          speed: The inference speed mode for this request. `"fast"` enables high
              output-tokens-per-second inference.

              Some models require the `fast-mode-2026-02-01` beta header for any `speed`
              value. See
              [fast mode](https://platform.claude.com/docs/en/build-with-claude/fast-mode) for
              which models.

          system: System prompt.

              A system prompt is a way of providing context and instructions to Claude, such
              as specifying a particular goal or role. See our
              [guide to system prompts](https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/claude-prompting-best-practices#give-claude-a-role).

          thinking: Configuration for Claude's thinking.

              With `{"type": "adaptive"}`, Claude decides when and how much to think. With
              `{"type": "enabled"}` (manual extended thinking), you set a `budget_tokens` of
              at least 1,024. Thinking tokens count toward your `max_tokens` limit.

              Which `type` values are accepted, and what happens when you omit `thinking`,
              depend on the model. See
              [thinking](https://platform.claude.com/docs/en/build-with-claude/thinking#configuring-thinking)
              for each model's behavior.

          tool_choice: How the model should use the provided tools. The model can use a specific tool,
              any available tool, decide by itself, or not use tools at all.

          tools: Definitions of tools that the model may use.

              If you include `tools` in your API request, the model may return `tool_use`
              content blocks that represent the model's use of those tools. You can then run
              those tools using the tool input generated by the model and then optionally
              return results back to the model using `tool_result` content blocks.

              There are two types of tools: **client tools** and **server tools**. The
              behavior described below applies to client tools. For
              [server tools](https://platform.claude.com/docs/en/agents-and-tools/tool-use/server-tools),
              see their individual documentation as each has its own behavior (e.g., the
              [web search tool](https://platform.claude.com/docs/en/agents-and-tools/tool-use/web-search-tool)).

              Each tool definition includes:

              - `name`: Name of the tool.
              - `description`: Optional, but strongly-recommended description of the tool.
              - `input_schema`: [JSON schema](https://json-schema.org/draft/2020-12) for the
                tool `input` shape that the model will produce in `tool_use` output content
                blocks.

              For example, if you defined `tools` as:

              ```json
              [
                {
                  "name": "get_stock_price",
                  "description": "Get the current stock price for a given ticker symbol.",
                  "input_schema": {
                    "type": "object",
                    "properties": {
                      "ticker": {
                        "type": "string",
                        "description": "The stock ticker symbol, e.g. AAPL for Apple Inc."
                      }
                    },
                    "required": ["ticker"]
                  }
                }
              ]
              ```

              And then asked the model "What's the S&P 500 at today?", the model might produce
              `tool_use` content blocks in the response like this:

              ```json
              [
                {
                  "type": "tool_use",
                  "id": "toolu_01D7FLrfh4GYq7yT1ULFeyMV",
                  "name": "get_stock_price",
                  "input": { "ticker": "^GSPC" }
                }
              ]
              ```

              You might then run your `get_stock_price` tool with `{"ticker": "^GSPC"}` as an
              input, and return the following back to the model in a subsequent `user`
              message:

              ```json
              [
                {
                  "type": "tool_result",
                  "tool_use_id": "toolu_01D7FLrfh4GYq7yT1ULFeyMV",
                  "content": "259.75 USD"
                }
              ]
              ```

              Tools can be used for workflows that include running client-side tools and
              functions, or more generally whenever you want the model to produce a particular
              JSON structure of output.

              See our
              [guide](https://platform.claude.com/docs/en/agents-and-tools/tool-use/overview)
              for more details.

          betas: Optional header to specify the beta version(s) you want to use.

          user_profile_id: The user profile ID to attribute this request to. Use when acting on behalf of a
              party other than your organization.

          workspace_id: Optional header to select the Workspace for this request. The value is a
              Workspace ID (for example, `wrkspc_011CZkZaBF1tNoB5wlCeusgy`).

              Only needed for credentials that can act on more than one Workspace. A
              credential that belongs to a specific Workspace may omit it; if sent, it must
              match that Workspace.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds

        Raises:
          AvailableToolsLimitExceededError:

          ClaudeCodeKeyCreatorNotMemberError:

          CompactionBlockAmbiguousError:

          CompactionBlockMisplacedError:

          CompactionContentMismatchError:

          CompactionNothingToSummarizeError:

          CompactionSignatureInvalidError:

          CompactionToolChangesMismatchError:

          OrganizationOnHoldError:

          RequestBodyEncodingInvalidError:

          RequestBodyEncodingUnsupportedError:

          ToolNameConflictError:

          ToolReferenceUnresolvedError:

          RequestBodyTooLargeAfterDecodingError:

          EnforcedSpendLimitReachedError:

          CompactionUnavailableError:
        """
        tools = _to_tool_params(tools)
        extra_headers = {
            **strip_not_given(
                {
                    "anthropic-beta": ",".join(chain((str(e) for e in betas), ["token-counting-2024-11-01"]))
                    if is_given(betas)
                    else not_given,
                    "anthropic-user-profile-id": user_profile_id,
                    "anthropic-workspace-id": workspace_id,
                }
            ),
            **(extra_headers or {}),
        }
        extra_headers = {"anthropic-beta": "token-counting-2024-11-01", **(extra_headers or {})}
        return await self._post(
            "/v1/messages/count_tokens",
            body={
                "messages": messages,
                "model": model,
                "cache_control": cache_control,
                "compaction": compaction,
                "context_management": context_management,
                "mcp_servers": mcp_servers,
                "output_config": output_config,
                "speed": speed,
                "system": system,
                "thinking": thinking,
                "tool_choice": tool_choice,
                "tools": tools,
            },
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                qualifiers={"beta": "true"},
                span_name="anthropic.messages.count_tokens",
                span_route="/v1/messages/count_tokens",
            ),
            cast_to=BetaMessageTokensCount,
        )


class MessagesWithRawResponse:
    def __init__(self, messages: Messages) -> None:
        self._messages = messages

        self.create = to_raw_response_wrapper(
            messages.create,
        )
        self.parse = to_raw_response_wrapper(
            messages.parse,
        )
        self.count_tokens = to_raw_response_wrapper(
            messages.count_tokens,
        )

    @cached_property
    def batches(self) -> BatchesWithRawResponse:
        return BatchesWithRawResponse(self._messages.batches)


class AsyncMessagesWithRawResponse:
    def __init__(self, messages: AsyncMessages) -> None:
        self._messages = messages

        self.create = async_to_raw_response_wrapper(
            messages.create,
        )
        self.parse = async_to_raw_response_wrapper(
            messages.parse,
        )
        self.count_tokens = async_to_raw_response_wrapper(
            messages.count_tokens,
        )

    @cached_property
    def batches(self) -> AsyncBatchesWithRawResponse:
        return AsyncBatchesWithRawResponse(self._messages.batches)


class MessagesWithStreamingResponse:
    def __init__(self, messages: Messages) -> None:
        self._messages = messages

        self.create = to_streamed_response_wrapper(
            messages.create,
        )
        self.count_tokens = to_streamed_response_wrapper(
            messages.count_tokens,
        )

    @cached_property
    def batches(self) -> BatchesWithStreamingResponse:
        return BatchesWithStreamingResponse(self._messages.batches)


class AsyncMessagesWithStreamingResponse:
    def __init__(self, messages: AsyncMessages) -> None:
        self._messages = messages

        self.create = async_to_streamed_response_wrapper(
            messages.create,
        )
        self.count_tokens = async_to_streamed_response_wrapper(
            messages.count_tokens,
        )

    @cached_property
    def batches(self) -> AsyncBatchesWithStreamingResponse:
        return AsyncBatchesWithStreamingResponse(self._messages.batches)
